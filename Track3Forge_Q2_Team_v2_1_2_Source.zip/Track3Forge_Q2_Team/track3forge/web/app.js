const el=id=>document.getElementById(id);
async function load(){
  try{
    const r=await fetch('/api/runs',{cache:'no-store'});
    if(!r.ok)throw Error('request failed');const runs=await r.json();
    el('nRuns').textContent=runs.length;
    el('nExports').textContent=runs.reduce((s,r)=>s+(r.exported_real_docker||0),0);
    el('nProofs').textContent=runs.reduce((s,r)=>s+(r.verified_vulnerabilities||0),0);
    const area=el('runs');area.replaceChildren();
    if(!runs.length){area.textContent='暂无记录。先执行 q2 plan 或 run。';return;}
    for(const run of runs){
      const b=document.createElement('section');b.className='batch';
      const h=document.createElement('header');h.textContent=run.id+' · '+run.requested+' 个 CVE';b.appendChild(h);
      for(const item of run.results||[]){
        const row=document.createElement('div');row.className='case';
        const name=document.createElement('strong');name.textContent=item.cve;
        const status=document.createElement('span');status.className='status';status.textContent=item.status + (item.proof_status ? (' · PROOF: '+item.proof_status) : '');
        const btn=document.createElement('button');btn.type='button';btn.textContent='查看证据';
        btn.onclick=async()=>{const res=await fetch('/api/case/'+encodeURIComponent(run.id)+'/'+encodeURIComponent(item.cve));
          const x=await res.json();el('detail').hidden=false;el('json').textContent=JSON.stringify(x,null,2);el('detail').scrollIntoView({behavior:'smooth'});};
        row.append(name,status,btn);b.appendChild(row);
      }area.appendChild(b);
    }
  }catch(e){el('runs').textContent='读取失败：'+String(e)}
}
el('refresh').addEventListener('click',load);load();
