"""Mechanism-oriented, fail-closed CVE triage based on local Vulhub metadata.

No model-written exploit is run. Registry tags classify work, never prove behavior.
The only recognized proof files are preexisting, audited isolated-lab oracles.
"""
from __future__ import annotations

import ast
import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

try:
    import tomllib
except ImportError:  # Python 3.10; the installed project declares >=3.10.
    tomllib = None

from .catalog import validate_cve, find_recipes, read_cves
from .core import TaskError, json_write, within, sha256_file

# Multiple labels are preserved. Priority is only for batch stratification.
TAG_FAMILY = {
    'Path Traversal': 'FILE_READ_TRAVERSAL',
    'Info Disclosure': 'INFORMATION_DISCLOSURE',
    'Deserialization': 'UNSAFE_DESERIALIZATION',
    'SQL Injection': 'SQL_INJECTION',
    'Auth Bypass': 'AUTHORIZATION_BYPASS',
    'Privilege Escalation': 'PRIVILEGE_ESCALATION',
    'SSRF': 'SERVER_SIDE_REQUEST',
    'XSS': 'CROSS_SITE_SCRIPTING',
    'XXE': 'XML_EXTERNAL_ENTITY',
    'SSTI': 'TEMPLATE_INJECTION',
    'Expression Injection': 'EXPRESSION_INJECTION',
    'File Upload': 'FILE_UPLOAD',
    'File Deletion': 'FILE_DELETION',
    'Environment Injection': 'ENVIRONMENT_INJECTION',
    'RCE': 'CODE_EXECUTION',
    'DoS': 'DENIAL_OF_SERVICE',
    'Backdoor': 'BACKDOOR',
    'Hard Coding': 'HARDCODED_CREDENTIAL',
}
# Practical effect-oriented objectives: never infer a trigger from a CVE ID.
FAMILY_GOALS = {
    'FILE_READ_TRAVERSAL': 'random target-owned file; benign-path negative; matched patched control',
    'INFORMATION_DISCLOSURE': 'unique non-secret target marker; authorized baseline; patched control',
    'UNSAFE_DESERIALIZATION': 'inert class-load / target-origin local callback; patched negative',
    'SQL_INJECTION': 'side-effect-free response differential; ordinary-input control; patched control',
    'AUTHORIZATION_BYPASS': 'unauthenticated and authorized identities; protected test resource; patched control',
    'PRIVILEGE_ESCALATION': 'low-privilege and authorized identities; state-difference control',
    'SERVER_SIDE_REQUEST': 'unique local callback; target IP attribution; patched control',
    'CROSS_SITE_SCRIPTING': 'inert unique marker with browser-context analysis; patched control',
    'XML_EXTERNAL_ENTITY': 'local canary resolver and network callback; patched control',
    'TEMPLATE_INJECTION': 'side-effect-free deterministic expression; patched control',
    'EXPRESSION_INJECTION': 'side-effect-free expression result; patched control',
    'FILE_UPLOAD': 'non-executable unique test file; authorized baseline; patched control',
    'FILE_DELETION': 'disposable canary and before/after state; patched control',
    'ENVIRONMENT_INJECTION': 'inert environment-value change; clean process baseline; patched control',
    'CODE_EXECUTION': 'non-destructive effect or local callback; do not label RCE without direct evidence',
    'DENIAL_OF_SERVICE': 'bounded health differential with safe rate/time ceilings; patched control',
    'BACKDOOR': 'controlled identity and authorization difference; patched control',
    'HARDCODED_CREDENTIAL': 'controlled credential authentication; patched control',
    'UNCLASSIFIED': 'collect advisory, components, expected effect and patched baseline before proving',
}
# These are legacy verified *implementations*, not claims of whole-family coverage.
# Exact-CVE binding prevents misapplying a successful proof to another vulnerability.
AUDITED_ORACLES = {
    'CVE-2021-43798': ('FILE_READ_TRAVERSAL', 'grafana_file_read_v1', 'proof/known/known_proof.json'),
    'CVE-2021-41773': ('FILE_READ_TRAVERSAL', 'apache_file_read_v1', 'proof/apache/apache_proof.json'),
    'CVE-2023-46604': ('UNSAFE_DESERIALIZATION', 'openwire_callback_v1', 'proof/activemq/activemq_proof.json'),
}


def _inside_registry_path(root, relative):
    if not isinstance(relative, str) or not relative or relative.startswith('/') or '\\' in relative:
        raise TaskError('REGISTRY_UNSAFE_PATH', repr(relative))
    p = root / relative
    if not within(p, root) or p.is_symlink():
        raise TaskError('REGISTRY_UNSAFE_PATH', repr(relative))
    return p.resolve()


def _read_registry_doc(content):
    """Use stdlib TOML when present; on Python 3.10 parse only registry fields.

    This fallback deliberately ignores Dockerfile tables and all other TOML
    semantics. It never interprets Python expressions: ast.literal_eval only.
    Unexpected syntax fails closed instead of silently assigning a type.
    """
    decoded=content.decode('utf-8-sig')
    if tomllib is not None:
        return tomllib.loads(decoded)
    fields={'name','cve','app','path','tags'}
    entries=[]; current=None
    for raw in decoded.splitlines():
        line=raw.strip()
        if line=='[[environment]]':
            current={}; entries.append(current); continue
        if current is None or '=' not in line:continue
        key,value=line.split('=',1)
        key=key.strip()
        if key not in fields:continue
        # Require a single-line string or array of strings for the needed metadata.
        try:
            obj=ast.literal_eval(value.strip())
        except (ValueError,TypeError,SyntaxError) as exc:
            raise TaskError('REGISTRY_UNSUPPORTED_TOML',f'{key}: Python 3.10 fallback cannot parse metadata') from exc
        if not isinstance(obj,(str,list)):
            raise TaskError('REGISTRY_INVALID',f'{key}: type not allowed')
        current[key]=obj
    return {'environment':entries}


def load_registry(root):
    root=Path(root).expanduser().resolve()
    manifest=root/'environments.toml'
    if not manifest.is_file() or manifest.is_symlink():
        raise TaskError('REGISTRY_MISSING', f'{manifest}: run q2 discover --fetch')
    if manifest.stat().st_size > 12_000_000:
        raise TaskError('REGISTRY_OVERSIZE', 'Registry exceeds 12 MB')
    content=manifest.read_bytes()
    try:
        doc=_read_registry_doc(content)
    except (ValueError, UnicodeError) as exc:
        raise TaskError('REGISTRY_INVALID', str(exc)[:500]) from exc
    entries=doc.get('environment', [])
    if not isinstance(entries, list):
        raise TaskError('REGISTRY_INVALID', 'Expected [[environment]] array')
    by_cve=defaultdict(list)
    for entry in entries:
        if not isinstance(entry, dict): continue
        ids=entry.get('cve') or []
        if not isinstance(ids, list): continue
        app=entry.get('app') or 'Unknown'
        tags=entry.get('tags') or []
        if not isinstance(tags, list) or not all(isinstance(t,str) for t in tags):
            raise TaskError('REGISTRY_INVALID', 'tags must be list of strings')
        path=entry.get('path')
        if not path: continue
        resolved=_inside_registry_path(root,path)
        for cid in ids:
            try: cve=validate_cve(cid)
            except TaskError:continue
            by_cve[cve].append({
                'app':str(app)[:120], 'name':str(entry.get('name') or '')[:200],
                'path':str(resolved), 'tags':sorted(set(tags)),
                'families':sorted({TAG_FAMILY[t] for t in tags if t in TAG_FAMILY}),
            })
    return by_cve, hashlib.sha256(content).hexdigest()


def _proof_audit(case, cve):
    if not case or not case.is_dir(): return {'status':'NOT_EVALUATED'}
    source=case/'result.json'
    if not source.is_file(): return {'status':'CASE_NOT_PRESENT'}
    try:
        data=json.loads(source.read_text(encoding='utf-8'))
    except (OSError,ValueError): return {'status':'INVALID_CASE_DATA'}
    if data.get('cve')!=cve or data.get('status')!='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
        return {'status':'CASE_NOT_EXPORTED'}
    oracle=AUDITED_ORACLES.get(cve)
    if not oracle: return {'status':'NO_AUDITED_ORACLE'}
    artifact=data.get('artifact')
    # Proof must still point at bytes that exist and match the original export.
    if not artifact or not Path(artifact).is_file():
        return {'status':'ARTIFACT_MISSING','oracle':oracle[1]}
    if sha256_file(artifact) != data.get('archive_sha256'):
        return {'status':'ARTIFACT_HASH_MISMATCH','oracle':oracle[1]}
    path=case/oracle[2]
    if not path.is_file(): return {'status':'NOT_TESTED','oracle':oracle[1]}
    try: proof=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {'status':'INVALID_PROOF_DATA'}
    # Only accept an existing proof that is connected to the exact exported artifact.
    ident=proof.get('identity') or {}
    if (proof.get('cve')!=cve or proof.get('status')!='BEHAVIOR_VERIFIED'
        or proof.get('vulnerability_verified') is not True
        or ident.get('artifact_sha256')!=data.get('archive_sha256')):
        return {'status':'PROOF_UNTRUSTED_OR_ARTIFACT_MISMATCH','oracle':oracle[1]}
    vuln=proof.get('vulnerable_trial') or {}
    fixed=proof.get('fixed_trial') or {}
    if cve in ('CVE-2021-43798','CVE-2021-41773'):
        valid=(vuln.get('positive_exact') is True
               and fixed.get('positive_exact') is False
               and vuln.get('negative_exact') is False
               and fixed.get('negative_exact') is False)
    elif cve=='CVE-2023-46604':
        valid=(vuln.get('callback_from_broker') is True
               and fixed.get('callback_from_broker') is False
               and vuln.get('baseline_no_callback') is True
               and fixed.get('baseline_no_callback') is True
               and vuln.get('cleanup_ok') is True
               and fixed.get('cleanup_ok') is True)
    else: valid=False
    if not valid: return {'status':'PROOF_CONTRACT_FAILED','oracle':oracle[1]}
    return {'status':'BEHAVIOR_VERIFIED','oracle':oracle[1],
            'evidence_path':str(path),'evidence_kind':proof.get('evidence_kind','AUDITED_DIFFERENTIAL')}


def assess(cves, source, *, pilot=None):
    root=Path(source).expanduser().resolve()
    registry,digest=load_registry(root)
    pilot=Path(pilot).expanduser().resolve() if pilot else None
    rows=[]
    for cve in cves:
        cve=validate_cve(cve)
        entries=registry.get(cve,[])
        recipes=find_recipes(root,cve)
        registered_paths={Path(e['path']) for e in entries}
        found_paths={p.resolve().parent for p in recipes}
        overlap=sorted(registered_paths & found_paths)
        status=('REGISTERED_RECIPE_MATCHED' if overlap else
                'REGISTRY_RECIPE_MISMATCH' if entries and recipes else
                'REGISTERED_RECIPE_MISSING' if entries else
                'UNREGISTERED_RECIPE_FOUND' if recipes else 'NO_RECIPE')
        # Prefer the registry entry that matches the concrete Compose recipe.
        selected=[x for x in entries if Path(x['path']) in overlap] or entries
        tags=sorted({tag for e in selected for tag in e['tags']})
        families=sorted({f for e in selected for f in e['families']})
        primary=next((f for f in FAMILY_GOALS if f in families),'UNCLASSIFIED')
        implementation=AUDITED_ORACLES.get(cve)
        proof=_proof_audit(pilot/cve if pilot else None,cve)
        rows.append({
            'cve':cve, 'app':selected[0]['app'] if selected else 'Unknown',
            'recipe_status':status, 'registered_recipe':str(overlap[0]) if overlap else None,
            'tags':tags, 'families':families, 'primary_family':primary,
            'proof_goal':FAMILY_GOALS[primary],
            'runtime_probe':'INTERNAL_NETWORK_PROTOCOL_PROBE_AVAILABLE' if recipes else 'NO_RECIPE',
            'oracle_status':'AUDITED_EXACT_SCOPE' if implementation else 'ORACLE_REQUIRED',
            'oracle_engine':implementation[1] if implementation else None,
            'proof':proof,
        })
    return {
        'status':'MECHANISM_ASSESSMENT_NOT_CVE_PROOF',
        'requested':len(rows), 'source':str(root), 'registry_sha256':digest,
        'registered_recipe_matches':sum(x['recipe_status']=='REGISTERED_RECIPE_MATCHED' for x in rows),
        'oracle_implemented':sum(x['oracle_status']=='AUDITED_EXACT_SCOPE' for x in rows),
        'verified_from_existing_evidence':sum(x['proof']['status']=='BEHAVIOR_VERIFIED' for x in rows),
        'mechanism_counts':dict(sorted(Counter(x['primary_family'] for x in rows).items())),
        'official_accepted':None,
        'rows':rows,
    }


def choose_diverse(assessment, count, seed=42):
    rows=assessment['rows']
    if count<1 or count>len(rows):raise TaskError('INVALID_COUNT',f'count={count}, available={len(rows)}')
    eligible=[r for r in rows if r['recipe_status']=='REGISTERED_RECIPE_MATCHED']
    if len(eligible)<count:
        raise TaskError('INSUFFICIENT_REGISTERED_RECIPES',f'need {count}, have {len(eligible)}')
    rng=random.Random(seed)
    # First cover distinct mechanisms, then maximize additional app diversity.
    order=list(eligible)
    rng.shuffle(order)
    chosen=[]; used_cves=set(); seen_family=set(); seen_app=set()
    while len(chosen)<count:
        avail=[x for x in order if x['cve'] not in used_cves]
        if not avail:break
        best=max(avail,key=lambda x:(
            int(x['primary_family'] not in seen_family),
            int(x['app'].lower() not in seen_app),
            -sum(1 for z in chosen if z['primary_family']==x['primary_family']),
            -sum(1 for z in chosen if z['app']==x['app']),
        ))
        chosen.append(best)
        used_cves.add(best['cve']);seen_family.add(best['primary_family']);seen_app.add(best['app'].lower())
    return chosen,[x for x in rows if x['cve'] not in used_cves]


def write_matrix(out, assessment, *, choose=None, seed=42):
    out=Path(out).expanduser().resolve();out.mkdir(parents=True,exist_ok=True)
    json_write(out/'mechanism_matrix.json',assessment)
    if choose is not None:
        selected,holdout=choose_diverse(assessment,choose,seed)
        (out/'selected_cves.txt').write_text(''.join(x['cve']+'\n' for x in selected),encoding='utf-8')
        (out/'holdout_cves.txt').write_text(''.join(x['cve']+'\n' for x in holdout),encoding='utf-8')
        json_write(out/'selection.json',{
            'status':'MECHANISM_STRATIFIED_SELECTION_NOT_EXECUTED',
            'seed':seed,'selected':[{'cve':x['cve'],'app':x['app'],'family':x['primary_family']} for x in selected],
            'holdout_count':len(holdout),'selection_rule':'maximize family diversity then app diversity',
            'leakage_guard':'no result-dependent cherry-picking; holdout remains separate'})
    return out
