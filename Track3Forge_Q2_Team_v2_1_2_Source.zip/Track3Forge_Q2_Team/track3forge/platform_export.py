"""Docker archive platform selection. No pull, retag or container execution."""
import os, re, tarfile, json
from pathlib import Path
from .core import TaskError, budget_seconds
from .archive import _members, _manifest, _read_member


def platform_of(obj):
    if not isinstance(obj, dict):
        return None
    os_name = obj.get('os') or obj.get('Os') or obj.get('OS')
    arch = obj.get('architecture') or obj.get('Architecture')
    if not isinstance(os_name, str) or not isinstance(arch, str):
        return None
    value = os_name + '/' + arch
    if not re.fullmatch(r'[a-z0-9_]+/[a-z0-9_]+', value) or 'unknown' in value:
        return None
    # Variant matters for 32-bit ARM, and for non-default ARM64 variants.
    variant = obj.get('variant') or obj.get('Variant')
    if variant and not (arch == 'arm64' and variant == 'v8'):
        if not isinstance(variant, str) or not re.fullmatch(r'[a-z0-9_]+', variant):
            return None
        value += '/' + variant
    if arch == 'arm' and not variant:
        return None
    return value


def runtime_platform(inspect):
    desc = inspect.get('ImageManifestDescriptor') or {}
    return platform_of(desc.get('platform') or desc.get('Platform'))


def normalized(ref):
    if not ref or ref.startswith('sha256:') or '@' in ref:
        return ref
    return ref if ':' in ref.rsplit('/', 1)[-1] else ref + ':latest'


def archive_platforms(archive, refs):
    result = {ref: set() for ref in refs}
    try:
        with tarfile.open(archive, 'r:*') as tar:
            members = _members(tar)
            for entry in _manifest(tar, members):
                tags = {normalized(t) for t in entry.get('RepoTags') or []}
                matching = [ref for ref in refs if normalized(ref) in tags]
                if matching:
                    cfg = json.loads(_read_member(tar, members, entry['Config']))
                    for ref in matching:
                        result[ref].add(platform_of(cfg))
    except (OSError, ValueError, tarfile.TarError) as exc:
        raise TaskError('ARCHIVE_PLATFORM_METADATA_INVALID', str(exc)) from exc
    return result


def missing_content(error):
    message = str(error).lower()
    return (getattr(error, 'code', None) == 'COMMAND_FAILED' and
            'content digest' in message and 'not found' in message)


def resolve_export_platform(states, metadata, override=None):
    # Prefer the platform of the container's actual manifest, not the host.
    # Never infer an unknown service's platform from a different service.
    candidates = {}
    for state in states.values():
        ref = state['image_ref']
        runtime = state.get('runtime_platform')
        meta = metadata.get(ref, {})
        # Tag inspection may report a different platform variant. Trust it
        # only if the ID matches the running container's image reference.
        hint = (platform_of(meta) if state.get('image_id') and
                state.get('image_id') == meta.get('Id') else None)
        selected = runtime or hint or override
        if not selected:
            raise TaskError('EXPORT_PLATFORM_UNRESOLVED', f'{ref}: no platform evidence; inspect running manifest or set explicit operator platform')
        if override and selected != override:
            raise TaskError('EXPORT_PLATFORM_CONFLICT', f'{ref}: {selected} differs from explicit {override}')
        if ref in candidates and candidates[ref] != selected:
            raise TaskError('EXPORT_MIXED_PLATFORM_UNSUPPORTED', f'{ref}: multiple running platforms')
        candidates[ref] = selected
    if len(set(candidates.values())) != 1:
        raise TaskError('EXPORT_MIXED_PLATFORM_UNSUPPORTED', 'No automatic homogeneous export for mixed platforms')
    chosen = next(iter(candidates.values()))
    if not re.fullmatch(r'[a-z0-9_]+/[a-z0-9_]+(?:/[a-z0-9_]+)?', chosen):
        raise TaskError('EXPORT_PLATFORM_UNRESOLVED', repr(chosen))
    return chosen


def save_candidate(runner, artifact, refs, states, metadata, deadline, budget):
    artifact = Path(artifact)
    def save(platform=None):
        args = ['docker', 'save']
        if platform:
            args += ['--platform', platform]
        args += ['-o', str(artifact), *refs]
        runner.run(args, timeout=budget_seconds(deadline, max(1, budget)))
    try:
        save()
        return {'mode': 'DEFAULT', 'platform': None}
    except TaskError as exc:
        if not missing_content(exc):
            raise
        original_error = str(exc)
    artifact.unlink(missing_ok=True)
    override = os.environ.get('TRACK3_EXPORT_PLATFORM') or None
    chosen = resolve_export_platform(states, metadata, override)
    # A local-only inspect with explicit platform must resolve every reference.
    for ref in refs:
        obj = json.loads(runner.run(['docker','image','inspect','--platform',chosen,ref],
                  timeout=budget_seconds(deadline,20)).stdout)[0]
        if not obj.get('Id'):
            raise TaskError('EXPORT_PLATFORM_UNRESOLVED', ref)
        observed = platform_of(obj)
        if observed and observed != chosen:
            raise TaskError('EXPORT_PLATFORM_CONFLICT', ref)
    try:
        save(chosen)
        actual = archive_platforms(artifact, refs)
        if any(platforms != {chosen} for platforms in actual.values()):
            raise TaskError('EXPORT_ARCHIVE_PLATFORM_MISMATCH', repr(actual))
    except Exception:
        artifact.unlink(missing_ok=True)
        raise
    return {'mode':'EXPLICIT_PLATFORM_FALLBACK', 'platform':chosen, 'original_error':original_error}


def save_identity_check(runner, original, image, new):
    try:
        runner.run(['docker','save','-o',str(new),image],timeout=180)
    except TaskError as exc:
        if not missing_content(exc):
            raise
        platforms = archive_platforms(original, [image])[image]
        if len(platforms) != 1 or None in platforms:
            raise TaskError('VERIFY_ARCHIVE_PLATFORM_UNRESOLVED', image) from exc
        platform = next(iter(platforms))
        Path(new).unlink(missing_ok=True)
        runner.run(['docker','save','--platform',platform,'-o',str(new),image],timeout=180)
        if archive_platforms(new, [image])[image] != {platform}:
            raise TaskError('VERIFY_ARCHIVE_PLATFORM_MISMATCH', image)
