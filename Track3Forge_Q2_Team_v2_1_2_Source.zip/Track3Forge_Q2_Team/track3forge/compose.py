"""Q2: deterministic exact-recipe Compose sandbox and export, not an exploit generator.
Docker execution is opt-in. Source repo is untrusted; lab VM recommended.
"""
from __future__ import annotations
import copy, json, os, re, shutil, time, uuid, hashlib
from pathlib import Path
from .core import TaskError,Executor,json_write,sha256_file,safe_name,within,budget_seconds,now_id
from .archive import inventory
from .catalog import find_recipes
from .platform_export import runtime_platform, save_candidate

FORBIDDEN_KEYS={'privileged','devices','device_cgroup_rules','cap_add','pid','ipc','cgroup','cgroup_parent','uts','security_opt'}

def sanitize(config, source_root, *, service_memory="2g"):
    if not isinstance(config,dict) or not isinstance(config.get('services'),dict) or not config['services']:
        raise TaskError('COMPOSE_INVALID','No services')
    if not re.fullmatch(r'[1-9][0-9]{0,3}(?:m|g)',service_memory):
        raise TaskError('INVALID_MEMORY_LIMIT',f'Expected e.g. 512m or 2g, got {service_memory}')
    out=copy.deepcopy(config)
    root=Path(source_root).resolve()
    flags=[]
    for name,service in out['services'].items():
        if not isinstance(service,dict): raise TaskError('COMPOSE_INVALID',name)
        for k in FORBIDDEN_KEYS:
            if service.get(k): raise TaskError('COMPOSE_UNSAFE',f'{name}.{k}')
        if service.get('network_mode') or service.get('network_mode')== 'host':
            raise TaskError('COMPOSE_UNSAFE',f'{name}.network_mode')
        if service.get('volumes_from') or service.get('secrets') or service.get('configs'):
            raise TaskError('COMPOSE_UNSAFE',f'{name}: external secrets/configs/volumes_from')
        if service.get('ports'): flags.append('HOST_PORTS_REMOVED')
        service.pop('ports',None)
        if service.pop('container_name',None) is not None:
            flags.append('FIXED_CONTAINER_NAME_REMOVED')
        service.pop('extra_hosts',None)
        service.pop('dns',None)
        service.pop('dns_search',None)
        service.pop('links',None)
        service['networks']=['default']
        service['mem_limit']=service_memory
        service['pids_limit']=256
        if 'build' in service:
            b=service['build']
            ctx=b if isinstance(b,str) else b.get('context')
            if not ctx: raise TaskError('COMPOSE_INVALID',f'{name}: build context missing')
            if not within(Path(ctx),root):
                raise TaskError('SOURCE_PATH_OUTSIDE_ROOT',f'{name}: build context {ctx}')
            if isinstance(b,dict):
                dockerfile=b.get('dockerfile')
                if dockerfile:
                    df=Path(dockerfile) if Path(dockerfile).is_absolute() else Path(ctx)/dockerfile
                    if not within(df,root): raise TaskError('DOCKERFILE_OUTSIDE_SOURCE',str(df))
                if b.get('network') or b.get('entitlements') or b.get('additional_contexts'):
                    raise TaskError('COMPOSE_UNSAFE',f'{name}: build elevated/network features')
        for mount in service.get('volumes',[]) or []:
            if not isinstance(mount,dict): raise TaskError('COMPOSE_INVALID','volumes should be normalized by compose config')
            typ=mount.get('type')
            src=mount.get('source')
            if typ=='bind':
                if not src or not within(src,root): raise TaskError('UNSAFE_BIND_MOUNT',str(src))
                if not mount.get('read_only',False): flags.append('WRITABLE_BIND_MOUNT')
                flags.append('BIND_MOUNT_REQUIRES_PACKAGING')
            elif typ=='volume': flags.append('NAMED_VOLUME_DATA_NOT_EXPORTED')
            elif typ not in ('tmpfs',): raise TaskError('COMPOSE_UNSAFE',f'Unsupported volume: {typ}')
    out['networks']={'default':{'internal':True}}
    # Extra top-level fields from a canonical Compose model could reopen external config.
    for key in ('secrets','configs','include','extends'):
        if out.get(key): raise TaskError('COMPOSE_UNSAFE',f'top-level {key}')
        out.pop(key,None)
    # After replacing networks, externally attached volumes are forbidden.
    for k,v in (out.get('volumes') or {}).items():
        if isinstance(v,dict):
            if v.get('external'):
                raise TaskError('COMPOSE_UNSAFE',f'external volume {k}')
            if v.pop('name',None) is not None:
                flags.append('GLOBAL_VOLUME_NAME_PROJECT_SCOPED')
    out.pop('name',None)
    return out,sorted(set(flags))

def parse_compose(recipe, runner, *, deadline):
    p=runner.run(['docker','compose','-f',str(recipe),'config','--format','json'],
                 timeout=budget_seconds(deadline,40),cwd=str(recipe.parent))
    try: return json.loads(p.stdout)
    except ValueError as e: raise TaskError('COMPOSE_PARSE_FAILED',str(e)) from e

def _docker_state(inspect):
    state=inspect.get('State') or {}
    running=state.get('Running') is True
    health=(state.get('Health') or {}).get('Status')
    return {'running':running,'status':state.get('Status'),'exit_code':state.get('ExitCode'),
            'health':health,'image_ref':inspect.get('Config',{}).get('Image'),
            'image_id':inspect.get('Image'), 'runtime_platform':runtime_platform(inspect)}

def ready_services(states):
    return bool(states) and all(v['running'] and v['health'] in (None,'healthy') for v in states.values())

def inspect_services(runner, compose, project, services, deadline):
    states={}
    for service in services:
        result=runner.run(['docker','compose','-f',str(compose),'-p',project,'ps','-q',service],
                          timeout=budget_seconds(deadline,20))
        ids=[x.strip() for x in result.stdout.splitlines() if x.strip()]
        if len(ids)!=1:
            states[service]={'running':False,'status':'MISSING_OR_MULTIPLE','health':None}
            continue
        info=runner.run(['docker','inspect',ids[0]],timeout=budget_seconds(deadline,20))
        v=json.loads(info.stdout)
        states[service]=_docker_state(v[0]) if isinstance(v,list) and len(v)==1 else {'running':False,'status':'INSPECT_BAD'}
    return states

# Network classification is intentionally conservative: only clear transient
# transport failures are retried. Missing tags and rate limits remain failures.
def classify_compose_error(output):
    t=(output or '').lower()
    if any(k in t for k in ('toomanyrequests', '429 too many requests', 'rate limit exceeded')):
        return 'REGISTRY_RATE_LIMIT', False
    if any(k in t for k in ('manifest unknown', 'no matching manifest', 'pull access denied',
                            'repository does not exist', 'not found: manifest')):
        return 'IMAGE_UNAVAILABLE_OR_PLATFORM_MISMATCH', False
    transient=('unexpected eof', ' eof', ': eof', 'connection reset',
               'connection refused', 'tls handshake timeout', 'i/o timeout',
               'context deadline exceeded', 'client.timeout exceeded',
               'temporary failure', 'server misbehaving', 'no such host',
               'connection aborted', 'http2: client connection lost',
               '502 bad gateway', '503 service unavailable', '504 gateway timeout')
    if 'auth.docker.io' in t or 'failed to fetch oauth token' in t:
        if any(x in t for x in transient):
            return 'REGISTRY_AUTH_NETWORK_TRANSIENT', True
        return 'REGISTRY_AUTH_FAILURE', False
    if any(x in t for x in transient) and any(x in t for x in
           ('pulling', 'downloading', 'failed to resolve', 'failed to fetch', 'registry',
            'docker.io', 'failed to copy', 'failed to solve')):
        return 'REGISTRY_TRANSFER_TRANSIENT', True
    if 'no space left on device' in t:
        return 'DISK_EXHAUSTED', False
    if 'permission denied' in t:
        return 'PERMISSION_DENIED', False
    return 'COMPOSE_UP_FAILED', False


def compose_up_with_retries(runner, args, out, deadline):
    """Retry *only* transport failures and keep each attempt's complete tail.

    Up is Compose-idempotent within the same unique project. Never add a new
    image tag, rewrite the CVE recipe, or turn an error into a success.
    """
    history=[]
    for n in range(1,4):
        started=time.monotonic()
        timed_out=False
        try:
            res=runner.run(args,timeout=budget_seconds(deadline, max(1,int(deadline-time.monotonic()))),check=False)
            code=res.returncode
            output=(getattr(res,'stdout','') or '')+'\n'+(getattr(res,'stderr','') or '')
        except TaskError as exc:
            if exc.code=='TIMEOUT':
                # A Docker deadline is not a registry retry signal. Preserve
                # its partial stdout/stderr, then fail closed without retrying.
                timed_out=True
                code=124
                output=(getattr(exc,'partial_stdout','') or '')+'\n'+(getattr(exc,'partial_stderr','') or '')
                if not output.strip():
                    output='DOCKER_COMPOSE_UP_TIMEOUT_WITHOUT_CAPTURED_OUTPUT'
            elif exc.code=='COMMAND_FAILED':
                code=1
                output=str(exc)
            else:
                raise
        if len(output)>120000:
            output=output[:12000]+'\n...OUTPUT_TRUNCATED...\n'+output[-108000:]
        log=out/f'compose_up_attempt_{n}.log'
        log.write_text(output,encoding='utf-8')
        os.chmod(log,0o600)
        issue,transient=(('COMPOSE_UP_TIMEOUT',False) if timed_out else
                         (classify_compose_error(output) if code else ('NONE',False)))
        attempt={'attempt':n,'exit_code':code,'classification':issue,'retryable':transient,
                 'timed_out':timed_out,
                 'elapsed_seconds':round(time.monotonic()-started,2),'log':str(log)}
        history.append(attempt)
        json_write(out/'compose_up_attempts.json',history)
        if code==0:return history
        remaining=deadline-time.monotonic()
        if not transient or n==3 or remaining<12:
            raise TaskError(issue, f'Compose up attempt {n} exit={code}; '
                              f'log={log}; final_error={output[-950:]}')
        print(f'DOCKER_RETRY={n}/2 REASON={issue} NEXT=RETRY_SAME_RECIPE',flush=True)
        time.sleep(min(2*n, max(0,remaining-9)))
    raise TaskError('COMPOSE_UP_FAILED','Retry budget exhausted')


def snapshot_static_binds(model, root):
    """Only source-tree regular files can be self-contained delivery assets."""
    result={}
    root=Path(root).resolve()
    for service, cfg in model['services'].items():
        for index, mount in enumerate(cfg.get('volumes',[]) or []):
            if mount.get('type')!='bind':continue
            src=Path(mount['source'])
            key=(service,index)
            try:
                resolved=src.resolve(strict=True)
                if not within(resolved,root) or src.is_symlink() or not resolved.is_file():
                    result[key]={'reason':'NOT_SOURCE_TREE_REGULAR_FILE'};continue
                if resolved.stat().st_size>1024*1024:
                    result[key]={'reason':'FILE_TOO_LARGE_FOR_STATIC_BUNDLE'};continue
                if any(x in resolved.name.lower() for x in ('.env','secret','password','private','token','.key','.pem')):
                    result[key]={'reason':'SENSITIVE_FILENAME_REQUIRES_REVIEW'};continue
                result[key]={'path':resolved,'sha256':sha256_file(resolved),'size':resolved.stat().st_size}
            except (OSError,RuntimeError):
                result[key]={'reason':'BIND_SOURCE_NOT_ACCESSIBLE'}
    return result


def bundle_static_binds(model, before, out):
    """Copy unchanged static bind files into the deliverable's own directory.

    Mutable directories, named volumes, unexpected symlinks and changed inputs
    are NOT silently copied: report explicit portability blockers instead.
    """
    portable=copy.deepcopy(model)
    copies=[];blockers=[]
    for service, cfg in portable['services'].items():
        for index,mount in enumerate(cfg.get('volumes',[]) or []):
            kind=mount.get('type')
            if kind=='volume':
                blockers.append({'service':service,'mount_index':index,'kind':'NAMED_VOLUME',
                                 'reason':'RUNTIME_VOLUME_DATA_NOT_EXPORTED'})
                continue
            if kind!='bind':continue
            item=before.get((service,index),{})
            if 'path' not in item:
                blockers.append({'service':service,'mount_index':index,'kind':'BIND',
                                 'reason':item.get('reason','UNSNAPSHOTTED')})
                continue
            src=item['path']
            try:
                if not src.is_file() or src.is_symlink() or sha256_file(src)!=item['sha256']:
                    raise ValueError('BIND_CHANGED_DURING_EXECUTION')
                rel=Path('delivery_bind_assets')/safe_name(service,45)/(str(index)+'-'+safe_name(src.name,60))
                dst=out/rel
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(src,dst)
                if sha256_file(dst)!=item['sha256']:
                    raise ValueError('COPIED_BIND_DIGEST_MISMATCH')
                # Compose resolves relative bind paths next to portable.compose.json.
                mount['source']='./'+rel.as_posix()
                copies.append({'service':service,'mount_index':index,'relative_path':str(rel),
                               'sha256':item['sha256'],'size_bytes':item['size']})
            except (OSError,ValueError) as exc:
                blockers.append({'service':service,'mount_index':index,'kind':'BIND',
                                 'reason':str(exc)[:120]})
    json_write(out/'delivery_assets.json',{'packaged_static_binds':copies,
                                            'portability_blockers':blockers})
    return portable,copies,blockers


def candidate_run(cve, recipe, source_root, out, *, execute=False, acknowledge=False,
                  runner=None, budget=600, keep=False, service_memory='2g'):
    runner=runner or Executor()
    recipe=Path(recipe).resolve(); source_root=Path(source_root).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    deadline=time.monotonic()+max(1,budget);project='t3'+uuid.uuid4().hex[:10]
    data={'cve':cve,'recipe':str(recipe),'status':'STARTED','project':project,
          'started_at':time.time(),'checks':[],'errors':[]}
    sanitized=out/'isolated.compose.json'
    try:
        data['phase']='PARSE_COMPOSE'
        raw=parse_compose(recipe,runner,deadline=deadline)
        model,flags=sanitize(raw,source_root,service_memory=service_memory)
        model['name']=project
        json_write(sanitized,model)
        data['flags']=flags;data['checks'].append('COMPOSE_PARSED_AND_ISOLATED')
        data['services_declared']=sorted(model['services'])
        # Build-only Vulhub recipes have no stable image name. Assign a
        # project-scoped explicit tag before Compose builds or exports them.
        # Never overwrite a source-specified image/version.
        for service_name, service in model['services'].items():
            if service.get('build') and not service.get('image'):
                service['image'] = ('track3forge-local/' + project + '-' +
                                    safe_name(service_name).lower() + ':build')
                flags.append('BUILD_ONLY_IMAGE_TAG_ASSIGNED')
        data['flags']=sorted(set(flags))
        json_write(sanitized,model)
        if not execute:
            data['status']='RECIPE_FOUND_NOT_RUN';return data
        if not acknowledge: raise TaskError('LAB_ACK_REQUIRED','Execution requires --ack-lab')
        bind_before=snapshot_static_binds(model,source_root)
        for image in (model.get('services') or {}).values():
            if image.get('pull_policy')=='always': image.pop('pull_policy',None)
        json_write(sanitized,model)
        data['phase']='COMPOSE_UP'
        data['compose_up_attempts_file']=str(out/'compose_up_attempts.json')
        data['compose_up_attempts']=compose_up_with_retries(
            runner,['docker','compose','-f',str(sanitized),'-p',project,
                    'up','-d','--build','--remove-orphans','--pull','missing'],out,deadline)
        data['phase']='WAIT_SERVICES'
        states={}
        while True:
            states=inspect_services(runner,sanitized,project,data['services_declared'],deadline)
            if ready_services(states):break
            if time.monotonic()>deadline-3: raise TaskError('SERVICE_NOT_READY',str(states)[:1000])
            # Exited non-zero cannot recover through waiting.
            if any(x.get('status')=='exited' and x.get('exit_code',0)!=0 for x in states.values()):
                raise TaskError('SERVICE_EXITED',str(states)[:1000])
            time.sleep(2)
        data['services']=states;data['checks'].append('ALL_SERVICES_RUNNING_AND_HEALTHY')
        data['phase']='EXPORT_IMAGES'
        refs=sorted({v.get('image_ref') for v in states.values() if v.get('image_ref')})
        if len(refs)==0 or any(not v.get('image_ref') for v in states.values()):
            raise TaskError('IMAGE_REFERENCE_MISSING','Container image ref not available')
        before={}; image_metadata={}
        for ref in refs:
            p=runner.run(['docker','image','inspect',ref],timeout=budget_seconds(deadline,20))
            info=json.loads(p.stdout)[0]
            before[ref]=info['Id']; image_metadata[ref]=info
        artifact=out/(cve+'-docker-images.tar')
        data['export_platform']=save_candidate(runner,artifact,refs,states,image_metadata,deadline,budget)
        for ref,original in before.items():
            info=json.loads(runner.run(['docker','image','inspect',ref],timeout=budget_seconds(deadline,20)).stdout)[0]
            if info['Id']!=original: raise TaskError('IMAGE_CHANGED_DURING_EXPORT',ref)
        inv=inventory(artifact)
        if inv['status']!='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF':
            raise TaskError('ARTIFACT_INVALID',str(inv['status']))
        data['checks']+=['EXPORTED_ALL_IMAGES','ARCHIVE_MANIFEST_VERIFIED','IMAGE_TAGS_STABLE']
        data['phase']='PACKAGE_ASSETS'
        portable,copied,blockers=bundle_static_binds(model,bind_before,out)
        for svc,state in states.items():
            portable['services'][svc]['image']=state['image_ref']
            if data['export_platform']['platform']:
                portable['services'][svc]['platform']=data['export_platform']['platform']
            portable['services'][svc].pop('build',None)
        if copied:data['checks'].append('UNCHANGED_SOURCE_BIND_FILES_BUNDLED')
        data['delivery_assets']=str(out/'delivery_assets.json')
        data['delivery_blockers']=blockers
        json_write(out/'portable.compose.json',portable)
        json_write(out/'image_inventory.json',inv)
        data['phase']='DELIVERY_EXPORTED'
        data.update(status='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',artifact=str(artifact),
                    archive_sha256=inv['sha256'],images=refs,
                    delivery_ready=False, verified_vulnerability=False,
                    portability='SOURCE_OR_VOLUME_REQUIRED' if blockers else 'REDEPLOY_NOT_TESTED')
        return data
    except (TaskError,ValueError,KeyError) as e:
        data.update(status='FAILED',error_code=getattr(e,'code','UNEXPECTED_RESPONSE'),error=str(e)[:1600]);return data
    finally:
        if execute:
            # Capture the *real* Compose diagnostics before project teardown.  These
            # files are local evidence, not model interpretations or CVE proof.
            try:
                logs=runner.run(['docker','compose','-f',str(sanitized),'-p',project,
                                 'logs','--no-color','--tail','100'],timeout=25,check=False)
                logfile=out/'compose.log'
                logfile.write_text((logs.stdout+'\n'+logs.stderr)[-40000:],encoding='utf-8')
                os.chmod(logfile,0o600)
                data['compose_log']=str(logfile)
            except (TaskError,OSError) as e:
                data['log_capture_error']=str(e)[:250]
        if execute and not keep:
            try:
                cleaned=runner.run(['docker','compose','-f',str(sanitized),'-p',project,
                                    'down','--remove-orphans','--volumes'],
                                   timeout=45,check=False)
                data['cleanup_status']='OK' if cleaned.returncode==0 else 'FAILED'
                if cleaned.returncode!=0:
                    data['cleanup_error']=cleaned.stderr[-400:]
            except (TaskError,OSError) as e:
                data['cleanup_status']='FAILED'
                data['cleanup_error']=str(e)[:400]
        data['seconds']=round(max(0,budget-(deadline-time.monotonic())),2)
        json_write(out/'result.json',data)

def process_cves(cves, source, output, *, runner=None, execute=False,acknowledge=False,budget=600,keep=False,service_memory='2g',total_budget=None):
    runner=runner or Executor();output=Path(output);output.mkdir(parents=True,exist_ok=True)
    summary={'requested':len(cves),'results':[],'verified_vulnerabilities':0}
    global_deadline=(time.monotonic()+total_budget) if total_budget is not None else None
    for cve in cves:
        if global_deadline is not None and time.monotonic()>=global_deadline:
            result={'cve':cve,'status':'GLOBAL_BUDGET_EXHAUSTED_NOT_RUN'}
            json_write(output/cve/'result.json',result)
            summary['results'].append({'cve':cve,'status':result['status'],'seconds':0,'artifact':None,'error_code':None})
            continue
        recipes=find_recipes(source,cve)
        if not recipes:
            result={'cve':cve,'status':'NO_RECIPE','errors':['No exact CVE directory with Compose file']}
            json_write(output/cve/'result.json',result)
        else:
            # Explicitly handle the first exact recipe; never quietly try different projects.
            remaining=(max(1,int(global_deadline-time.monotonic())) if global_deadline is not None else budget)
            result=candidate_run(cve,recipes[0],source,output/cve,execute=execute,
                  acknowledge=acknowledge,runner=runner,budget=min(budget,remaining),keep=keep,service_memory=service_memory)
            result['matches']=[str(r) for r in recipes]
            json_write(output/cve/'result.json',result)
        summary['results'].append({'cve':cve,'status':result['status'],
                                   'seconds':result.get('seconds',0),'artifact':result.get('artifact'),
                                   'error_code':result.get('error_code')})
    summary['exported_real_docker']=sum(x['status']=='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF' for x in summary['results'])
    json_write(output/'summary.json',summary)
    return summary

def redeploy_check(case_dir, *, runner=None, allow_load=False, budget=180):
    """Fresh project redeploy of an exported candidate. Does not imply CVE proof.
    Keeps named-volume or bind-mount cases in DELIVERY_BLOCKED, no data invented.
    """
    runner=runner or Executor();case=Path(case_dir)
    if not (case/'result.json').is_file():raise TaskError('MISSING_CASE_RESULT',str(case))
    try:report=json.loads((case/'result.json').read_text(encoding='utf-8'))
    except ValueError as e:raise TaskError('BAD_CASE_RESULT',str(e)) from e
    if report.get('status')!='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
        raise TaskError('NOT_AN_EXPORTED_CASE','Only exported candidates may be redeployed')
    if report.get('portability')!='REDEPLOY_NOT_TESTED':
        raise TaskError('PORTABILITY_UNRESOLVED','Bind mounts / named-volume data not included')
    config=case/'portable.compose.json'; image_archive=Path(report['artifact'])
    if not config.is_file() or not image_archive.is_file():
        raise TaskError('MISSING_DELIVERY_FILE','Missing image archive or portable compose')
    from .verify import assert_archive_tag
    for image in report.get('images',[]):
        assert_archive_tag(image_archive,image,runner,allow_load=allow_load)
    project='t3check'+uuid.uuid4().hex[:9]
    deadline=time.monotonic()+budget
    receipt={'status':'FAILED','case':str(case),'project':project,
             'image_archive_sha256':sha256_file(image_archive),'checks':[],
             'fresh_project':True,'image_store_clean':False}
    started=False
    try:
        cfg=json.loads(config.read_text(encoding='utf-8'))
        if not cfg.get('networks',{}).get('default',{}).get('internal'):
            raise TaskError('PORTABILITY_UNSAFE','Portable compose lacks internal network')
        for svc in cfg['services'].values():
            if svc.get('build'): raise TaskError('PORTABILITY_UNSAFE','Portable compose still builds from source')
        runner.run(['docker','compose','-f',str(config),'-p',project,'up','-d','--no-build','--pull','never'],
                   timeout=budget_seconds(deadline,budget))
        started=True
        names=sorted(cfg['services'])
        while True:
            state=inspect_services(runner,config,project,names,deadline)
            if ready_services(state):break
            if any(v.get('status')=='exited' for v in state.values()):
                raise TaskError('REDEPLOY_SERVICE_EXITED',str(state)[:1200])
            if time.monotonic()>deadline-3:raise TaskError('REDEPLOY_TIMEOUT',str(state)[:1200])
            time.sleep(2)
        receipt.update(status='CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF',
                       checks=['ORIGINAL_ARCHIVE_TAG_CONFIG_MATCHED','FRESH_PROJECT_SERVICES_RUNNING'],
                       services=state,official_accepted=None,verified_vulnerability=False)
    except (TaskError,ValueError,KeyError) as e:
        receipt.update(error_code=getattr(e,'code','INVALID_RECEIPT'),error=str(e))
    finally:
        if started:
            try:runner.run(['docker','compose','-f',str(config),'-p',project,'down','--remove-orphans'],
                           timeout=45,check=False)
            except TaskError:pass
        json_write(case/'redeploy_result.json',receipt)
    return receipt
