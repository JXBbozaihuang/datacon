"""Track3Forge: explicit Q1/Q2 tasks, separate practice tests, evidence-first reports."""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
from . import __version__
from .core import TaskError,Executor,json_write,now_id
from . import archive,catalog,compose,llm,verify,service_check

BASE=Path(__file__).resolve().parent.parent

def print_result(data):
    print(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True))
    # Fail closed: unknown / incomplete status never prints PASSED=YES.
    passed={
      'DOCTOR_PASSED','OLLAMA_READY','OLLAMA_SMOKE_PASSED',
      'INTERNAL_SIDECAR_NETWORK_PASSED','PRACTICE_SAMPLE_GENERATED',
      'STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF',
      'IMAGE_ARCHIVE_RECOVERED_NOT_RUNTIME_PROOF',
      'DOCKER_ARCHIVE_ROUNDTRIP_CONFIG_MATCHED_NOT_CVE_PROOF',
      'BEHAVIOR_VERIFIED','CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF',
      'Q1_RUNTIME_DIAGNOSIS_ONLY',
    }
    print('PASSED=' + ('YES' if data.get('status') in passed else 'NO'))

def cmd_doctor(args):
    run=Executor()
    checks={}
    for label,cmd in [('docker',['docker','info','--format','{{.ServerVersion}}']),
                      ('compose',['docker','compose','version','--short'])]:
        try:
            p=run.run(cmd,timeout=20)
            checks[label]={'status':'OK','version':p.stdout.strip()}
        except TaskError as e: checks[label]={'status':'FAILED','reason':str(e)}
    try:
        models=llm.list_models()
        checks['ollama']={'status':'OK','models':models}
    except TaskError: checks['ollama']={'status':'UNAVAILABLE_OPTIONAL'}
    passed=all(checks[x]['status']=='OK' for x in ('docker','compose'))
    print_result({'status':'DOCTOR_PASSED' if passed else 'FAILED',
                  'checks':checks,'version':__version__,'gpu':'NO','training':'NO'})
    return 0 if passed else 2

def cmd_models(args):
    avail=llm.ensure_server(start=args.start)
    model=llm.choose_model(avail,args.model)
    if not model: raise TaskError('NO_QWEN_MODEL','No existing Qwen model; no model was downloaded')
    print_result({'status':'OLLAMA_READY','installed':avail,'model':model,'network':'127.0.0.1_ONLY'})
    if args.smoke:
        data=llm.diagnose(model,'Docker failed to find a local image in a lab. Error: image not found')
        print_result({'status':'OLLAMA_SMOKE_PASSED','advice':data})

def cmd_q1_inspect(args):
    result=archive.inventory(args.tar)
    if args.out: json_write(Path(args.out)/'q1_inspection.json',result)
    print_result(result)

def cmd_q1_recover(args):
    result=archive.recover(args.tar,args.donor,args.out)
    json_write(Path(args.out).with_suffix('.evidence.json'),result)
    print_result(result)

def cmd_q1_validate(args):
    if not args.ack_lab: raise TaskError('LAB_ACK_REQUIRED','Use --ack-lab')
    result=archive.docker_validate(Path(args.tar),allow_load=args.allow_load)
    if args.out:json_write(Path(args.out),result)
    print_result(result)

def cmd_q1_diagnose(args):
    if not args.ack_lab: raise TaskError('LAB_ACK_REQUIRED','Use --ack-lab')
    runner=Executor();name='t3q1-'+now_id().lower()
    result={'status':'Q1_RUNTIME_DIAGNOSIS_ONLY','image':args.image,'container':name,
            'verified_vulnerability':False,'diagnostics':[]}
    started=False
    try:
        p=runner.run(['docker','run','-d','--name',name,'--network','none','--cap-drop','ALL',
            '--security-opt','no-new-privileges','--memory','512m','--pids-limit','128',args.image],timeout=50)
        started=True;time.sleep(min(4,args.observe_seconds))
        inspect=runner.run(['docker','inspect',name],timeout=15)
        status=json.loads(inspect.stdout)[0].get('State',{})
        log=runner.run(['docker','logs','--tail','100',name],timeout=15,check=False)
        result.update(container_state=status,logs_tail=(log.stdout+'\n'+log.stderr)[-5000:])
    except TaskError as e:
        result.update(status='Q1_RUNTIME_DIAGNOSIS_FAILED',error_code=e.code,error=str(e))
    finally:
        if started: runner.run(['docker','rm','-f',name],timeout=20,check=False)
    if args.agent:
        try:
            models=llm.ensure_server(start=args.start_ollama)
            model=llm.choose_model(models,args.model)
            if model:result['agent_advice']=llm.diagnose(model,str(result.get('logs_tail',result.get('error',''))))
            else:result['agent_error']='NO_INSTALLED_QWEN_MODEL'
        except TaskError as e:result['agent_error']=f'{e.code}: {e}'
    json_write(args.out,result);print_result(result)
    return 0 if result['status']=='Q1_RUNTIME_DIAGNOSIS_ONLY' else 2

def _source(args):
    src=Path(args.source or BASE/'data'/'vulhub').expanduser().resolve()
    fetch_receipt=None
    if args.fetch:
        fetch_receipt=catalog.fetch_snapshot(src)
    if not src.is_dir():raise TaskError('SOURCE_MISSING',f'{src}: use --fetch or provide --source')
    return src,fetch_receipt

def _q2(args,*,execute):
    cves=catalog.read_cves(args.cves)
    if execute and not args.ack_lab: raise TaskError('LAB_ACK_REQUIRED','Use --ack-lab')
    src,receipt=_source(args)
    out=Path(args.out or BASE/'runs'/now_id()).resolve();out.mkdir(parents=True,exist_ok=True)
    summary=compose.process_cves(cves,src,out,execute=execute,acknowledge=args.ack_lab,budget=args.per_cve_seconds,service_memory=args.service_memory,total_budget=args.total_seconds)
    if receipt:summary['source_receipt']=receipt
    summary['source']=str(src)
    summary['official_accepted']=None
    summary['purpose']='competition' if execute else 'planning'
    json_write(out/'summary.json',summary)
    print('CVE                  STATUS                                 SECONDS  ARTIFACT')
    for x in summary['results']:
        print(f"{x['cve']:<21}{x['status']:<39}{x['seconds']:>7}  {x.get('artifact') or '-'}")
    print('SUMMARY='+json.dumps({k:v for k,v in summary.items() if k!='results'},ensure_ascii=False))
    print('OUTPUT='+str(out))
    print('GPU=NO TRAINING=NO DOCKER='+('YES' if execute else 'PLAN_ONLY'))
    if args.agent and execute:
        model=None
        try:
            installed=llm.ensure_server(start=args.start_ollama)
            model=llm.choose_model(installed,args.model)
        except TaskError as e: print('AGENT_UNAVAILABLE='+e.code)
        if model:
            for x in summary['results']:
                if x['status']!='FAILED':continue
                p=out/x['cve']/'result.json'
                data=json.loads(p.read_text())
                try:
                    advice=llm.diagnose(model,str(data.get('error','')))
                    json_write(out/x['cve']/'agent_advice.json',advice)
                    print('AGENT_ADVICE='+x['cve']+':'+json.dumps(advice,ensure_ascii=False))
                except TaskError as e: print('AGENT_ADVICE_FAILED='+x['cve']+':'+e.code)
    if any(x['status']=='FAILED' for x in summary['results']):return 2
    return 0

def cmd_pilot(args):
    # A deliberately bounded first real-Docker batch, not a 30-CVE proof run.
    from .pilot import run_pilot
    selected = catalog.read_cves(args.cves)
    source, _ = _source(args)
    out = Path(args.out or BASE / 'runs' / ('pilot-' + now_id()))
    summary = run_pilot(
        selected, source, out, limit=args.limit,
        per_cve_seconds=args.per_cve_seconds,
        total_seconds=args.total_seconds,
        redeploy_seconds=args.redeploy_seconds,
        service_memory=args.service_memory,
        ack_lab=args.ack_lab, agent=args.agent,
        start_ollama=args.start_ollama, model=args.model,
        min_disk_gb=args.min_disk_gb,
    )
    print('SUMMARY=' + json.dumps({k:v for k,v in summary.items() if k != 'cases'}, ensure_ascii=False))
    print('OUTPUT=' + str(out.resolve()))
    print('GPU=NO TRAINING=NO DOCKER=YES VERIFIED_VULNERABILITIES=0')
    print('NEXT=Inspect pilot_summary.csv and case/compose.log; verify only CVEs with an audited oracle')
    return 2 if (summary['failed'] or summary['exported_real_docker'] == 0) else 0

def cmd_redeploy(args):
    if not args.ack_lab: raise TaskError('LAB_ACK_REQUIRED','Redeployment requires --ack-lab')
    result=compose.redeploy_check(args.case,allow_load=args.allow_load,budget=args.budget)
    print_result(result)
    return 0 if result['status']=='CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF' else 2

def cmd_service_check(args):
    if not args.ack_lab:
        raise TaskError('LAB_ACK_REQUIRED', 'Service checks require --ack-lab')
    if args.case:
        d=service_check.check_case(args.case,budget=args.budget,apache_canary=args.apache_canary)
        print_result(d)
        print('EVIDENCE='+str(Path(args.case).resolve()/'service_check.json'))
        return 0 if d['status'] in (
            'APPLICATION_RESPONDED_NOT_CVE_PROOF',
            'OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF',
            'GENERIC_TCP_REACHABLE_NOT_CVE_PROOF') else 2
    d=service_check.check_pilot(args.pilot,budget=args.budget,apache_canary=args.apache_canary)
    print('CVE                  SERVICE_STATUS                         ERROR')
    for row in d['cases']:
        print(f"{row['cve']:<21}{row['status']:<39}{row.get('error_code') or '-'} CANARY={row.get('canary_status') or '-'}")
    print('SUMMARY='+json.dumps({k:v for k,v in d.items() if k!='cases'},ensure_ascii=False))
    print('EVIDENCE='+str(Path(args.pilot).resolve()/'service_summary.json'))
    print('GPU=NO TRAINING=NO DOCKER=YES CVE_VERIFIED=0')
    return 0 if d['count'] and d['service_passed']==d['count'] else 2


def cmd_verify_case(args):
    if not args.ack_lab:
        raise TaskError('LAB_ACK_REQUIRED', 'Verification requires --ack-lab')
    case=Path(args.case).expanduser().resolve()
    data=json.loads((case/'result.json').read_text(encoding='utf-8'))
    cve=catalog.validate_cve(data['cve'])
    if data.get('status')!='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
        raise TaskError('CASE_NOT_EXPORTED','Candidate has no validated image export')
    if cve not in verify.BUILTIN_AUDITED:
        raise TaskError('ORACLE_NOT_IMPLEMENTED',f'{cve}: no audited positive/fixed oracle')
    # Resolve the exact image from saved metadata, never from a model response.
    svc=list((data.get('services') or {}).values())
    refs=sorted({s['image_ref'] for s in svc if s.get('image_ref')})
    if len(refs)!=1:
        raise TaskError('UNEXPECTED_IMAGE_COUNT',repr(refs))
    out=Path(args.out).resolve() if args.out else case/'proof'/'known'
    d=verify.verify_known(cve,Path(data['artifact']),refs[0],out,
        fixed_image=args.fixed_image,allow_pull=args.allow_pull,allow_load=False)
    print_result(d)
    print('EVIDENCE='+str(out/'known_proof.json'))
    return 0 if d['status']=='BEHAVIOR_VERIFIED' else 2


def cmd_verify_apache_case(args):
    if not args.ack_lab:
        raise TaskError('LAB_ACK_REQUIRED', 'Apache differential verification requires --ack-lab')
    from .apache_proof import verify_apache_case
    d=verify_apache_case(args.case, allow_pull=args.allow_pull, budget=args.budget)
    print_result(d)
    print('EVIDENCE='+str(Path(args.case).resolve()/'proof'/'apache'/'apache_proof.json'))
    return 0 if d.get('vulnerability_verified') is True else 2


def cmd_verify_activemq_case(args):
    if not args.ack_lab:
        raise TaskError('LAB_ACK_REQUIRED', 'ActiveMQ internal lab verification requires --ack-lab')
    from .activemq_proof import verify_activemq_case
    d=verify_activemq_case(args.case, allow_pull=args.allow_pull, budget=args.budget)
    print_result(d)
    print('EVIDENCE='+str(Path(args.case).resolve()/'proof'/'activemq'/'activemq_proof.json'))
    print('GPU=NO TRAINING=NO DOCKER=YES')
    return 0 if d.get('vulnerability_verified') is True else 2


def cmd_mechanism_matrix(args):
    """Classify an arbitrary CVE list using the checked local Vulhub registry."""
    from . import mechanism
    source,_=_source(args)
    cves=catalog.read_cves(args.cves)
    assessment=mechanism.assess(cves,source,pilot=args.pilot)
    out=Path(args.out or BASE/'runs'/('matrix-'+now_id())).resolve()
    mechanism.write_matrix(out,assessment,choose=args.select,seed=args.seed)
    print('CVE                  FAMILY                       RECIPE                     ORACLE              PROOF')
    for r in assessment['rows']:
        print(f"{r['cve']:<21}{r['primary_family']:<29}{r['recipe_status']:<27}{r['oracle_status']:<20}{r['proof']['status']}")
    print('SUMMARY='+json.dumps({k:v for k,v in assessment.items() if k!='rows'},ensure_ascii=False))
    print('OUTPUT='+str(out))
    if args.select is not None:
        print('SELECTED='+str(out/'selected_cves.txt'))
        print('HOLDOUT='+str(out/'holdout_cves.txt'))
        print('NEXT=bash START.sh q2 pilot --cves "'+str(out/'selected_cves.txt')+'" --source "'+str(source)+'" --ack-lab --limit '+str(args.select))
    print('GPU=NO TRAINING=NO DOCKER=NO CVE_PROOF_EXECUTED=NO')
    return 0

def cmd_discover(args):
    src,receipt=_source(args)
    cves=catalog.read_cves(args.cves)
    records=[]
    for cve in cves:
        recipes=catalog.find_recipes(src,cve)
        records.append({'cve':cve,'status':'RECIPE_FOUND_NOT_RUN' if recipes else 'NO_RECIPE',
                        'recipes':[str(x) for x in recipes]})
    out=Path(args.out or BASE/'runs'/now_id())
    out.mkdir(parents=True,exist_ok=True)
    result={'status':'DISCOVERY_FINISHED_NOT_CVE_PROOF','count':len(records),
            'recipes_found':sum(bool(x['recipes']) for x in records),
            'source':str(src),'source_receipt':receipt,'cases':records}
    json_write(out/'discovery.json',result)
    print('CVE                  STATUS                    RECIPES')
    for x in records:print(f"{x['cve']:<21}{x['status']:<26}{len(x['recipes'])}")
    print('OUTPUT='+str(out))
    print('GPU=NO TRAINING=NO DOCKER=NO')

def cmd_sample(args):
    src,receipt=_source(args)
    cves=catalog.sample_recipes(src,count=args.count,seed=args.seed)
    out=Path(args.out or BASE/'examples'/'generated-practice.txt')
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text('\n'.join(cves)+'\n',encoding='utf-8')
    info={'status':'PRACTICE_SAMPLE_GENERATED','count':len(cves),'path':str(out),
          'source':str(src),'seed':args.seed,'source_receipt':receipt}
    print_result(info)

def cmd_verify(args):
    if not args.ack_lab: raise TaskError('LAB_ACK_REQUIRED','Verification requires --ack-lab')
    d=verify.verify_known(catalog.validate_cve(args.cve),Path(args.artifact),args.image,args.out,
        fixed_image=args.fixed_image,allow_pull=args.allow_pull,allow_load=args.allow_load)
    print_result(d)
    print('EVIDENCE='+str(Path(args.out)/'known_proof.json'))
    return 0 if d['status']=='BEHAVIOR_VERIFIED' else 2

def cmd_network_smoke(args):
    """Actual two-container internal-network smoke. No published ports."""
    import uuid
    run=Executor(); network='t3smoke-'+uuid.uuid4().hex[:10]
    name='t3server-'+uuid.uuid4().hex[:10]
    images=['python:3.12-alpine',verify.CURL_IMAGE]
    if args.allow_pull:
        for img in images:
            r=run.run(['docker','image','inspect',img],timeout=20,check=False)
            if r.returncode!=0:run.run(['docker','pull',img],timeout=180)
    for img in images:
        r=run.run(['docker','image','inspect',img],timeout=20,check=False)
        if r.returncode!=0:raise TaskError('SMOKE_IMAGE_MISSING',f'docker pull {img} or --allow-pull')
    network_created=False;server_created=False
    try:
        run.run(['docker','network','create','--internal',network],timeout=30)
        network_created=True
        run.run(['docker','run','-d','--name',name,'--network',network,'--network-alias','server',
                 '--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','64',
                 '--memory','128m','python:3.12-alpine','python','-m','http.server','8000',
                 '--bind','0.0.0.0'],timeout=40)
        server_created=True
        last=''
        for i in range(15):
            p=run.run(['docker','run','--rm','--network',network,'--entrypoint','curl',verify.CURL_IMAGE,
                     '--noproxy','*','--silent','--show-error','--max-time','3','--write-out',
                     '__T3:%{http_code}','http://server:8000/'],timeout=15,check=False)
            if p.returncode==0 and '__T3:200' in p.stdout:
                print_result({'status':'INTERNAL_SIDECAR_NETWORK_PASSED','network':network,
                  'host_ports_published':False,'target':'server:8000','probe':'curl container'})
                return 0
            last=p.stderr[-300:];time.sleep(1)
        raise TaskError('INTERNAL_NETWORK_SMOKE_FAILED',last or 'No 200 after 15 attempts')
    finally:
        if server_created:run.run(['docker','rm','-f',name],timeout=20,check=False)
        if network_created:run.run(['docker','network','rm',network],timeout=20,check=False)

def cmd_dashboard(args):
    from .dashboard import serve
    serve(args.runs,args.port)

def cmd_report(args):
    p=Path(args.path)
    if p.is_dir():p=p/'summary.json'
    data=json.loads(p.read_text(encoding='utf-8'))
    print('CVE                  STATUS                                 ARTIFACT')
    for x in data.get('results',[]):print(f"{x['cve']:<21}{x['status']:<39}{x.get('artifact') or '-'}")
    print('OUTPUT='+str(p))

def make_parser():
    ap=argparse.ArgumentParser(prog='track3',description='Track3Forge | Q1 damaged Docker archives, Q2 CVE environments')
    ap.add_argument('--version',action='version',version=__version__)
    sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('doctor');p.set_defaults(func=cmd_doctor)
    p=sub.add_parser('network-smoke');p.add_argument('--allow-pull',action='store_true');p.set_defaults(func=cmd_network_smoke)
    p=sub.add_parser('models');p.add_argument('--start',action='store_true');p.add_argument('--smoke',action='store_true');p.add_argument('--model');p.set_defaults(func=cmd_models)
    q1=sub.add_parser('q1');q1sub=q1.add_subparsers(dest='q1_cmd',required=True)
    p=q1sub.add_parser('inspect');p.add_argument('--tar',required=True);p.add_argument('--out');p.set_defaults(func=cmd_q1_inspect)
    p=q1sub.add_parser('recover');p.add_argument('--tar',required=True);p.add_argument('--donor',required=True);p.add_argument('--out',required=True);p.set_defaults(func=cmd_q1_recover)
    p=q1sub.add_parser('validate');p.add_argument('--tar',required=True);p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-load',action='store_true');p.add_argument('--out');p.set_defaults(func=cmd_q1_validate)
    p=q1sub.add_parser('diagnose');p.add_argument('--image',required=True);p.add_argument('--ack-lab',action='store_true');
    p.add_argument('--out',required=True);p.add_argument('--agent',action='store_true');p.add_argument('--start-ollama',action='store_true');p.add_argument('--model');p.add_argument('--observe-seconds',type=int,default=3);p.set_defaults(func=cmd_q1_diagnose)
    q2=sub.add_parser('q2');q2sub=q2.add_subparsers(dest='q2_cmd',required=True)
    for name,execute in (('plan',False),('run',True)):
        p=q2sub.add_parser(name);p.add_argument('--cves',required=True,help='CVE or TXT/CSV/JSON file')
        p.add_argument('--source',help='Local Vulhub or equivalent checked recipe directory');p.add_argument('--fetch',action='store_true')
        p.add_argument('--out');p.add_argument('--ack-lab',action='store_true');p.add_argument('--agent',action='store_true')
        p.add_argument('--start-ollama',action='store_true');p.add_argument('--model');p.add_argument('--per-cve-seconds',type=int,default=600);p.add_argument('--service-memory',default='2g');p.add_argument('--total-seconds',type=int)
        p.set_defaults(func=lambda a,e=execute:_q2(a,execute=e))
    p=q2sub.add_parser('pilot');p.add_argument('--cves',required=True,help='Explicit CVEs/TXT; only first --limit CVEs are run')
    p.add_argument('--source');p.add_argument('--fetch',action='store_true');p.add_argument('--out');p.add_argument('--limit',type=int,default=3)
    p.add_argument('--per-cve-seconds',type=int,default=300);p.add_argument('--total-seconds',type=int,default=1800)
    p.add_argument('--redeploy-seconds',type=int,default=180);p.add_argument('--service-memory',default='2g')
    p.add_argument('--min-disk-gb',type=int,default=2);p.add_argument('--ack-lab',action='store_true')
    p.add_argument('--agent',action='store_true');p.add_argument('--start-ollama',action='store_true')
    p.add_argument('--model');p.set_defaults(func=cmd_pilot)
    p=q2sub.add_parser('matrix');p.add_argument('--cves',required=True);p.add_argument('--source');p.add_argument('--fetch',action='store_true');p.add_argument('--pilot');p.add_argument('--out');p.add_argument('--select',type=int);p.add_argument('--seed',type=int,default=42);p.set_defaults(func=cmd_mechanism_matrix)
    p=q2sub.add_parser('discover');p.add_argument('--cves',required=True);p.add_argument('--source');p.add_argument('--fetch',action='store_true');p.add_argument('--out');p.set_defaults(func=cmd_discover)
    p=q2sub.add_parser('sample');p.add_argument('--source');p.add_argument('--fetch',action='store_true');p.add_argument('--count',type=int,default=30);p.add_argument('--seed',type=int,default=42);p.add_argument('--out');p.set_defaults(func=cmd_sample)
    p=q2sub.add_parser('redeploy');p.add_argument('--case',required=True);p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-load',action='store_true');p.add_argument('--budget',type=int,default=180);p.set_defaults(func=cmd_redeploy)
    p=q2sub.add_parser('service-check'); g=p.add_mutually_exclusive_group(required=True);g.add_argument('--case');g.add_argument('--pilot');p.add_argument('--ack-lab',action='store_true');p.add_argument('--budget',type=int,default=240);p.add_argument('--apache-canary',action='store_true');p.set_defaults(func=cmd_service_check)
    p=q2sub.add_parser('verify-apache-case');p.add_argument('--case',required=True);p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-pull',action='store_true');p.add_argument('--budget',type=int,default=360);p.set_defaults(func=cmd_verify_apache_case)
    p=q2sub.add_parser('verify-activemq-case');p.add_argument('--case',required=True);p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-pull',action='store_true');p.add_argument('--budget',type=int,default=480);p.set_defaults(func=cmd_verify_activemq_case)
    p=q2sub.add_parser('verify-case');p.add_argument('--case',required=True);p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-pull',action='store_true');p.add_argument('--fixed-image');p.add_argument('--out');p.set_defaults(func=cmd_verify_case)
    p=q2sub.add_parser('verify');p.add_argument('--cve',required=True);p.add_argument('--artifact',required=True)
    p.add_argument('--image',required=True,help='Exact image tag listed in exported archive');p.add_argument('--out',required=True)
    p.add_argument('--fixed-image');p.add_argument('--ack-lab',action='store_true');p.add_argument('--allow-pull',action='store_true');p.add_argument('--allow-load',action='store_true');p.set_defaults(func=cmd_verify)
    p=sub.add_parser('dashboard');p.add_argument('--runs',default=str(BASE/'runs'));p.add_argument('--port',type=int,default=8765);p.set_defaults(func=cmd_dashboard)
    p=sub.add_parser('report');p.add_argument('path');p.set_defaults(func=cmd_report)
    p=sub.add_parser('practice30');p.add_argument('--source');p.add_argument('--fetch',action='store_true');p.add_argument('--out')
    p.add_argument('--ack-lab',action='store_true');p.add_argument('--execute',action='store_true')
    p.add_argument('--per-cve-seconds',type=int,default=600);p.add_argument('--service-memory',default='2g');p.add_argument('--total-seconds',type=int);p.add_argument('--agent',action='store_true');p.add_argument('--model');p.add_argument('--start-ollama',action='store_true')
    p.set_defaults(func=lambda a:_q2(argparse.Namespace(**{**vars(a),'cves':str(BASE/'examples'/'practice30.txt')}),execute=a.execute))
    return ap

def main(argv=None):
    args=make_parser().parse_args(argv)
    try:
        status=args.func(args)
        return int(status or 0)
    except TaskError as e:
        print(f'FAILED={e.code} DETAIL={e}',file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print('FAILED=INTERRUPTED',file=sys.stderr);return 130
if __name__=='__main__':sys.exit(main())
