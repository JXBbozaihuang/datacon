"""Docker save archive inspection and provenance-preserving layer replacement.
No attempt to guess unknown bytes, no fabrication of CVE evidence.
"""
from __future__ import annotations
import hashlib, json, os, re, tarfile, tempfile
from pathlib import Path, PurePosixPath
from .core import TaskError,json_write,sha256_file

HEX64=re.compile(r'^[a-f0-9]{64}$')

def normal_path(s):
    if not s or '\\' in s or s.startswith('/'):
        raise TaskError('UNSAFE_ARCHIVE_PATH',f'Unsafe member path: {s!r}')
    # docker save may contain harmless './manifest.json' and 'dir/' entries.
    while s.startswith('./'):s=s[2:]
    s=s.rstrip('/')
    if s in ('','.'):return '.'
    if any(part=='..' for part in s.split('/')):
        raise TaskError('UNSAFE_ARCHIVE_PATH',f'Unsafe member path: {s!r}')
    p=PurePosixPath(s)
    if p.is_absolute(): raise TaskError('UNSAFE_ARCHIVE_PATH',f'Unsafe member path: {s!r}')
    return str(p)

def _members(tar):
    members={}
    for m in tar:
        name=normal_path(m.name)
        if m.issym() or m.islnk() or m.isdev() or m.isfifo():
            raise TaskError('UNSAFE_ARCHIVE_MEMBER',f'Unsupported archive entry: {name}')
        if name in members and m.isfile(): raise TaskError('DUPLICATE_MEMBER',name)
        if m.isfile(): members[name]=m
    return members

def _read_member(tar,members,name,max_bytes=16*1024*1024):
    name=normal_path(name)
    m=members.get(name)
    if m is None: raise TaskError('MISSING_MEMBER',name)
    if m.size>max_bytes: raise TaskError('METADATA_TOO_LARGE',name)
    f=tar.extractfile(m)
    if f is None: raise TaskError('UNREADABLE_MEMBER',name)
    data=f.read(max_bytes+1)
    if len(data)!=m.size: raise TaskError('TRUNCATED_MEMBER',name)
    return data

def _manifest(tar,members):
    raw=_read_member(tar,members,'manifest.json')
    try: data=json.loads(raw)
    except (ValueError,UnicodeDecodeError) as e: raise TaskError('INVALID_MANIFEST',str(e)) from e
    if not isinstance(data,list) or not data: raise TaskError('INVALID_MANIFEST','Must contain image entries')
    for entry in data:
        if not isinstance(entry,dict) or not isinstance(entry.get('Config'),str) or not isinstance(entry.get('Layers'),list):
            raise TaskError('INVALID_MANIFEST','Invalid image record')
        normal_path(entry['Config'])
        for x in entry['Layers']: normal_path(x)
    return data

def inventory(path):
    path=Path(path)
    if not path.is_file(): raise TaskError('FILE_MISSING',str(path))
    try:
        with tarfile.open(path,'r:*') as tar:
            members=_members(tar); entries=_manifest(tar,members)
            missing=[]; corrupted=[]; images=[]
            for e in entries:
                c=e['Config']; layers=e['Layers']
                for x in [c,*layers]:
                    if x not in members: missing.append(x)
                if c in members:
                    b=_read_member(tar,members,c)
                    stem=Path(c).stem.lower()
                    if HEX64.fullmatch(stem) and hashlib.sha256(b).hexdigest()!=stem:
                        corrupted.append(c)
                images.append({'config':c,'layers':len(layers),'tags':e.get('RepoTags',[])})
            if corrupted: status='CORRUPT_CONFIG'
            elif missing: status='INCOMPLETE'
            else: status='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF'
            return {'status':status,'path':str(path),'sha256':sha256_file(path),
                    'images':images,'missing':sorted(set(missing)),'corrupted':sorted(set(corrupted)),
                    'file_count':len(members)}
    except (tarfile.TarError,OSError,EOFError) as e:
        raise TaskError('INVALID_TAR',str(e)) from e

def recover(target, donor, dest):
    target=Path(target);donor=Path(donor);dest=Path(dest)
    if target.resolve()==dest.resolve() or donor.resolve()==dest.resolve():
        raise TaskError('DEST_EQUALS_SOURCE','Do not overwrite original')
    pre=inventory(target)
    if pre['status']!='INCOMPLETE': raise TaskError('NO_RECOVERABLE_MISSING_LAYERS',pre['status'])
    original=inventory(donor)
    if original['status']!='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF':
        raise TaskError('DONOR_INVALID',original['status'])
    with tarfile.open(target,'r:*') as t,tarfile.open(donor,'r:*') as d:
        tm=_members(t);dm=_members(d)
        target_entries=_manifest(t,tm);donor_entries=_manifest(d,dm)
        donor_by_config={e['Config']:e for e in donor_entries}
        for x in target_entries:
            y=donor_by_config.get(x['Config'])
            if y is None or x['Layers']!=y['Layers']:
                raise TaskError('DONOR_IDENTITY_MISMATCH','Layer list / config differ')
            conf=x['Config']
            if conf in tm and conf in dm:
                if _read_member(t,tm,conf)!=_read_member(d,dm,conf):
                    raise TaskError('DONOR_CONFIG_MISMATCH','Config bytes differ')
            elif conf not in dm:
                raise TaskError('DONOR_CONFIG_MISSING',conf)
        needed=pre['missing']
        if any(x not in dm for x in needed): raise TaskError('DONOR_MISSING_LAYER','Donor lacks requested entries')
        dest.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=dest.parent,suffix='.tar',delete=False) as tmp:
            tmp_path=Path(tmp.name)
        try:
            with tarfile.open(tmp_path,'w') as out:
                for name,m in tm.items():
                    f=t.extractfile(m)
                    if f is None: raise TaskError('UNREADABLE_MEMBER',name)
                    out.addfile(m,f)
                for name in needed:
                    m=dm[name]; f=d.extractfile(m)
                    if f is None: raise TaskError('DONOR_UNREADABLE',name)
                    out.addfile(m,f)
            post=inventory(tmp_path)
            if post['status']!='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF':
                raise TaskError('REPAIR_VALIDATION_FAILED',repr(post))
            os.replace(tmp_path,dest)
        finally:
            tmp_path.unlink(missing_ok=True)
    return {'status':'IMAGE_ARCHIVE_RECOVERED_NOT_RUNTIME_PROOF', 'target':str(target),
            'target_sha256':pre['sha256'],'donor':str(donor),'donor_sha256':original['sha256'],
            'output':str(dest),'output_sha256':sha256_file(dest),'recovered_members':needed}

def docker_validate(path, *, runner=None, allow_load=False):
    """Docker 29 compatible: compare config blobs of re-export, not image inspect Id.
    Loading image tags can change the local tag mapping; explicit opt-in required.
    """
    from .core import Executor
    runner=runner or Executor()
    inv=inventory(path)
    if inv['status']!='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF':
        raise TaskError('INCOMPLETE_ARCHIVE',inv['status'])
    if not allow_load: raise TaskError('DOCKER_LOAD_NOT_ACKED','Pass --allow-load to import image tags')
    refs=sorted({tag for item in inv['images'] for tag in (item.get('tags') or []) if tag})
    if not refs:raise TaskError('NO_IMAGE_TAGS','Archive has no tags for re-export check')
    runner.run(['docker','load','-i',str(path)],timeout=180)
    from .verify import assert_archive_tag
    matched=[]
    for image in refs:
        matched.append(assert_archive_tag(path,image,runner,allow_load=False))
    return {'status':'DOCKER_ARCHIVE_ROUNDTRIP_CONFIG_MATCHED_NOT_CVE_PROOF',
            'images':refs,'artifact_sha256':inv['sha256'],'checks':matched,'verified_vulnerability':False}
