"""Read-only application checks from ephemeral sidecars on isolated Docker networks.

All results are distinct from CVE behavior verification. No host ports, no
external destinations, no arbitrary targets, no remote model decisions.
"""
from __future__ import annotations

import json
import secrets
import re
import time
import uuid
from pathlib import Path

from .core import Executor, TaskError, budget_seconds, json_write, sha256_file
from .compose import inspect_services, ready_services
from .verify import assert_archive_tag, CURL_IMAGE, canonical_image_ref

PYTHON_IMAGE = 'python:3.12-alpine'
PROFILES = {
    'CVE-2021-43798': {'service': 'web', 'kind': 'grafana', 'port': 3000, 'version': '8.2.6'},
    'CVE-2021-41773': {'service': 'apache', 'kind': 'apache', 'port': 80},
    'CVE-2021-42013': {'service': 'apache', 'kind': 'apache', 'port': 80},
    'CVE-2023-46604': {'service': 'activemq', 'kind': 'activemq', 'port': 61616},
}


def _load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (ValueError, OSError) as exc:
        raise TaskError('INVALID_CASE_JSON', f'{path}: {exc}') from exc


def _http(runner, network, service, port, path, deadline):
    # The command is fully constructed by the controller, never by the LLM.
    url=f'http://{service}:{port}{path}'
    result=runner.run(['docker','run','--rm','--network',network,
        '--cap-drop','ALL','--security-opt','no-new-privileges',
        '--read-only','--memory','128m','--pids-limit','64',
        '--entrypoint','curl',CURL_IMAGE,
        '--noproxy','*','--path-as-is','--silent','--show-error',
        '--connect-timeout','4','--max-time','12',
        '--write-out','\n__T3STATUS__:%{http_code}',url],
        timeout=budget_seconds(deadline,20))
    if '\n__T3STATUS__:' not in result.stdout:
        raise TaskError('HTTP_BAD_RESULT','Missing HTTP status marker')
    body, code = result.stdout.rsplit('\n__T3STATUS__:',1)
    if not re.fullmatch(r'\d{3}',code.strip()):
        raise TaskError('HTTP_BAD_STATUS',code[-40:])
    return {'http':int(code.strip()), 'body':body[:1024]}


def _tcp(runner,network,service,port,deadline):
    program=(
        'import socket,json,sys\n'
        's=socket.create_connection((sys.argv[1],int(sys.argv[2])),5)\n'
        's.close()\n'
        'print(json.dumps({"tcp_connected":True}))\n'
    )
    result=runner.run(['docker','run','--rm','--network',network,
        '--cap-drop','ALL','--security-opt','no-new-privileges',
        '--read-only','--memory','96m','--pids-limit','64',
        '--entrypoint','python',PYTHON_IMAGE,
        '-c',program,service,str(port)],timeout=budget_seconds(deadline,20))
    try: datum=json.loads(result.stdout.strip())
    except ValueError as e:raise TaskError('TCP_BAD_RESULT',str(e)) from e
    if datum.get('tcp_connected') is not True:
        raise TaskError('TCP_NOT_CONNECTED',f'{service}:{port}')
    return {'tcp_connected':True,'port':port}


def _internal_network(runner, container_id, deadline):
    p=runner.run(['docker','inspect',container_id],timeout=budget_seconds(deadline,15))
    info=json.loads(p.stdout)[0]
    networks=(info.get('NetworkSettings') or {}).get('Networks') or {}
    if len(networks)!=1:
        raise TaskError('UNEXPECTED_NETWORKS',repr(sorted(networks)))
    network=next(iter(networks))
    p=runner.run(['docker','network','inspect',network],timeout=budget_seconds(deadline,15))
    network_info=json.loads(p.stdout)[0]
    if network_info.get('Internal') is not True:
        raise TaskError('NETWORK_NOT_INTERNAL',network)
    if (info.get('HostConfig') or {}).get('PortBindings'):
        raise TaskError('HOST_PORT_PUBLISHED',container_id)
    return network


def _image_ports(runner, image, deadline):
    p=runner.run(['docker','image','inspect',image],timeout=budget_seconds(deadline,15))
    cfg=json.loads(p.stdout)[0].get('Config') or {}
    ports=[]
    for exposed in (cfg.get('ExposedPorts') or {}):
        m=re.fullmatch(r'(\d{1,5})/tcp',exposed)
        if m and 1 <= int(m.group(1)) <= 65535:
            ports.append(int(m.group(1)))
    return sorted(set(ports))[:3]


def _apache_canary(runner, network, service, container_id, deadline):
    """Optional lab-only self-file path traversal probe (no remote files, no RCE)."""
    filename='t3_canary_'+secrets.token_hex(12)+'.txt'
    path='/tmp/'+filename
    marker='T3_NON_SECRET_'+secrets.token_hex(24)
    # Host supplies no mount and test file is written only inside this ephemeral container.
    runner.run(['docker','exec','--user','0',container_id,'sh','-c',
        'umask 022; printf %s "$1" > "$2"; chmod 0644 "$2"',
        't3',marker,path],timeout=budget_seconds(deadline,15))
    negative=_http(runner,network,service,80,'/icons/'+filename,deadline)
    paths=[
        '/icons/.%2e/.%2e/.%2e/.%2e/tmp/'+filename,
        '/icons/.%2e/.%2e/.%2e/.%2e/.%2e/tmp/'+filename,
    ]
    positives=[_http(runner,network,service,80,p,deadline) for p in paths]
    observed=any(x['http']==200 and x['body']==marker for x in positives)
    false_positive=negative['body']==marker
    return {'status':('LOCAL_CANARY_OBSERVED_NO_PATCHED_CONTROL' if observed and not false_positive
                      else 'LOCAL_CANARY_NOT_OBSERVED'),
            'observed':observed and not false_positive,
            'negative_exact':false_positive,
            'positive_http':[x['http'] for x in positives],
            'negative_http':negative['http'],
            'verified_vulnerability':False}


def _profile_check(runner,network,services,cve,deadline):
    profile=PROFILES.get(cve)
    if profile:
        service=profile['service']
        if service not in services:
            raise TaskError('PROFILE_SERVICE_MISSING',service)
        kind=profile['kind']
        if kind=='grafana':
            x=_http(runner,network,service,3000,'/api/health',deadline)
            try: version=json.loads(x['body']).get('version')
            except (ValueError,TypeError,AttributeError):version=None
            if x['http']!=200 or version!=profile['version']:
                raise TaskError('GRAFANA_HEALTH_MISMATCH',f'HTTP={x["http"]} version={version}')
            return {'kind':kind,'service':service,'port':3000,'http':200,
                    'version':version,'status':'APPLICATION_RESPONDED_NOT_CVE_PROOF'}
        if kind=='apache':
            x=_http(runner,network,service,80,'/',deadline)
            if x['http'] != 200 or not x['body'].strip():
                raise TaskError('APACHE_HTTP_UNHEALTHY',f'HTTP={x["http"]} body_length={len(x["body"])}')
            return {'kind':kind,'service':service,'port':80,'http':200,
                    'status':'APPLICATION_RESPONDED_NOT_CVE_PROOF'}
        if kind=='activemq':
            tcp=_tcp(runner,network,service,61616,deadline)
            # OpenWire reachability alone is not proof of the deserialization CVE.
            return {'kind':kind,'service':service,**tcp,
                    'status':'OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF'}
    # For unseen CVEs only probe a declared TCP port, with a clearly weaker verdict.
    found=[]
    for service, state in services.items():
        for port in _image_ports(runner,state['image_ref'],deadline):
            try:
                _tcp(runner,network,service,port,deadline)
                found.append({'service':service,'port':port})
            except TaskError:
                continue
    return {'kind':'generic','reachable_ports':found,
            'status':('GENERIC_TCP_REACHABLE_NOT_CVE_PROOF' if found
                      else 'NO_PROTOCOL_PROBE_AVAILABLE')}



def _is_transient_readiness_error(exc):
    """Retry application startup only, not Docker infrastructure or proof errors."""
    code = getattr(exc, 'code', '')
    message = str(exc)
    if code == 'COMMAND_FAILED':
        return (
            ('docker exit=7:' in message and 'Failed to connect' in message)
            or ('docker exit=28:' in message and 'timed out' in message.lower())
            or ('ConnectionRefusedError' in message)
            or ('[Errno 111] Connection refused' in message)
        )
    if code == 'APACHE_HTTP_UNHEALTHY':
        return any('HTTP='+str(n) in message for n in (502,503,504))
    if code == 'GRAFANA_HEALTH_MISMATCH':
        return any('HTTP='+str(n) in message for n in (502,503,504))
    return False


def _await_application(runner, network, services, cve, deadline, record,
                       *, max_wait=120, interval=2):
    """Bounded application readiness gate after Docker reports `running`.

    Writes evidence for every attempt, retains time for cleanup, and never
    turns a service-readiness pass into a vulnerability proof.
    """
    started = time.monotonic()
    end = min(started + max_wait, deadline - 12)
    evidence = {'status':'NOT_READY','attempts':[], 'elapsed_seconds':0}
    record['readiness'] = evidence
    attempt_no = 0
    while True:
        attempt_no += 1
        try:
            outcome = _profile_check(runner, network, services, cve, deadline)
            evidence['attempts'].append({'number':attempt_no,'result':'PASS'})
            evidence['status'] = 'READY'
            evidence['elapsed_seconds'] = round(time.monotonic()-started,2)
            return outcome
        except TaskError as exc:
            transient = _is_transient_readiness_error(exc)
            evidence['attempts'].append({
                'number':attempt_no, 'result':'RETRYABLE' if transient else 'FAILED',
                'error_code':exc.code, 'error':str(exc)[:300]
            })
            evidence['elapsed_seconds'] = round(time.monotonic()-started,2)
            if not transient:
                evidence['status']='FAILED_NON_TRANSIENT'
                raise
            remaining=end-time.monotonic()
            if remaining <= 0:
                evidence['status']='TIMEOUT'
                raise TaskError('APPLICATION_NOT_READY',
                    f'{cve}: {attempt_no} attempts over '
                    f'{evidence["elapsed_seconds"]}s; last={exc.code}: {str(exc)[:250]}') from exc
            time.sleep(min(interval, remaining))


def check_case(case_dir,*,runner=None,budget=240,apache_canary=False):
    if not 30 <= budget <= 3600:
        raise TaskError('INVALID_BUDGET','budget should be between 30 and 3600 seconds')
    case=Path(case_dir).expanduser().resolve()
    data={'status':'SERVICE_CHECK_FAILED','case':str(case), 'verified_vulnerability':False,
          'host_ports_published':False,'checks':[],'error_code':None}
    target=case/'service_check.json'
    runner=runner or Executor()
    project='t3svc'+uuid.uuid4().hex[:10]
    started=False
    cfg=case/'portable.compose.json'
    deadline=time.monotonic()+budget
    try:
        report=_load_json(case/'result.json')
        if report.get('status')!='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
            raise TaskError('NOT_EXPORTED_CASE','Case has not exported a real Docker image')
        if report.get('portability')!='REDEPLOY_NOT_TESTED':
            raise TaskError('EXTERNAL_DATA_NOT_PACKAGED','Case requires external data')
        config=_load_json(cfg)
        if not (config.get('networks') or {}).get('default',{}).get('internal'):
            raise TaskError('NOT_ISOLATED','Internal Docker network required')
        services=sorted(config.get('services') or {})
        if not services:raise TaskError('NO_SERVICES','Compose has no services')
        for svc in config['services'].values():
            if svc.get('build') or svc.get('ports') or svc.get('network_mode'):
                raise TaskError('UNSAFE_PORTABLE_COMPOSE','No build, host ports or host network permitted')
        artifact=Path(report['artifact'])
        if not artifact.is_file():raise TaskError('ARTIFACT_MISSING',str(artifact))
        if sha256_file(artifact)!=report.get('archive_sha256'):
            raise TaskError('ARTIFACT_SHA_MISMATCH','Saved Docker archive was modified')
        images=report.get('images')
        if not isinstance(images,list) or not images or not all(isinstance(x,str) for x in images):
            raise TaskError('IMAGE_LIST_INVALID','Nonempty original export image list required')
        config_refs=[(svc or {}).get('image') for svc in config['services'].values()]
        if any(not x for x in config_refs) or {canonical_image_ref(x) for x in images} != {canonical_image_ref(x) for x in config_refs}:
            raise TaskError('CASE_IMAGE_REFERENCES_MISMATCH','Portable compose and original exported image tags disagree')
        for image in images:
            assert_archive_tag(artifact,image,runner,allow_load=False)
        data['checks'].append('EXPORTED_ARCHIVE_TAG_CONFIG_MATCHED')
        data['project']=project
        started=True
        runner.run(['docker','compose','-f',str(cfg),'-p',project,'up','-d',
                    '--no-build','--pull','never'],timeout=budget_seconds(deadline,budget))
        last={}
        while time.monotonic()<deadline-20:
            states=inspect_services(runner,cfg,project,services,deadline)
            last=states
            if ready_services(states):break
            if any(v.get('status')=='exited' for v in states.values()):
                raise TaskError('SERVICE_EXITED',str(states)[:1000])
            time.sleep(2)
        else:raise TaskError('SERVICE_NOT_READY',repr(last)[:1000])
        data['checks'].append('COMPOSE_SERVICES_RUNNING')
        networks=set()
        for service in services:
            x=runner.run(['docker','compose','-f',str(cfg),'-p',project,'ps','-q',service],
                         timeout=budget_seconds(deadline,15))
            ids=x.stdout.split()
            if len(ids)!=1:raise TaskError('SERVICE_CONTAINER_MISSING',service)
            networks.add(_internal_network(runner,ids[0],deadline))
        if len(networks)!=1:
            raise TaskError('MULTIPLE_INTERNAL_NETWORKS',repr(networks))
        net=networks.pop()
        data['checks'].append('NO_HOST_PORT_AND_ALL_SERVICES_INTERNAL')
        cve=report['cve']
        trial=_await_application(runner,net,last,cve,deadline,data)
        data['trial']=trial
        data['status']=trial['status']
        data['checks'].append('REAL_CONTAINER_INTERNAL_PROBE_COMPLETE')
        data['network']=net
        if apache_canary and cve=='CVE-2021-41773' and trial['status']=='APPLICATION_RESPONDED_NOT_CVE_PROOF':
            p=runner.run(['docker','compose','-f',str(cfg),'-p',project,'ps','-q','apache'],
                         timeout=budget_seconds(deadline,15))
            ids=p.stdout.split()
            if len(ids)!=1:raise TaskError('SERVICE_CONTAINER_MISSING','apache')
            data['canary']=_apache_canary(runner,net,'apache',ids[0],deadline)
            data['checks'].append('SELF_CREATED_FILE_LAB_CANARY_ATTEMPTED')
    except (TaskError,ValueError,KeyError,IndexError,OSError) as exc:
        data['error_code']=getattr(exc,'code','SERVICE_PROBE_EXCEPTION')
        data['error']=str(exc)[:1500]
        if started:
            try:
                p=runner.run(['docker','compose','-f',str(cfg),'-p',project,
                              'logs','--no-color','--tail','50'],timeout=15,check=False)
                data['logs_tail']=(p.stdout+'\n'+p.stderr)[-3000:]
            except (TaskError,OSError):pass
    finally:
        if started:
            try:
                p=runner.run(['docker','compose','-f',str(cfg),'-p',project,'down',
                              '--remove-orphans','--volumes'],timeout=35,check=False)
                data['cleanup']='OK' if p.returncode==0 else 'FAILED'
            except TaskError as exc:data['cleanup']='FAILED: '+str(exc)[:200]
        json_write(target,data)
    return data


def check_pilot(pilot_dir,*,runner=None,budget=240,apache_canary=False):
    folder=Path(pilot_dir).expanduser().resolve()
    summary=_load_json(folder/'pilot_summary.json')
    results=[]
    for item in summary.get('cases',[]):
        cve=item['cve']
        if not re.fullmatch(r'CVE-\d{4}-\d{4,}',cve):
            raise TaskError('BAD_CVE_IN_PILOT',cve)
        x=check_case(folder/cve,runner=runner,budget=budget,apache_canary=apache_canary)
        results.append({'cve':cve,'status':x['status'],'error_code':x.get('error_code'),
                        'canary_status':(x.get('canary') or {}).get('status'),
                        'evidence':str(folder/cve/'service_check.json')})
    report={'status':'SERVICE_BATCH_COMPLETED_NOT_CVE_PROOF','pilot':str(folder),
            'cases':results,'count':len(results),'service_passed':sum(
                x['status'] in ('APPLICATION_RESPONDED_NOT_CVE_PROOF','OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF',
                                'GENERIC_TCP_REACHABLE_NOT_CVE_PROOF') for x in results),
            'verified_vulnerabilities':0,
            'canary_observed_no_patched_control':sum(
                x.get('canary_status')=='LOCAL_CANARY_OBSERVED_NO_PATCHED_CONTROL' for x in results)}
    json_write(folder/'service_summary.json',report)
    return report
