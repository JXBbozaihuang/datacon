"""Deterministic orchestration primitives; no shell=True, no hidden retries."""
from __future__ import annotations
import hashlib, json, os, re, subprocess, time, uuid
from pathlib import Path

class TaskError(RuntimeError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)

class Executor:
    def run(self, argv, *, timeout=60, cwd=None, input=None, check=True):
        if not isinstance(argv, (list, tuple)) or not argv or not all(isinstance(x,str) for x in argv):
            raise TaskError('INVALID_COMMAND','Command must be a string argument list')
        try:
            p = subprocess.run(list(argv), input=input, cwd=cwd, text=True,
                               capture_output=True, timeout=timeout, check=False)
        except FileNotFoundError as e:
            raise TaskError('TOOL_MISSING',str(e)) from e
        except subprocess.TimeoutExpired as e:
            # subprocess may return *bytes* even when text=True. Retain the
            # partial pipes so callers can persist evidence from a timed-out
            # docker pull/build rather than losing the failure's only clue.
            def as_text(chunk):
                if chunk is None:
                    return ''
                if isinstance(chunk, bytes):
                    return chunk.decode('utf-8', errors='replace')
                return str(chunk)
            error = TaskError('TIMEOUT', f'{argv[0]} timed out ({timeout}s)')
            error.partial_stdout = as_text(e.stdout)
            error.partial_stderr = as_text(e.stderr)
            error.timeout_seconds = timeout
            raise error from e
        if check and p.returncode != 0:
            raise TaskError('COMMAND_FAILED',f'{argv[0]} exit={p.returncode}: {p.stderr[-1200:]}')
        return p

def json_write(path, data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp-'+uuid.uuid4().hex[:8])
    tmp.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    os.replace(tmp,path)
    try: os.chmod(path,0o600)
    except OSError: pass

def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def safe_name(s, maxlen=75):
    s=re.sub(r'[^A-Za-z0-9_-]+','-',s).strip('-')[:maxlen]
    return s or 'task'

def now_id(): return time.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:6]

def within(path, root):
    try:
        Path(path).resolve(strict=False).relative_to(Path(root).resolve(strict=False))
        return True
    except ValueError: return False

def budget_seconds(deadline, cap):
    remain=deadline-time.monotonic()
    if remain <= 0: raise TaskError('BUDGET_EXHAUSTED','Time budget exhausted')
    return max(1,min(cap,int(remain)))

class FakeExecutor(Executor):
    """No implicit mocking in real run; tests use explicit fake executor."""
    def __init__(self, callback): self.callback=callback
    def run(self, argv, **kwargs): return self.callback(list(argv),**kwargs)
