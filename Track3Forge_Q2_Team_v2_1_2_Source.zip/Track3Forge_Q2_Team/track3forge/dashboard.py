"""Local read-only result viewer. No shell/AI commands or file uploads."""
from __future__ import annotations
import json,re
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,unquote
from .core import TaskError
from .catalog import CVE_RE
HTML=(Path(__file__).parent/'web'/'index.html')
CSS=(Path(__file__).parent/'web'/'style.css')
JS=(Path(__file__).parent/'web'/'app.js')
ID_RE=re.compile(r'^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$')

def run_index(root):
    root=Path(root);items=[]
    if not root.is_dir():return items
    for p in sorted(root.iterdir(),reverse=True):
        if not p.is_dir() or p.is_symlink() or not ID_RE.fullmatch(p.name):continue
        path=p/'summary.json'
        if not path.is_file():continue
        try:
            summary=json.loads(path.read_text(encoding='utf-8'))
            rows=[];verified=0
            for item in summary.get('results',[]):
                row=dict(item)
                cve=row.get('cve','')
                if CVE_RE.fullmatch(cve):
                    proof=p/cve/'proof'/'known_proof.json'
                    if proof.is_file() and not proof.is_symlink():
                        try:
                            evidence=json.loads(proof.read_text(encoding='utf-8'))
                            row['proof_status']=evidence.get('status')
                            if evidence.get('status')=='BEHAVIOR_VERIFIED' and evidence.get('vulnerability_verified') is True:
                                verified+=1
                        except (ValueError,OSError):pass
                rows.append(row)
            items.append({'id':p.name,'requested':summary.get('requested',0),
                 'exported_real_docker':summary.get('exported_real_docker',0),
                 'verified_vulnerabilities':verified,
                 'results':rows})
        except (ValueError,OSError):continue
    return items

def get_case(root,run_id,cve):
    if not ID_RE.fullmatch(run_id) or not CVE_RE.fullmatch(cve):
        raise TaskError('BAD_PATH','Invalid run/CVE path')
    root=Path(root).resolve();p=root/run_id/cve/'result.json'
    if not p.is_file() or p.is_symlink():raise TaskError('NOT_FOUND','Case missing')
    result=json.loads(p.read_text(encoding='utf-8'))
    proof=root/run_id/cve/'proof'/'known_proof.json'
    if proof.is_file() and not proof.is_symlink():result['known_proof']=json.loads(proof.read_text(encoding='utf-8'))
    return result

def serve(root,port=8765):
    root=Path(root).resolve()
    class View(BaseHTTPRequestHandler):
        def do_GET(self):
            route=urlparse(self.path).path
            status=200;ctype='application/json; charset=utf-8'
            try:
                if route=='/':content=HTML.read_bytes();ctype='text/html; charset=utf-8'
                elif route=='/style.css':content=CSS.read_bytes();ctype='text/css; charset=utf-8'
                elif route=='/app.js':content=JS.read_bytes();ctype='application/javascript; charset=utf-8'
                elif route=='/api/runs':content=json.dumps(run_index(root),ensure_ascii=False).encode()
                elif route.startswith('/api/case/'):
                    pieces=[unquote(x) for x in route.split('/')]
                    if len(pieces)!=5:raise TaskError('BAD_PATH','Bad route')
                    content=json.dumps(get_case(root,pieces[3],pieces[4]),ensure_ascii=False).encode()
                else:raise TaskError('NOT_FOUND','Resource not found')
            except (TaskError,ValueError,OSError):
                status=404;content=b'{"error":"NOT_FOUND"}'
            self.send_response(status)
            self.send_header('Content-Type',ctype)
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'")
            self.send_header('Content-Length',str(len(content)))
            self.end_headers();self.wfile.write(content)
        def do_POST(self):
            self.send_error(405,'Dashboard is read only')
    server=ThreadingHTTPServer(('127.0.0.1',port),View)
    print(f'DASHBOARD=http://127.0.0.1:{server.server_port}/')
    print(f'RUNS={root}')
    print('READ_ONLY=YES NEXT=Ctrl+C to stop dashboard')
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
