"""Exact-CVE recipe discovery. No guessed aliases, no model-generated successes."""
from __future__ import annotations
import csv, io, json, re, shutil, subprocess, tarfile, tempfile, urllib.request, zipfile
from pathlib import Path
from .core import TaskError,sha256_file,within

CVE_RE=re.compile(r'^CVE-\d{4}-\d{4,}$',re.I)
COMPOSE_NAMES=('docker-compose.yml','docker-compose.yaml','compose.yaml','compose.yml')

def validate_cve(raw):
    s=str(raw).strip().upper()
    if not CVE_RE.fullmatch(s): raise TaskError('INVALID_CVE',f'Invalid CVE ID: {raw!r}')
    return s

def read_cves(item):
    p=Path(item)
    if p.is_file():
        raw=p.read_text(encoding='utf-8-sig')
        if p.suffix.lower()=='.json':
            try:v=json.loads(raw)
            except ValueError as e:raise TaskError('BAD_CVE_FILE',str(e)) from e
            if isinstance(v,dict): v=v.get('cves',[])
            if not isinstance(v,list): raise TaskError('BAD_CVE_FILE','JSON must be list or {"cves":[]}')
            ids=[x if isinstance(x,str) else x.get('cve','') for x in v]
        elif p.suffix.lower()=='.csv':
            rows=list(csv.reader(io.StringIO(raw)))
            if not rows: raise TaskError('EMPTY_CVE_LIST','No rows in CVE file')
            col=next((i for i,k in enumerate(rows[0]) if k.strip().lower() in ('cve','cve_id','id')),0)
            rows=rows[1:] if rows[0][col].strip().lower() in ('cve','cve_id','id') else rows
            ids=[row[col] for row in rows if len(row)>col]
        else:
            ids=[line.partition('#')[0].strip() for line in raw.splitlines() if line.partition('#')[0].strip()]
    else: ids=[item]
    seen=set(); out=[]
    for raw in ids:
        cve=validate_cve(raw)
        if cve not in seen: out.append(cve);seen.add(cve)
    if not out: raise TaskError('EMPTY_CVE_LIST','No CVEs provided')
    return out

def find_recipes(root, cve):
    """Match an entire directory name, never a substring in a filename/README."""
    root=Path(root).expanduser(); cve=validate_cve(cve)
    if not root.is_dir(): return []
    matches=[]
    for d in root.rglob('*'):
        if not d.is_dir() or d.name.upper()!=cve or d.is_symlink(): continue
        if not within(d,root): continue
        for fn in COMPOSE_NAMES:
            candidate=d/fn
            if candidate.is_file() and not candidate.is_symlink() and within(candidate,root):
                matches.append(candidate);break
    return sorted(matches,key=str)

def safe_zip_extract(archive,dest,max_files=15000,max_bytes=600*1024*1024):
    dest=Path(dest);dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist()
        if len(infos)>max_files or sum(x.file_size for x in infos)>max_bytes:
            raise TaskError('ARCHIVE_TOO_LARGE','Vulhub snapshot exceeds limits')
        for ent in infos:
            if ent.filename.startswith('/') or '\\' in ent.filename or not within(dest/ent.filename,dest):
                raise TaskError('ZIP_SLIP','Unsafe archive path')
            # symlinks: external attrs POSIX mode
            if (ent.external_attr >> 16) & 0o170000 == 0o120000:
                raise TaskError('ZIP_SYMLINK','Symlink in snapshot rejected')
        for ent in infos:
            target=dest/ent.filename
            if ent.is_dir(): target.mkdir(parents=True,exist_ok=True);continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with z.open(ent) as src,target.open('wb') as out: shutil.copyfileobj(src,out)

def fetch_snapshot(cache,*,timeout=45):
    """Atomic snapshot: primary GitHub ZIP, fallback codeload ZIP, then git clone.
    The archive digest/commit is recorded; an invalid cache is never overwritten.
    """
    cache=Path(cache).expanduser()
    if cache.is_dir() and (cache/'environments.toml').is_file():
        return {'path':str(cache),'status':'CACHE_REUSED','sha256':None}
    if cache.exists():
        raise TaskError('SOURCE_CACHE_CONFLICT',f'Existing incomplete path {cache}; rename it before retrying')
    cache.parent.mkdir(parents=True,exist_ok=True)
    urls=[
      'https://github.com/vulhub/vulhub/archive/refs/heads/master.zip',
      'https://codeload.github.com/vulhub/vulhub/zip/refs/heads/master',
    ]
    errors=[]
    with tempfile.TemporaryDirectory(prefix='t3fetch-',dir=cache.parent) as tmpname:
        tmp=Path(tmpname)
        for index,url in enumerate(urls):
            archive=tmp/f'snapshot-{index}.zip'
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'Track3Forge/1.0'})
                with urllib.request.urlopen(req,timeout=timeout) as response,archive.open('wb') as out:
                    count=0
                    while True:
                        b=response.read(1024*1024)
                        if not b:break
                        count+=len(b)
                        if count>150*1024*1024:raise TaskError('DOWNLOAD_TOO_LARGE','snapshot >150MB')
                        out.write(b)
                dest=tmp/f'zip-{index}'
                safe_zip_extract(archive,dest)
                roots=[p for p in dest.iterdir() if p.is_dir()]
                if len(roots)!=1 or not (roots[0]/'environments.toml').is_file():
                    raise TaskError('SOURCE_INVALID','Missing environments.toml')
                digest=sha256_file(archive)
                shutil.move(str(roots[0]),str(cache))
                return {'path':str(cache),'status':'DOWNLOADED_ZIP',
                        'sha256':digest,'source_url':url}
            except Exception as e:
                errors.append(f'ZIP{index}: {type(e).__name__}: {str(e)[:180]}')
        target=tmp/'git-source'
        try:
            p=subprocess.run(['git','clone','--depth','1','https://github.com/vulhub/vulhub.git',str(target)],
                             capture_output=True,text=True,timeout=max(45,timeout))
            if p.returncode!=0:raise TaskError('GIT_CLONE_FAILED',p.stderr[-400:])
            if not (target/'environments.toml').is_file():raise TaskError('SOURCE_INVALID','Git repo missing registry')
            commit=subprocess.run(['git','rev-parse','HEAD'],cwd=target,capture_output=True,text=True,
                                  timeout=10,check=True).stdout.strip()
            shutil.move(str(target),str(cache))
            return {'path':str(cache),'status':'DOWNLOADED_GIT','commit':commit,
                    'source_url':'https://github.com/vulhub/vulhub.git'}
        except Exception as e:
            errors.append(f'GIT: {type(e).__name__}: {str(e)[:180]}')
    raise TaskError('SOURCE_FETCH_FAILED',' | '.join(errors))

def sample_recipes(source, *, count=30, seed=42):
    """Deterministic round-robin sample across different software families.
    Samples existing CVE directories; not a guarantee each environment builds.
    """
    import random
    source=Path(source)
    groups={}
    for path in source.rglob('*'):
        if not path.is_dir() or not CVE_RE.fullmatch(path.name) or path.is_symlink():continue
        if not within(path,source):continue
        if not any((path/n).is_file() and not (path/n).is_symlink() for n in COMPOSE_NAMES):continue
        family=path.parent.name
        groups.setdefault(family,[]).append(path.name.upper())
    rng=random.Random(seed)
    for values in groups.values():
        values[:]=sorted(set(values));rng.shuffle(values)
    families=sorted(groups);rng.shuffle(families)
    result=[]
    while len(result)<count and any(groups.values()):
        for family in families:
            if groups[family]:
                result.append(groups[family].pop())
                if len(result)==count:break
    if len(result)<count:
        raise TaskError('INSUFFICIENT_RECIPES',f'{len(result)} exact recipes found, requested {count}')
    return result
