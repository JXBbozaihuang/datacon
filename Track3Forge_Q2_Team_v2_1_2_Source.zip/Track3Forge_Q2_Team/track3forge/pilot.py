"""Bounded, serial Q2 pilot. Each CVE leaves a durable independent receipt.

This deliberately does not claim CVE reproduction from Docker build, export,
or redeploy. A model's post-mortem advice has no authority over status.
"""
from __future__ import annotations

import csv
import json
import shutil
import time
from pathlib import Path
from typing import Any

from . import catalog, compose, llm
from .core import TaskError, Executor, json_write, now_id

FIELDS = ('cve', 'build', 'redeploy', 'verified_vulnerability', 'seconds', 'error_code', 'redeploy_error_code', 'artifact')


def _persist(folder: Path, summary: dict[str, Any]) -> None:
    json_write(folder / 'pilot_summary.json', summary)
    p = folder / 'pilot_summary.csv'
    with p.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(summary['cases'])


def run_pilot(cves, source, out, *, runner=None, limit=3, per_cve_seconds=300,
              total_seconds=1800, redeploy_seconds=180, service_memory='2g',
              ack_lab=False, agent=False, start_ollama=False, model=None,
              min_disk_gb=2):
    """Execute at most `limit` selected CVEs sequentially, checkpoint per case.

    Returns all structured outcomes; caller is responsible for CLI exit code.
    """
    if not ack_lab:
        raise TaskError('LAB_ACK_REQUIRED', 'Pilot needs --ack-lab')
    if limit < 1 or limit > 30:
        raise TaskError('BAD_PILOT_LIMIT', 'Limit must be in [1,30]')
    if per_cve_seconds < 20 or total_seconds < 20 or redeploy_seconds < 20:
        raise TaskError('INVALID_BUDGET', 'Each budget must be at least 20 seconds')
    source = Path(source).resolve()
    if not source.is_dir():
        raise TaskError('SOURCE_MISSING', str(source))
    out = Path(out).resolve()
    if out.exists() and any(out.iterdir()):
        raise TaskError('OUTPUT_NOT_EMPTY', 'Use a new --out to avoid mixing evidence')
    out.mkdir(parents=True, exist_ok=True)
    runner = runner or Executor()
    # Fail *before* writing claimed case results if Docker is not available.
    runner.run(['docker', 'info', '--format', '{{.ServerVersion}}'], timeout=20)
    available = shutil.disk_usage(out).free
    if available < min_disk_gb * 1024**3:
        raise TaskError('LOW_DISK_SPACE', f'Only {available / 1024**3:.1f} GiB free')

    candidates = list(cves)
    selected = candidates[:limit]
    deadline = time.monotonic() + total_seconds
    summary = {
        'status': 'PILOT_IN_PROGRESS', 'requested': len(candidates),
        'selected': len(selected), 'source': str(source), 'output': str(out),
        'cases': [], 'official_accepted': None, 'verified_vulnerabilities': 0,
        'model_advice_is_not_proof': True,
    }
    _persist(out, summary)

    selected_model = None
    if agent:
        try:
            installed = llm.ensure_server(start=start_ollama)
            selected_model = llm.choose_model(installed, model)
            summary['ollama_model'] = selected_model or 'NONE_INSTALLED'
        except TaskError as e:
            summary['ollama_error'] = f'{e.code}: {e}'
        _persist(out, summary)

    for cve in selected:
        start = time.monotonic()
        record = {
            'cve': cve, 'build': 'NOT_RUN', 'redeploy': 'NOT_RUN',
            'verified_vulnerability': False, 'seconds': 0,
            'error_code': None, 'artifact': None,
        }
        case = out / cve
        case.mkdir(parents=True, exist_ok=True)
        remaining = int(deadline - time.monotonic())
        try:
            if remaining < 20:
                record['build'] = 'GLOBAL_BUDGET_EXHAUSTED_NOT_RUN'
                record['error_code'] = 'GLOBAL_BUDGET_EXHAUSTED'
            else:
                recipes = catalog.find_recipes(source, cve)
                if not recipes:
                    record['build'] = 'NO_RECIPE'
                    record['error_code'] = 'NO_EXACT_COMPOSE_RECIPE'
                else:
                    build = compose.candidate_run(
                        cve, recipes[0], source, case, execute=True,
                        acknowledge=True, runner=runner,
                        budget=min(per_cve_seconds, remaining),
                        service_memory=service_memory,
                    )
                    record['build'] = build['status']
                    record['artifact'] = build.get('artifact')
                    record['error_code'] = build.get('error_code')
                    record['error'] = build.get('error')
                    record['compose_log'] = build.get('compose_log')
                    record['cleanup_status'] = build.get('cleanup_status')
                    if build['status'] == 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
                        remaining = int(deadline - time.monotonic())
                        if remaining < 20:
                            record['redeploy'] = 'GLOBAL_BUDGET_EXHAUSTED_NOT_RUN'
                        elif build.get('portability') != 'REDEPLOY_NOT_TESTED':
                            record['redeploy'] = 'BLOCKED_EXTERNAL_DATA_NOT_PACKAGED'
                        else:
                            try:
                                ret = compose.redeploy_check(
                                    case, runner=runner,
                                    allow_load=False,
                                    budget=min(redeploy_seconds, remaining),
                                )
                                record['redeploy'] = ret['status']
                                if ret.get('error_code'):
                                    record['redeploy_error_code'] = ret['error_code']
                                    record['redeploy_error'] = ret.get('error')
                            except (TaskError, OSError, ValueError, KeyError) as e:
                                record['redeploy'] = 'FAILED'
                                record['redeploy_error_code'] = getattr(e, 'code', 'REDEPLOY_EXCEPTION')
                                record['redeploy_error'] = str(e)[:1200]
        except (TaskError, ValueError, KeyError, OSError) as e:
            record['build'] = 'FAILED'
            record['error_code'] = getattr(e, 'code', 'PILOT_EXECUTION_ERROR')
            record['error'] = str(e)[:1200]
        record['seconds'] = round(time.monotonic() - start, 2)
        json_write(case / 'pilot_receipt.json', record)

        if selected_model and record['build'] == 'FAILED':
            try:
                advice = llm.diagnose(selected_model, str(record.get('error', 'Unknown error')))
                json_write(case / 'agent_advice.json', advice)
                record['agent_advice_file'] = str(case / 'agent_advice.json')
            except TaskError as e:
                record['agent_error'] = f'{e.code}: {e}'
            json_write(case / 'pilot_receipt.json', record)
        summary['cases'].append(record)
        _persist(out, summary)
        print(f"{cve:<20} BUILD={record['build']:<39} REDEPLOY={record['redeploy']} "
              f"ERROR={record['error_code'] or record.get('redeploy_error_code') or '-'}", flush=True)

    summary['status'] = 'PILOT_COMPLETED_NOT_CVE_PROOF'
    summary['exported_real_docker'] = sum(
        x['build'] == 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF' for x in summary['cases'])
    summary['redeploy_passed'] = sum(
        x['redeploy'] == 'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF' for x in summary['cases'])
    summary['build_failed'] = sum(x['build'] == 'FAILED' for x in summary['cases'])
    summary['delivery_blocked'] = sum(x['redeploy'] == 'BLOCKED_EXTERNAL_DATA_NOT_PACKAGED'
                                       for x in summary['cases'])
    summary['registry_failures'] = sum((x.get('error_code') or '').startswith('REGISTRY_')
                                        for x in summary['cases'])
    summary['redeploy_failed'] = sum(x['redeploy'] == 'FAILED' for x in summary['cases'])
    summary['failed'] = sum(x['build'] == 'FAILED' or x['redeploy'] == 'FAILED'
                            for x in summary['cases'])
    summary['next'] = 'Check pilot_summary.csv and per-CVE result.json; run independent CVE behavior proof separately'
    _persist(out, summary)
    return summary
