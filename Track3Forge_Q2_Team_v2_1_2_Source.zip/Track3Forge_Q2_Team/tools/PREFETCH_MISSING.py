#!/usr/bin/env python3
"""Track3Forge generic Docker image prefetch for failed Q2 cases.

Uses prior pilot's isolated.compose.json as the authoritative, already audited
Compose input. Does not run CVE services, alter Compose, or assert reproduction.
Requires an explicit --pull to contact the registry. No CVE-specific paths.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
from typing import Any

IMG_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/:@-]{0,253}$")
CVE_RE = re.compile(r"^CVE-[0-9]{4}-[0-9]{4,}$", re.I)
TRANSIENT = ("unexpected eof", ": eof", "connection reset", "tls handshake timeout",
             "i/o timeout", "context deadline exceeded", "client.timeout exceeded",
             "connection aborted", "http2: client connection lost", "502 bad gateway",
             "503 service unavailable", "504 gateway timeout", "temporary failure")


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def valid_image(s: object) -> bool:
    return isinstance(s, str) and bool(IMG_RE.fullmatch(s)) and ".." not in s and not s.startswith("-")


def load_cases(pilot: Path, only_failed: bool = True) -> list[dict]:
    summary = read_json(pilot / "pilot_summary.json")
    entries = summary.get("cases")
    if not isinstance(entries, list):
        raise ValueError("pilot_summary.json does not contain cases[]")
    result = []
    for row in entries:
        cve = row.get("cve", "")
        if not isinstance(cve, str) or not CVE_RE.fullmatch(cve):
            raise ValueError("Malformed CVE in pilot summary: " + repr(cve))
        if only_failed and row.get("build") != "FAILED":
            continue
        case_dir = (pilot / cve).resolve()
        if case_dir.parent != pilot.resolve():
            raise ValueError("Case path escapes pilot: " + cve)
        compose_path = case_dir / "isolated.compose.json"
        if not compose_path.is_file():
            result.append({"cve": cve, "error": "ISOLATED_COMPOSE_MISSING", "images": [], "build_only": []})
            continue
        compose = read_json(compose_path)
        services = compose.get("services")
        if not isinstance(services, dict) or not services:
            raise ValueError("No services for " + cve)
        images, build_only = set(), []
        for service, cfg in services.items():
            if not isinstance(cfg, dict):
                raise ValueError("Invalid service in " + cve)
            image = cfg.get("image")
            if image is None and cfg.get("build"):
                build_only.append(str(service))
            elif image is None:
                raise ValueError(f"No image/build for {cve}:{service}")
            elif not valid_image(image):
                raise ValueError(f"Unexpected image reference in {cve}:{service}")
            if image is not None:
                images.add(image)
        result.append({"cve": cve, "images": sorted(images),
                       "build_only": sorted(build_only), "error": None})
    return result


def inspect_image(image: str) -> dict | None:
    """Return image ID and platform if present; None when not in local store."""
    try:
        p = subprocess.run(["docker", "image", "inspect", image], capture_output=True,
                           text=True, timeout=18, check=False)
        if p.returncode:
            return None
        value = json.loads(p.stdout)
        if not isinstance(value, list) or len(value) != 1 or not value[0].get("Id"):
            return None
        info = value[0]
        return {"id": info["Id"], "platform": str(info.get("Os", "unknown")) + "/" + str(info.get("Architecture", "unknown"))}
    except (subprocess.TimeoutExpired, subprocess.SubprocessError, OSError, ValueError, KeyError):
        return None


def classify(log_tail: str, timed_out: bool, exit_code: int) -> tuple[str, bool]:
    t = log_tail.lower()
    if not exit_code:
        return "PULLED", False
    if any(s in t for s in ("toomanyrequests", "429 too many requests", "rate limit exceeded")):
        return "REGISTRY_RATE_LIMIT", False
    if any(s in t for s in ("no matching manifest", "no match for platform")):
        return "PLATFORM_UNAVAILABLE", False
    if any(s in t for s in ("manifest unknown", "not found: manifest", "repository does not exist", "pull access denied")):
        return "IMAGE_NOT_FOUND_OR_ACCESS_DENIED", False
    if timed_out:
        return "PULL_DEADLINE_EXCEEDED", True
    if ("auth.docker.io" in t or "fetch oauth token" in t) and any(s in t for s in TRANSIENT):
        return "REGISTRY_AUTH_NETWORK_TRANSIENT", True
    if any(s in t for s in TRANSIENT):
        return "REGISTRY_TRANSFER_TRANSIENT", True
    if "unauthorized" in t or "authentication required" in t:
        return "REGISTRY_AUTH_REQUIRED", False
    if "no space left" in t:
        return "DISK_EXHAUSTED", False
    return "PULL_FAILED_UNCLASSIFIED", False


def tail_log(path: Path, limit: int = 10000) -> str:
    if not path.is_file():
        return ""
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        size = f.tell()
        f.seek(max(0, size - limit))
        return f.read().decode("utf-8", "replace")


def pull_image(image: str, log: Path, seconds: int, *, progress: bool = True) -> tuple[int, bool, float]:
    """Run one bounded `docker pull` with output streamed to a durable local log.

    If deadline expires, terminate the CLI process group. Docker daemon can
    still finish or retain layer downloads; never assume cache state until inspect.
    """
    start = time.monotonic()
    timed_out = False
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("wb") as writer:
        os.chmod(log, 0o600)
        proc = subprocess.Popen(["docker", "pull", image], stdout=writer,
                                stderr=subprocess.STDOUT, start_new_session=True)
        last_heartbeat = start
        while True:
            remaining = seconds - (time.monotonic() - start)
            if remaining <= 0:
                timed_out = True
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                    proc.wait(timeout=3)
                except (ProcessLookupError, subprocess.TimeoutExpired):
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    proc.wait()
                break
            try:
                proc.wait(timeout=min(5, remaining))
                break
            except subprocess.TimeoutExpired:
                if progress and (time.monotonic() - last_heartbeat) >= 15:
                    tail = tail_log(log, 1000).replace("\r", "\n")
                    rows = [x.strip() for x in tail.splitlines() if x.strip()]
                    last = re.sub(r"\x1b\[[0-9;]*m", "", rows[-1] if rows else "NO_OUTPUT_YET")
                    print("PULL_PROGRESS image=" + image + " seconds=" + str(int(time.monotonic()-start)) +
                          " last=" + last[:140], flush=True)
                    last_heartbeat = time.monotonic()
    return (124 if timed_out else proc.returncode), timed_out, round(time.monotonic()-start, 2)


def execute(args, *, inspector=inspect_image, puller=pull_image) -> dict:
    pilot = Path(args.pilot).expanduser().resolve()
    if not (pilot / "pilot_summary.json").is_file():
        raise ValueError("PILOT_SUMMARY_NOT_FOUND " + str(pilot))
    cases = load_cases(pilot, only_failed=not args.all_cases)
    out = Path(args.out).expanduser().resolve() if args.out else (pilot.parent /
          ("prefetch-" + dt.datetime.now().strftime("%Y%m%dT%H%M%S"))).resolve()
    if out == pilot or pilot in out.parents:
        raise ValueError("Use a separate output directory, not inside an existing pilot")
    if out.exists() and any(out.iterdir()):
        raise ValueError("OUTPUT_NOT_EMPTY " + str(out))
    out.mkdir(parents=True, exist_ok=True)
    images = sorted({i for c in cases for i in c["images"]})
    report = {"status": "IN_PROGRESS", "source_pilot": str(pilot),
              "requested_cases": len(cases), "images_total": len(images),
              "pulls_enabled": bool(args.pull), "cves": cases, "images": {},
              "proof_executed": False, "docker_services_started": False,
              "notes": ["Only explicit Compose service images are prefetched, not Dockerfile FROM bases",
                        "Cached images are not proof of runtime/service/vulnerability"]}
    atomic_json(out / "prefetch_report.json", report)
    deadline = time.monotonic() + args.total_seconds
    for i, image in enumerate(images):
        existing = inspector(image)
        record = {"image": image, "status": "CACHED" if existing else "MISSING",
                  "inspect": existing, "attempts": []}
        report["images"][image] = record
        atomic_json(out / "prefetch_report.json", report)
        if existing:
            print("CACHED image=" + image + " id=" + existing["id"][:22], flush=True)
            continue
        if not args.pull:
            print("MISSING image=" + image + " (dry-run; use --pull)", flush=True)
            continue
        for attempt in range(1, args.attempts+1):
            left = int(deadline-time.monotonic())
            if left < 2:
                record["status"] = "TOTAL_BUDGET_EXHAUSTED"
                break
            duration = min(args.per_image_seconds, left)
            log = out / (f"image_{i+1:02d}_attempt_{attempt}.log")
            print(f"START_PULL image={image} attempt={attempt}/{args.attempts} budget={duration}s", flush=True)
            try:
                rc, timed_out, elapsed = puller(image, log, duration)
            except (OSError, subprocess.SubprocessError) as e:
                rc, timed_out, elapsed = 127, False, 0
                log.write_text(type(e).__name__ + ": " + str(e), encoding="utf-8")
                os.chmod(log, 0o600)
            info = inspector(image)
            kind, retryable = classify(tail_log(log), timed_out, rc)
            if rc == 0 and info is None:
                kind, retryable = "PULL_EXITED_BUT_IMAGE_NOT_PRESENT", False
            entry = {"attempt": attempt, "classification": kind, "exit_code": rc,
                     "timed_out": timed_out, "seconds": elapsed, "log": str(log),
                     "cached_after_attempt": bool(info)}
            record["attempts"].append(entry)
            if info:
                record.update(status="PRESENT_AFTER_PULL", inspect=info)
                print("PULL_READY image=" + image + " platform=" + info["platform"], flush=True)
            else:
                record["status"] = kind
                print("PULL_FAILED image=" + image + " reason=" + kind + " log=" + str(log), flush=True)
            atomic_json(out / "prefetch_report.json", report)
            if info or not retryable or attempt == args.attempts:
                break
            if deadline-time.monotonic() < 5:
                break
            time.sleep(min(3*attempt, max(0, deadline-time.monotonic()-3)))
    ready = []
    unready = []
    for case in cases:
        if case["error"]:
            unready.append(case["cve"])
            continue
        missing = [image for image in case["images"] if report["images"][image]["inspect"] is None]
        # A Compose `build` without image is not prefetched; distinguish it.
        if not missing and not case["build_only"]:
            ready.append(case["cve"])
        else:
            unready.append(case["cve"])
    (out / "ready_cves.txt").write_text("".join(x+"\n" for x in ready), encoding="utf-8")
    (out / "unready_cves.txt").write_text("".join(x+"\n" for x in unready), encoding="utf-8")
    report.update(status="PREFETCH_COMPLETED_NOT_RUNTIME_PROOF",
                  cached_images=sum(v["inspect"] is not None for v in report["images"].values()),
                  ready_cves=ready, unready_cves=unready, output=str(out))
    atomic_json(out / "prefetch_report.json", report)
    print("\n========== PREFETCH FINAL ==========")
    print("SELECTED_CVES=" + str(len(cases)))
    print("IMAGES_READY=" + str(report["cached_images"]) + "/" + str(len(images)))
    print("CVES_READY_FOR_PILOT=" + str(len(ready)))
    print("CVES_NOT_READY=" + str(len(unready)))
    print("READY_LIST=" + str(out / "ready_cves.txt"))
    print("UNREADY_LIST=" + str(out / "unready_cves.txt"))
    print("REPORT=" + str(out / "prefetch_report.json"))
    print("GPU=NO TRAINING=NO DOCKER_PULL=" + ("YES" if args.pull else "NO"))
    return report


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pilot", required=True, help="Path to previous pilot output directory")
    p.add_argument("--out", help="Fresh output directory, outside the pilot")
    p.add_argument("--pull", action="store_true", help="Explicit permission to run docker pull")
    p.add_argument("--all-cases", action="store_true", help="Include successful cases too (default: failures only)")
    p.add_argument("--per-image-seconds", type=int, default=240)
    p.add_argument("--total-seconds", type=int, default=1500)
    p.add_argument("--attempts", type=int, default=2)
    args = p.parse_args(argv)
    if not 20 <= args.per_image_seconds <= 3600 or not 20 <= args.total_seconds <= 21600 or not 1 <= args.attempts <= 3:
        p.error("Use per-image-seconds 20..3600, total-seconds 20..21600, attempts 1..3")
    if args.pull:
        try:
            probe = subprocess.run(["docker", "info", "--format", "{{.ServerVersion}}"],
                                   capture_output=True, text=True, timeout=15, check=False)
            if probe.returncode:
                print("PREFETCH_FATAL=DOCKER_ENGINE_UNAVAILABLE " + probe.stderr[-300:], file=sys.stderr)
                return 2
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
            print("PREFETCH_FATAL=DOCKER_ENGINE_UNAVAILABLE " + str(e), file=sys.stderr)
            return 2
    try:
        report = execute(args)
    except (ValueError, KeyError, FileNotFoundError, OSError, json.JSONDecodeError) as e:
        print("PREFETCH_FATAL=" + str(e), file=sys.stderr)
        return 2
    return 0 if not report["unready_cves"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
