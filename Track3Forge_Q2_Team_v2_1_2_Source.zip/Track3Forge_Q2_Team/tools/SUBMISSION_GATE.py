#!/usr/bin/env python3
"""Track3Forge Q2: independent Docker submission gate.

Promotes a *previously cleanly redeployed* case to output/main only after
re-hashing the archive, validating its OCI members, validating portable Compose,
and checking all delivery receipts and bundled static assets.
This does not trigger CVE behavior or assert official acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from tools.artifact_audit import audit_archive, verify_file_manifest

CVE = re.compile(r'^CVE-\d{4}-\d{4,}$')
GOOD = {'NEW_REDEPLOY_PASS', 'REUSED_REDEPLOY_PASS'}
BUILD = 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF'
REDO = 'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF'


def load_json(path: Path):
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 16*1024*1024:
        raise ValueError('MISSING_OR_OVERSIZED_JSON: ' + str(path))
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise ValueError('JSON_OBJECT_REQUIRED: ' + str(path))
    return value


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def ensure_file(path: Path, root: Path):
    """Validate a file under root, allowing macOS /var -> /private/var aliases.

    The root may be canonical while an artifact came from tempfile's lexical
    alias.  Verify containment on real paths; independently reject symlinked
    subdirectories *inside* that trusted root.  The host's /var alias above
    the project root is not part of the untrusted artifact tree.
    """
    path = Path(path)
    real_root = Path(root).resolve()
    if path.is_symlink() or not path.is_file():
        raise ValueError('UNSAFE_OR_MISSING_FILE: '+str(path))
    try:
        real_path = path.resolve(strict=True)
        real_path.relative_to(real_root)
    except (ValueError, OSError):
        raise ValueError('UNSAFE_OR_MISSING_FILE: '+str(path)) from None
    for parent in path.absolute().parents:
        if parent.resolve() == real_root:
            break
        if parent.is_symlink():
            raise ValueError('SYMLINK_PARENT: '+str(path))
    else:
        raise ValueError('UNSAFE_OR_MISSING_FILE: '+str(path))


def check_compose(path: Path, *, enabled: bool):
    if not enabled:
        return 'SKIPPED_OFFLINE_TEST'
    try:
        p = subprocess.run(['docker','compose','-f',str(path),'config','--format','json'],
                           capture_output=True,text=True,timeout=30)
    except (OSError,subprocess.TimeoutExpired) as e:
        raise ValueError('DOCKER_COMPOSE_CONFIG_UNAVAILABLE: '+str(e)) from e
    if p.returncode:
        raise ValueError('DOCKER_COMPOSE_CONFIG_FAILED: '+p.stderr[-500:])
    cfg = json.loads(p.stdout)
    if not isinstance(cfg,dict) or not cfg.get('services'):
        raise ValueError('DOCKER_COMPOSE_CONFIG_EMPTY')
    return 'PASS'



def validate_packaged_runtime(compose_file: Path, *, timeout=120):
    """Fresh isolated deployment from the *final staging directory*.

    Independent of the source case's previous redeploy evidence. Never bind
    host ports. Never pull images. Always down the temporary Compose project.
    """
    from track3forge.compose import inspect_services, ready_services
    from track3forge.core import Executor
    cfg=load_json(compose_file)
    for service in cfg.get('services',{}).values():
        if service.get('ports') or service.get('privileged') or service.get('network_mode'):
            raise ValueError('UNSAFE_PACKAGED_SERVICE')
    if not cfg.get('networks',{}).get('default',{}).get('internal'):
        raise ValueError('PACKAGED_INTERNAL_NETWORK_MISSING')
    project='t3pkg'+uuid.uuid4().hex[:10]
    command=['docker','compose','-f',str(compose_file),'-p',project]
    started=time.monotonic()
    result={'project':project,'status':'FAILED','checks':[], 'cleaned_up':False}
    try:
        up=subprocess.run(command+['up','-d','--no-build','--pull','never'],
                          capture_output=True,text=True,timeout=timeout)
        if up.returncode:
            raise ValueError('PACKAGED_COMPOSE_UP_FAILED: '+up.stderr[-600:])
        result['checks'].append('PACKAGED_COMPOSE_STARTED')
        runner=Executor()
        deadline=started+timeout
        names=sorted(cfg['services'])
        while time.monotonic()<deadline:
            state=inspect_services(runner,compose_file,project,names,deadline)
            if ready_services(state):
                result['checks'].append('PACKAGED_SERVICES_RUNNING_AND_HEALTHY')
                result['status']='PASS'
                break
            if any(v.get('status')=='exited' for v in state.values()):
                raise ValueError('PACKAGED_SERVICE_EXITED: '+str(state)[:500])
            time.sleep(2)
        if result['status']!='PASS':
            raise ValueError('PACKAGED_HEALTH_TIMEOUT')
        result['services']=state
    except (ValueError,OSError,subprocess.TimeoutExpired) as exc:
        result['error']=str(exc)[:800]
    finally:
        try:
            down=subprocess.run(command+['down','--remove-orphans'],capture_output=True,
                                text=True,timeout=45)
            result['cleaned_up']=down.returncode==0
            if down.returncode:
                result['cleanup_error']=down.stderr[-400:]
        except (OSError,subprocess.TimeoutExpired) as exc:
            result['cleanup_error']=str(exc)[:400]
        result['seconds']=round(time.monotonic()-started,2)
    if result['status']!='PASS' or not result['cleaned_up']:
        raise ValueError('PACKAGED_RUNTIME_FAILED: '+str(result.get('error') or result.get('cleanup_error')))
    return result

def inspect_candidate(cve: str, rec: dict, project_root: Path, *, validate_archive=True):
    if not CVE.fullmatch(cve) or rec.get('status') not in GOOD:
        raise ValueError('NOT_AN_ELIGIBLE_CVE')
    raw = rec.get('artifact')
    if not isinstance(raw,str) or not raw:
        raise ValueError('NO_ARTIFACT_IN_REPORT')
    artifact = Path(raw)
    ensure_file(artifact, project_root)
    case = artifact.parent
    build = load_json(case/'result.json')
    redeploy = load_json(case/'redeploy_result.json')
    portable = load_json(case/'portable.compose.json')
    if build.get('cve') != cve or build.get('status') != BUILD:
        raise ValueError('BUILD_RECEIPT_NOT_ELIGIBLE')
    if redeploy.get('status') != REDO or redeploy.get('fresh_project') is not True:
        raise ValueError('REDEPLOY_NOT_PROVEN')
    if Path(str(build.get('artifact',''))).resolve() != artifact.resolve():
        raise ValueError('ARTIFACT_RECEIPT_PATH_MISMATCH')
    if not isinstance(portable.get('services'),dict) or not portable['services']:
        raise ValueError('COMPOSE_SERVICES_MISSING')
    if not portable.get('networks',{}).get('default',{}).get('internal'):
        raise ValueError('COMPOSE_ISOLATION_MISSING')
    for service in portable['services'].values():
        if not isinstance(service,dict) or not service.get('image') or 'build' in service:
            raise ValueError('COMPOSE_NOT_SELF_CONTAINED')
        if service.get('ports') or service.get('privileged') or service.get('network_mode'):
            raise ValueError('UNSAFE_COMPOSE_SERVICE')
    for field, val in [('build.archive_sha256',build.get('archive_sha256')),
                        ('redeploy.image_archive_sha256',redeploy.get('image_archive_sha256')),
                        ('batch.artifact_sha256_recorded',rec.get('artifact_sha256_recorded'))]:
        if val is not None and not re.fullmatch(r'[a-f0-9]{64}',str(val)):
            raise ValueError('BAD_SHA256_FIELD: '+field)
    actual = sha(artifact)
    for val in [build.get('archive_sha256'),redeploy.get('image_archive_sha256'),rec.get('artifact_sha256_recorded')]:
        if val and actual != val:
            raise ValueError('ARCHIVE_SHA256_MISMATCH')
    if not build.get('archive_sha256') or not redeploy.get('image_archive_sha256'):
        raise ValueError('RECEIPT_SHA256_MISSING')
    result = audit_archive(artifact) if validate_archive else {'status':'SKIPPED_FOR_TEST'}
    if result['status'] not in ('PASS','SKIPPED_FOR_TEST'):
        raise ValueError('ARCHIVE_INTEGRITY_FAILED: '+str(result.get('errors'))[:320])
    extras = []
    for name in ('image_inventory.json','delivery_assets.json','pilot_receipt.json'):
        path=case/name
        if path.exists():
            ensure_file(path,project_root)
            extras.append(path)
    assets=case/'delivery_bind_assets'
    if assets.exists():
        if assets.is_symlink() or not assets.is_dir():
            raise ValueError('UNSAFE_DELIVERY_ASSETS')
        for path in sorted(assets.rglob('*')):
            if path.is_symlink():
                raise ValueError('SYMLINK_IN_DELIVERY_ASSETS')
            if path.is_file():
                ensure_file(path,project_root)
                extras.append(path)
    bind_report=case/'delivery_assets.json'
    if bind_report.exists():
        br=load_json(bind_report)
        if br.get('portability_blockers'):
            raise ValueError('PORTABILITY_BLOCKERS')
        for entry in br.get('packaged_static_binds',[]):
            rel=entry.get('relative_path','')
            path=case/rel
            ensure_file(path,project_root)
            if path.stat().st_size != entry.get('size_bytes') or sha(path) != entry.get('sha256'):
                raise ValueError('DELIVERY_BIND_HASH_MISMATCH')
    proofs = []
    for path in (case/'proof').rglob('*.json') if (case/'proof').is_dir() else []:
        ensure_file(path,project_root)
        proofs.append(path)
    # Historical proof JSON is carried only as an attachment, never re-asserted.
    return {'artifact':artifact,'case':case,'portable':portable,'build':build,
            'redeploy':redeploy,'archive_hash':actual,'integrity':result,
            'extras':extras,'proofs':proofs}


def transfer(source: Path, dest: Path, *, mode='hardlink'):
    dest.parent.mkdir(parents=True,exist_ok=True)
    if mode == 'hardlink':
        try:
            os.link(source,dest)
            return 'HARDLINK'
        except OSError:
            pass
    shutil.copy2(source,dest)
    return 'COPY'


def inventory_files(folder: Path) -> list[dict]:
    rows=[]
    for path in sorted(folder.rglob('*')):
        if path.is_symlink():
            raise ValueError('SYMLINK_IN_SUBMISSION')
        if path.is_file() and path != folder/'manifest.json':
            rows.append({'path':path.relative_to(folder).as_posix(),
                         'size':path.stat().st_size,'sha256':sha(path)})
    return rows


def write_json(path: Path, obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n', encoding='utf-8')


def promote_one(cve: str, rec: dict, project_root: Path, main: Path, rejected: Path,
                *, mode='hardlink', docker_parse=True, validate_archive=True, runtime_validate=False):
    candidate=inspect_candidate(cve,rec,project_root,validate_archive=validate_archive)
    existing=main/cve
    if existing.is_dir():
        try:
            manifest=existing/'manifest.json'
            if (load_json(existing/'validation.json').get('source_archive_sha256')==candidate['archive_hash']
                    and (not runtime_validate or
                         load_json(existing/'validation.json').get('packaged_runtime')=='PASS')
                    and load_json(existing/'submission.json').get('cve')==cve
                    and manifest.is_file() and all(x['status']=='PASS' for x in verify_file_manifest(manifest))
                    and (existing/'docker-images.tar').is_file()):
                return {'cve':cve,'status':'MAIN_ALREADY_VALID','path':str(existing)}
        except (ValueError,OSError):
            pass
    temp=main/('.staging-'+cve+'-'+str(os.getpid()))
    if temp.exists():
        rejected.mkdir(parents=True,exist_ok=True)
        interrupted=rejected/(cve+'-interrupted-'+uuid.uuid4().hex[:10])
        temp.rename(interrupted)
    temp.mkdir(parents=True)
    try:
        transfer(candidate['artifact'],temp/'docker-images.tar',mode=mode)
        for name in ('result.json','redeploy_result.json','portable.compose.json'):
            transfer(candidate['case']/name,temp/name,mode='copy')
        for path in candidate['extras']+candidate['proofs']:
            rel=path.relative_to(candidate['case'])
            transfer(path,temp/rel,mode='copy')
        # JSON mapping is also valid YAML 1.2; use explicit docker compose parser check.
        shutil.copy2(temp/'portable.compose.json',temp/'docker-compose.yml')
        parsed=check_compose(temp/'docker-compose.yml',enabled=docker_parse)
        packaged_runtime=(validate_packaged_runtime(temp/'docker-compose.yml')
                          if runtime_validate else {'status':'NOT_TESTED_THIS_PASS'})
        write_json(temp/'packaged_runtime.json',packaged_runtime)
        if sha(temp/'docker-images.tar')!=candidate['archive_hash']:
            raise ValueError('TRANSFERRED_ARCHIVE_SHA256_MISMATCH')
        write_json(temp/'submission.json',{
            'schema':'track3forge-q2-delivery-v2.1',
            'cve':cve,'artifact':'docker-images.tar','compose':'docker-compose.yml',
            'artifact_sha256':candidate['archive_hash'],
            'service_redeploy_receipt':REDO,
            'vulnerability_behavior_verified':False,'official_accepted':None,
        })
        write_json(temp/'validation.json',{
            'cve':cve,'status':'DELIVERY_ARCHIVE_AND_CLEAN_REDEPLOY_VERIFIED',
            'archive_content_integrity':candidate['integrity'],
            'source_archive_sha256':candidate['archive_hash'],
            'docker_compose_parser':parsed,'service_redeploy_receipt':REDO,
            'packaged_runtime':packaged_runtime['status'],
            'vulnerability_behavior_revalidated':False,'official_accepted':None,
            'source_case':str(candidate['case']),
        })
        (temp/'README.md').write_text(
            '# '+cve+' Docker 环境交付\n\n'
            '此目录已核对 OCI 归档和历史清洁重新部署回执。并不代表漏洞行为或官方验收已经通过。\n\n'
            '```bash\n'
            'docker load -i docker-images.tar\n'
            'docker compose -f docker-compose.yml up -d --no-build --pull never\n'
            'docker compose -f docker-compose.yml ps\n'
            'docker compose -f docker-compose.yml down\n'
            '```\n\n'
            '请仅在隔离授权实验环境中部署；不要将容器端口公开。\n', encoding='utf-8')
        write_json(temp/'manifest.json',inventory_files(temp))
        checks=verify_file_manifest(temp/'manifest.json')
        if not checks or any(v['status']!='PASS' for v in checks):
            raise ValueError('FINAL_MANIFEST_HASH_CHECK_FAILED')
        if existing.exists():
            rejected.mkdir(parents=True,exist_ok=True)
            stale=rejected/(cve+'-replaced-'+str(int(time.time())))
            if stale.exists():
                raise ValueError('REJECTED_NAME_CONFLICT')
            existing.rename(stale)
        temp.rename(existing)
        return {'cve':cve,'status':'MAIN_READY','path':str(existing),
                'sha256':candidate['archive_hash'],'docker_compose_parser':parsed}
    except Exception:
        if temp.exists():
            shutil.rmtree(temp)
        raise


def package_report(report_path: Path, project_root: Path, out_root: Path,
                   *, minimum=20, mode='hardlink', docker_parse=True, validate_archive=True, runtime_validate=False):
    report=load_json(report_path)
    cves=report.get('cves')
    if not isinstance(cves,list) or not cves or len(set(cves))!=len(cves) or any(not isinstance(c,str) or not CVE.fullmatch(c) for c in cves):
        raise ValueError('INVALID_CVE_LIST_IN_REPORT')
    case_map=report.get('cases')
    if not isinstance(case_map,dict):
        raise ValueError('MISSING_BATCH_CASES')
    main=out_root/'main'; rejected=out_root/'rejected'; main.mkdir(parents=True,exist_ok=True)
    results=[]
    for i,cve in enumerate(cves,1):
        rec=case_map.get(cve,{})
        print(f'PACKAGING={i}/{len(cves)} {cve}',flush=True)
        if rec.get('status') not in GOOD:
            row={'cve':cve,'status':'NOT_DELIVERED','reason':rec.get('reason') or rec.get('status','UNKNOWN')}
        else:
            try:
                row=promote_one(cve,rec,project_root,main,rejected,mode=mode,
                                docker_parse=docker_parse,validate_archive=validate_archive,
                                runtime_validate=runtime_validate)
            except (ValueError,RuntimeError,OSError,json.JSONDecodeError) as e:
                row={'cve':cve,'status':'REJECTED','reason':str(e)[:500]}
        results.append(row)
        print('PACKAGE_RESULT '+json.dumps(row,ensure_ascii=False),flush=True)
    ready=sum(r['status'] in {'MAIN_READY','MAIN_ALREADY_VALID'} for r in results)
    gate=ready>=minimum
    summary={'schema':'track3forge-q2-submissions-v2.1','requested':len(cves),
             'ready':ready,'minimum':minimum,'gate':'PASS' if gate else 'BELOW_TARGET',
             'environment_redeploy_evidence':'HISTORICAL_AND_NEW_RECEIPTS',
             'behavior_verified_this_pass':0,'official_accepted':None,
             'source_batch_report':str(report_path.resolve()),'cases':results}
    write_json(out_root/'summary.json',summary)
    (out_root/'ready_cves.txt').write_text(''.join(r['cve']+'\n' for r in results if r['status'] in {'MAIN_READY','MAIN_ALREADY_VALID'}))
    (out_root/'pending_cves.txt').write_text(''.join(r['cve']+'\n' for r in results if r['status'] not in {'MAIN_READY','MAIN_ALREADY_VALID'}))
    print('========== Q2 SUBMISSION FINAL ==========',flush=True)
    print(f'REQUESTED={len(cves)}\nMAIN_READY={ready}\nMINIMUM={minimum}\nDELIVERY_GATE={summary["gate"]}',flush=True)
    print('CVE_BEHAVIOR_VERIFIED_THIS_PASS=0\nOFFICIAL_ACCEPTANCE=UNKNOWN',flush=True)
    print('MAIN_DIR='+str(main)+'\nSUMMARY='+str(out_root/'summary.json')+'\nFINISHED=YES',flush=True)
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--report',type=Path,required=True)
    p.add_argument('--out-root',type=Path,required=True)
    p.add_argument('--project-root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--minimum',type=int,default=20)
    p.add_argument('--copy-mode',choices=['hardlink','copy'],default='hardlink')
    p.add_argument('--no-docker-parse',action='store_true')
    p.add_argument('--validate-package-runtime',action='store_true')
    a=p.parse_args()
    try:
        res=package_report(a.report,a.project_root.resolve(),a.out_root.resolve(),minimum=a.minimum,
                           mode=a.copy_mode,docker_parse=not a.no_docker_parse,
                           runtime_validate=a.validate_package_runtime)
        return 0 if res['gate']=='PASS' else 2
    except (ValueError,OSError,json.JSONDecodeError) as e:
        print('PACKAGE_FAILED='+str(e),file=sys.stderr)
        return 3

if __name__=='__main__':
    raise SystemExit(main())
