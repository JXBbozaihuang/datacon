#!/usr/bin/env python3
"""Track3Forge v1.7: resumable, CVE-agnostic Q2 environment benchmark.

Only asserts proven build/export/redeploy receipts. Never executes a CVE exploit.
No explicit registry prefetch unless --allow-pull; source builds may use
network even with cached base images. No Docker execution unless
--execute --ack-lab. Existing evidence is linked, not modified or overwritten.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tools'))

from track3forge import catalog, compose
from track3forge.core import Executor, TaskError, json_write

STATUS_DONE = {'REUSED_REDEPLOY_PASS', 'NEW_REDEPLOY_PASS'}
BUILD_OK = 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF'
REDEPLOY_OK = 'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF'
SCHEMA = 'track3forge-batch30-v1.7'
CSV_FIELDS = ('cve', 'status', 'build', 'redeploy', 'proof', 'provenance',
              'reason', 'seconds', 'image_platforms', 'evidence')


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise ValueError(f'JSON_OBJECT_REQUIRED {path}')
    return value


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def digest_cves(cves: list[str]) -> str:
    return hashlib.sha256(('\n'.join(cves) + '\n').encode()).hexdigest()


def evidence_for_case(case: Path, expected_cve: str) -> dict | None:
    """Reuse only actual archived material and a successful redeploy receipt.

    Does not treat stale pilot_summary.json, missing tar, or unscoped proof JSON
    as success. It intentionally does not rehash large tar files on Mac.
    """
    case = case.resolve()
    buildfile = case / 'result.json'
    redo = case / 'redeploy_result.json'
    if not (buildfile.is_file() and redo.is_file()):
        return None
    try:
        b, r = read_json(buildfile), read_json(redo)
        if b.get('cve') != expected_cve or b.get('status') != BUILD_OK or r.get('status') != REDEPLOY_OK:
            return None
        artifact = Path(str(b.get('artifact', ''))).resolve()
        if artifact.parent != case or not artifact.is_file() or artifact.stat().st_size < 512:
            return None
        if not isinstance(b.get('archive_sha256'), str) or len(b['archive_sha256']) != 64:
            return None
    except (ValueError, OSError, KeyError, TypeError):
        return None
    proof = 'NOT_VERIFIED'
    proof_path = None
    for rel in ('proof/known/known_proof.json', 'proof/apache/apache_proof.json',
                'proof/activemq/activemq_proof.json'):
        p = case / rel
        if not p.is_file():
            continue
        try:
            d = read_json(p)
            if (d.get('cve') == expected_cve and d.get('status') == 'BEHAVIOR_VERIFIED'
                    and d.get('vulnerability_verified') is True):
                proof, proof_path = 'VERIFIED_PREVIOUS_EVIDENCE', str(p.resolve())
                break
        except (OSError, ValueError, KeyError):
            continue
    return {
        'cve': expected_cve, 'status': 'REUSED_REDEPLOY_PASS',
        'build': BUILD_OK, 'redeploy': REDEPLOY_OK, 'proof': proof,
        'provenance': 'REUSED_PREVIOUS_RECEIPTS', 'reason': None,
        'seconds': 0, 'image_platforms': {},
        'evidence': str(case), 'artifact': str(artifact),
        'artifact_sha256_recorded': b['archive_sha256'],
        'artifact_rehashed': False, 'proof_file': proof_path,
        'last_updated': utc_now(), 'attempts': [],
    }


def reuse_candidates(runs_dir: Path, cves: list[str]) -> dict[str, dict]:
    """Find eligible earlier pilots; favor verified evidence and newer receipts.

    Never changes or deletes prior runs. An unrelated JSON in runs is ignored.
    """
    candidates = {}
    allowed = set(cves)
    if not runs_dir.is_dir():
        return candidates
    for folder in sorted(runs_dir.glob('pilot-*')):
        if not folder.is_dir() or not (folder / 'pilot_summary.json').is_file():
            continue
        try:
            summary = read_json(folder / 'pilot_summary.json')
        except (OSError, ValueError):
            continue
        for entry in summary.get('cases', []):
            if not isinstance(entry, dict):
                continue
            cve = entry.get('cve')
            if cve not in allowed:
                continue
            item = evidence_for_case(folder / cve, cve)
            if item is None:
                continue
            prev = candidates.get(cve)
            rank = (int(item['proof'] == 'VERIFIED_PREVIOUS_EVIDENCE'),
                    (folder / cve / 'redeploy_result.json').stat().st_mtime)
            if prev is None or rank > prev[0]:
                candidates[cve] = (rank, item)
    return {cve: item for cve, (_, item) in candidates.items()}


def docker_cached(image: str, *, runner=None) -> dict | None:
    runner = runner or Executor()
    try:
        res = runner.run(['docker', 'image', 'inspect', image], timeout=20, check=False)
        if res.returncode:
            return None
        objects = json.loads(res.stdout)
        if not isinstance(objects, list) or len(objects) != 1 or not objects[0].get('Id'):
            return None
        obj = objects[0]
        return {'id': obj['Id'], 'platform': str(obj.get('Os', 'unknown')) + '/' +
                str(obj.get('Architecture', 'unknown'))}
    except (TaskError, ValueError, KeyError, TypeError, OSError):
        return None



def dockerfile_bases(build: Any) -> tuple[list[str], list[str]]:
    """Extract concrete FROM images; uncertainty is reported, never hidden.

    This is only a cheap preflight. Dockerfile RUN and remote ADD may still
    require network; a clean cache is not a full offline-build guarantee.
    """
    if isinstance(build, str):
        context, dockerfile = Path(build), Path(build) / 'Dockerfile'
    elif isinstance(build, dict):
        context = Path(str(build.get('context', '')))
        requested = Path(str(build.get('dockerfile', 'Dockerfile')))
        dockerfile = requested if requested.is_absolute() else context / requested
    else:
        return [], ['INVALID_BUILD_CONFIG']
    if not dockerfile.is_file() or dockerfile.is_symlink():
        return [], ['DOCKERFILE_NOT_A_REGULAR_FILE']
    try:
        content = dockerfile.read_text(encoding='utf-8')
    except (UnicodeError, OSError):
        return [], ['DOCKERFILE_UNREADABLE']
    args: dict[str, str] = {}
    stages: set[str] = set()
    bases: set[str] = set()
    unresolved: list[str] = []
    # Typical build args can be resolved locally; caller-specific --build-arg
    # overrides are deliberately not guessed.
    for source_line in content.splitlines():
        line = source_line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        command = parts[0].upper()
        if command == 'ARG' and len(parts) > 1 and '=' in parts[1]:
            k, v = parts[1].split('=', 1)
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', k):
                args[k] = v
            continue
        if command != 'FROM':
            continue
        payload = parts[1:]
        while payload and payload[0].startswith('--'):
            payload = payload[1:]
        if not payload:
            unresolved.append('FROM_MISSING_IMAGE')
            continue
        image = payload[0]
        for name, val in args.items():
            image = image.replace('${'+name+'}', val).replace('$'+name, val)
        if '$' in image or '{' in image or '}' in image:
            unresolved.append('DYNAMIC_FROM')
            continue
        if image.lower() != 'scratch' and image.lower() not in stages:
            bases.add(image)
        if len(payload) >= 3 and payload[1].upper() == 'AS':
            stages.add(payload[2].lower())
    if not bases and not unresolved:
        unresolved.append('NO_FROM_PARSED')
    return sorted(bases), sorted(set(unresolved))


def inspect_recipe(cve: str, source: Path, *, runner=None, memory='2g') -> dict:
    """Describe audited Compose inputs, without starting CVE containers."""
    runner = runner or Executor()
    recipes = catalog.find_recipes(source, cve)
    if not recipes:
        return {'status': 'NO_RECIPE', 'reason': 'NO_EXACT_COMPOSE_RECIPE',
                'images': [], 'build_services': [], 'recipe': None}
    recipe = recipes[0]
    try:
        config = compose.parse_compose(recipe, runner, deadline=time.monotonic() + 60)
        safe, flags = compose.sanitize(config, source, service_memory=memory)
        image_refs = set()
        build_services = []
        build_uncertainty = []
        for service, info in safe['services'].items():
            if 'build' in info:
                build_services.append(service)
                bases, unknown = dockerfile_bases(info['build'])
                image_refs.update(bases)
                build_uncertainty.extend(service + ':' + item for item in unknown)
                continue  # a build service may synthesize its own image tag
            image = info.get('image')
            if not isinstance(image, str) or not image.strip():
                raise TaskError('IMAGE_REFERENCE_MISSING', f'{service}: neither image nor build')
            image_refs.add(image)
        return {'status': 'RECIPE_VALIDATED', 'reason': None,
                'images': sorted(image_refs), 'build_services': sorted(build_services),
                'build_uncertainty': build_uncertainty, 'recipe': str(recipe), 'sanitization_flags': flags,
                'possible_build_base_pulls': bool(build_services)}
    except (TaskError, ValueError, KeyError, OSError) as e:
        return {'status': 'RECIPE_INVALID',
                'reason': getattr(e, 'code', type(e).__name__), 'detail': str(e)[:500],
                'images': [], 'build_services': [], 'recipe': str(recipe)}


def classify_registry(record: dict) -> bool:
    """Only count connection/auth/transfer faults toward a circuit breaker."""
    return record.get('failure') in ('REGISTRY_AUTH_NETWORK_TRANSIENT',
                                      'REGISTRY_TRANSFER_TRANSIENT')


def try_pull(image: str, folder: Path, *, budget: int, puller=None, inspector=None) -> dict:
    from PREFETCH_MISSING import pull_image, classify, tail_log
    puller = puller or pull_image
    inspector = inspector or docker_cached
    folder.mkdir(parents=True, exist_ok=True)
    stem = 'pull_' + hashlib.sha256(image.encode()).hexdigest()[:16]
    log = folder / (stem + '.log')
    suffix = 1
    while log.exists():
        log = folder / (stem + f'_retry{suffix:03d}.log')
        suffix += 1
    try:
        code, timed_out, seconds = puller(image, log, budget, progress=True)
    except (OSError, subprocess.SubprocessError) as exc:
        code, timed_out, seconds = 127, False, 0
        log.write_text(f'{type(exc).__name__}: {exc}\n', encoding='utf-8')
    cache = inspector(image)
    if cache:
        return {'ok': True, 'failure': None, 'log': str(log), 'seconds': seconds,
                'image': image, 'cache': cache}
    failure, _ = classify(tail_log(log), timed_out, code)
    return {'ok': False, 'failure': failure, 'log': str(log), 'seconds': seconds,
            'image': image, 'cache': None}


def save_report(out: Path, report: dict) -> None:
    cases = report['cases']
    total = len(report['cves'])
    vals = list(cases.values())
    def count(fn):
        return sum(bool(fn(c)) for c in vals)
    report['summary'] = {
        'requested': total,
        'completed_deliveries': count(lambda v: v.get('status') in STATUS_DONE),
        'reused_deliveries': count(lambda v: v.get('status') == 'REUSED_REDEPLOY_PASS'),
        'new_deliveries': count(lambda v: v.get('status') == 'NEW_REDEPLOY_PASS'),
        'exported': count(lambda v: v.get('build') == BUILD_OK),
        'proofs_from_existing_evidence': count(lambda v: v.get('proof') == 'VERIFIED_PREVIOUS_EVIDENCE'),
        'blocked_registry': count(lambda v: v.get('status') == 'BLOCKED_REGISTRY'),
        'pending': total - count(lambda v: v.get('status') in STATUS_DONE),
        'attempted_new_runs': sum(len(v.get('attempts', [])) for v in vals),
        'not_claimed_as_official': True,
    }
    report['updated_at'] = utc_now()
    json_write(out / 'batch30_report.json', report)
    with (out / 'batch30_summary.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction='ignore')
        w.writeheader()
        for cve in report['cves']:
            w.writerow({'cve': cve, **cases.get(cve, {})})
    files = {
        'ready': [cve for cve in report['cves'] if cases.get(cve, {}).get('status') in STATUS_DONE],
        'blocked': [cve for cve in report['cves'] if cases.get(cve, {}).get('status') == 'BLOCKED_REGISTRY'],
        'pending': [cve for cve in report['cves'] if cases.get(cve, {}).get('status') not in STATUS_DONE],
    }
    for name, entries in files.items():
        (out / (name + '_cves.txt')).write_text(''.join(c + '\n' for c in entries), encoding='utf-8')


def init_report(cves: list[str], source: Path, out: Path, *, resume=False, reuse=None) -> dict:
    source = Path(source).expanduser().resolve()
    target = out / 'batch30_report.json'
    if resume:
        if not target.is_file():
            raise ValueError('RESUME_REPORT_MISSING: ' + str(target))
        report = read_json(target)
        saved_source = report.get('source')
        same_source = isinstance(saved_source, str) and bool(saved_source) and Path(saved_source).expanduser().resolve() == source
        if report.get('schema') != SCHEMA or not same_source or report.get('cves_sha256') != digest_cves(cves):
            raise ValueError('RESUME_INPUT_MISMATCH: CVEs/source differ from original run')
        return report
    if out.exists() and any(out.iterdir()):
        raise ValueError('OUTPUT_NOT_EMPTY (use --resume for same directory)')
    out.mkdir(parents=True, exist_ok=True)
    report = {
        'schema': SCHEMA, 'started_at': utc_now(), 'updated_at': utc_now(),
        'source': str(source), 'cves': cves, 'cves_sha256': digest_cves(cves),
        'runs_reused_without_rehash': True, 'verification_policy':
        'Only explicit independent audited proof files count. Batch never triggers exploit or declares official acceptance.',
        'cases': {}, 'registry_image_cache': {}, 'registry_circuit': {'failures': 0, 'open': False},
    }
    for cve, item in (reuse or {}).items():
        report['cases'][cve] = item
    save_report(out, report)
    return report


def step_report(report: dict, out: Path, cve: str, data: dict) -> None:
    report['cases'][cve] = data
    save_report(out, report)
    print(f"{cve:<20} STATUS={data['status']:<27} "
          f"BUILD={data.get('build','NOT_RUN'):<35} "
          f"REDEPLOY={data.get('redeploy','NOT_RUN')} "
          f"REASON={data.get('reason') or '-'}", flush=True)


def default_case(cve: str) -> dict:
    return {'cve': cve, 'status': 'NOT_RUN', 'build': 'NOT_RUN',
            'redeploy': 'NOT_RUN', 'proof': 'NOT_EVALUATED', 'provenance': 'NEW_BATCH',
            'reason': None, 'seconds': 0, 'image_platforms': {}, 'evidence': None,
            'attempts': [], 'last_updated': utc_now()}


def compute_preflight(args, *, runner=None, reuse_override=None, dry_run=True) -> dict:
    """Deterministic plan, no pulling/building. Useful for mocked integration."""
    runner = runner or Executor()
    cves = catalog.read_cves(args.cves)
    if len(cves) > 30:
        raise ValueError('MAX_CVE_BATCH=30; split larger lists into separate batches')
    source = Path(args.source).expanduser().resolve()
    if not source.is_dir():
        raise ValueError('SOURCE_MISSING ' + str(source))
    out = Path(args.out).expanduser().resolve()
    reused = reuse_override if reuse_override is not None else (
        reuse_candidates(Path(args.runs_dir).resolve(), cves) if args.reuse_all else {})
    report = init_report(cves, source, out, resume=args.resume, reuse=reused)
    cache = report['registry_image_cache']
    for cve in cves:
        existing = report['cases'].get(cve)
        if existing and existing['status'] in STATUS_DONE:
            continue
        # Resume never silently overwrites a failed or blocked receipt.
        if args.resume and existing and existing['status'] in ('RUN_FAILED', 'PREFLIGHT_FAILED', 'DELIVERY_BLOCKED') and not args.retry_blocked:
            continue
        record = (existing or default_case(cve)).copy()
        record['attempts'] = list(record.get('attempts') or [])
        stage = inspect_recipe(cve, source, runner=runner, memory=args.service_memory)
        record['preflight'] = stage
        if stage['status'] != 'RECIPE_VALIDATED':
            record.update(status='NO_RECIPE' if stage['status']=='NO_RECIPE' else 'PREFLIGHT_FAILED',
                          reason=stage.get('reason'), build='NOT_RUN', redeploy='NOT_RUN')
        else:
            missing = []
            platforms = {}
            for image in stage['images']:
                info = docker_cached(image, runner=runner)
                if info:
                    platforms[image] = info['platform']
                    cache[image] = {'status': 'CACHED', **info}
                else:
                    missing.append(image)
                    cache[image] = {'status': 'NOT_CACHED'}
            record['image_platforms'] = platforms
            record['missing_images'] = missing
            unknown = stage.get('build_uncertainty') or []
            record.update(status='BLOCKED_REGISTRY' if missing or unknown else 'READY_TO_RUN',
                          reason='IMAGE_NOT_CACHED' if missing else ('BUILD_BASE_UNRESOLVED' if unknown else None))
        record['last_updated'] = utc_now()
        step_report(report, out, cve, record)
    return report


def execution_order(report: dict) -> list[str]:
    # Run cached recipes first; preserve original order within priority groups.
    priority = {'READY_TO_RUN': 0, 'BLOCKED_REGISTRY': 1}
    return sorted(report['cves'], key=lambda cve:
                  priority.get(report['cases'].get(cve, {}).get('status'), 2))


def execute_batch(args, *, runner=None, pilot_runner=None, puller=None) -> dict:
    """Run only eligible cases, with bounded single-image pulls and resume.

    A registry circuit breaker blocks only uncached images; cached or
    build-only recipes continue even after a network failure.
    """
    if not args.ack_lab:
        raise ValueError('LAB_ACK_REQUIRED: use --ack-lab')
    runner = runner or Executor()
    result = runner.run(['docker', 'info', '--format', '{{.ServerVersion}}'], timeout=20)
    if not result.stdout.strip():
        raise ValueError('DOCKER_INFO_EMPTY')
    report = compute_preflight(args, runner=runner)
    out = Path(args.out).expanduser().resolve()
    source = Path(args.source).expanduser().resolve()
    deadline = time.monotonic() + args.total_seconds
    completed_new = 0
    image_map = report['registry_image_cache']
    if args.resume and args.retry_blocked and args.allow_pull:
        report['registry_circuit'] = {'failures': 0, 'open': False}
    circuit = report['registry_circuit']
    pulled_this_execution: set[str] = set()
    from track3forge.pilot import run_pilot
    pilot_runner = pilot_runner or run_pilot
    schedule=execution_order(report)
    print('EXECUTION_PRIORITY=CACHED_READY_FIRST', flush=True)
    print('EXECUTION_ORDER='+','.join(schedule),flush=True)
    for cve in schedule:
        record = report['cases'].get(cve) or default_case(cve)
        if record['status'] in STATUS_DONE:
            continue
        if args.resume and record.get('attempts') and not args.retry_blocked:
            continue
        if completed_new >= args.max_new:
            continue
        if deadline - time.monotonic() < 25:
            record.update(status='GLOBAL_BUDGET_EXHAUSTED', reason='GLOBAL_BUDGET_EXHAUSTED')
            step_report(report, out, cve, record)
            continue
        stage = record.get('preflight') or inspect_recipe(cve, source, runner=runner)
        if stage['status'] != 'RECIPE_VALIDATED':
            continue
        missing = []
        platforms = {}
        for image in stage['images']:
            inspected = docker_cached(image, runner=runner)
            if inspected:
                platforms[image] = inspected['platform']
                image_map[image] = {'status': 'CACHED', **inspected}
                continue
            if not args.allow_pull or circuit['open']:
                missing.append(image)
                continue
            # Avoid duplicate pulls inside one process, but allow explicit
            # --resume --retry-blocked to retry after connectivity recovers.
            if image in pulled_this_execution:
                missing.append(image)
                continue
            remaining = int(deadline-time.monotonic())
            if remaining < 30:
                missing.append(image)
                continue
            pulled_this_execution.add(image)
            pull_info = try_pull(image, out/'registry_logs',
                                 budget=min(args.per_image_seconds, remaining),
                                 puller=puller,
                                 inspector=lambda x: docker_cached(x, runner=runner))
            if pull_info['ok']:
                platforms[image] = pull_info['cache']['platform']
                image_map[image] = {'status': 'CACHED', **pull_info['cache']}
                circuit['failures'] = 0
            else:
                missing.append(image)
                image_map[image] = {'status': 'PULL_FAILED', **pull_info}
                if classify_registry(pull_info):
                    circuit['failures'] += 1
                    if circuit['failures'] >= args.registry_fail_threshold:
                        circuit['open'] = True
                else:
                    circuit['failures'] = 0
            save_report(out, report)
        record['image_platforms'] = platforms
        if stage.get('build_uncertainty') and not args.allow_pull:
            record.update(status='BLOCKED_REGISTRY', reason='BUILD_BASE_UNRESOLVED',
                          missing_images=missing, last_updated=utc_now())
            step_report(report, out, cve, record)
            continue
        if missing:
            record.update(status='BLOCKED_REGISTRY',
                          reason=('REGISTRY_CIRCUIT_OPEN' if circuit['open'] else
                                  'IMAGE_NOT_CACHED_OR_PULL_FAILED'),
                          missing_images=missing,
                          last_updated=utc_now())
            step_report(report, out, cve, record)
            continue
        record['status'] = 'RUNNING'; record['reason'] = None
        attempt = len(record.get('attempts', [])) + 1
        case_run = out / 'execution' / cve / f'attempt_{attempt:02d}'
        if case_run.exists() and any(case_run.iterdir()):
            # A previous process was interrupted after mkdir but before receipt.
            attempt += 1
            case_run = out / 'execution' / cve / f'attempt_{attempt:02d}'
        record['active_execution'] = str(case_run)
        step_report(report, out, cve, record)
        started = time.monotonic()
        remaining = int(deadline-started)
        try:
            actual = pilot_runner([cve], source, case_run,
                        limit=1, per_cve_seconds=min(args.per_cve_seconds, max(20,remaining-40)),
                        redeploy_seconds=min(args.redeploy_seconds,max(20,remaining-40)),
                        total_seconds=min(remaining, args.per_cve_seconds + args.redeploy_seconds + 50),
                        service_memory=args.service_memory, ack_lab=True,
                        agent=getattr(args, 'agent', False),
                        start_ollama=getattr(args, 'start_ollama', False),
                        model=getattr(args, 'model', None),
                        min_disk_gb=args.min_disk_gb, runner=runner)
            row = actual['cases'][0]
            new_attempt = {'execution': str(case_run), 'build': row.get('build'),
                           'redeploy': row.get('redeploy'), 'error_code':
                           row.get('error_code') or row.get('redeploy_error_code'),
                           'seconds': row.get('seconds')}
            record.setdefault('attempts', []).append(new_attempt)
            claimed_complete = row.get('build') == BUILD_OK and row.get('redeploy') == REDEPLOY_OK
            validated = evidence_for_case(case_run/cve, cve) if claimed_complete else None
            # A returned PASS string alone cannot establish delivery. Require
            # the actual image tar + original and redeploy receipts on disk.
            case_status = ('NEW_REDEPLOY_PASS' if validated else
                           ('DELIVERY_BLOCKED' if row.get('build')==BUILD_OK and
                            row.get('redeploy')=='BLOCKED_EXTERNAL_DATA_NOT_PACKAGED'
                            else 'RUN_FAILED'))
            record.update(build=row.get('build','FAILED'),
                          redeploy=row.get('redeploy','NOT_RUN'),
                          reason=('DELIVERY_RECEIPT_MISSING' if claimed_complete and not validated
                                  else new_attempt['error_code']),
                          seconds=round(time.monotonic()-started, 2),
                          evidence=str(case_run/'pilot_summary.json'),
                          status=case_status,
                          active_execution=None, last_updated=utc_now())
            if validated:
                record['artifact'] = validated['artifact']
                record['artifact_sha256_recorded'] = validated['artifact_sha256_recorded']
                record['artifact_rehashed'] = False
            completed_new += 1
        except (TaskError, OSError, ValueError, KeyError, TypeError) as e:
            record.setdefault('attempts', []).append({'execution': str(case_run),
                  'error_code': getattr(e,'code',type(e).__name__),
                  'seconds':round(time.monotonic()-started,2)})
            record.update(status='RUN_FAILED', reason=getattr(e,'code',type(e).__name__),
                          seconds=round(time.monotonic()-started,2),
                          active_execution=None, last_updated=utc_now())
            completed_new += 1
        step_report(report, out, cve, record)
    report['ended_at'] = utc_now()
    save_report(out, report)
    return report


def print_final(report: dict, folder: Path) -> None:
    s = report['summary']
    print('\n========== TRACK3FORGE 30-CVE FINAL ==========', flush=True)
    for cve in report['cves']:
        item = report['cases'].get(cve) or {}
        print(f"{cve:<20} {item.get('status','NOT_RUN'):<27} "
              f"{item.get('reason') or '-'}", flush=True)
    for k in ('requested', 'completed_deliveries', 'reused_deliveries',
              'new_deliveries','exported','proofs_from_existing_evidence',
              'blocked_registry', 'pending','attempted_new_runs'):
        print(k.upper() + '=' + str(s.get(k)), flush=True)
    print('REGISTRY_CIRCUIT_OPEN=' + str(report['registry_circuit']['open']).upper(), flush=True)
    print('OFFICIAL_ACCEPTED=UNKNOWN', flush=True)
    print('BATCH_PROOF_EXECUTED=NO', flush=True)
    print('GPU=OLLAMA_AUTO_OR_NO TRAINING=NO', flush=True)
    print('REPORT=' + str(folder/'batch30_report.json'), flush=True)
    print('CSV=' + str(folder/'batch30_summary.csv'), flush=True)
    print('PENDING_CVES=' + str(folder/'pending_cves.txt'), flush=True)
    print('FINISHED=YES', flush=True)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cves', required=True, help='Audited CVE TXT/CSV/JSON list')
    p.add_argument('--source', required=True, help='Vulhub checked-out source directory')
    p.add_argument('--out', required=True, help='Dedicated fresh output directory')
    p.add_argument('--runs-dir', default=str(ROOT/'runs'), help='Existing old pilot runs directory')
    p.add_argument('--reuse-all', action='store_true', help='Reference valid prior delivery receipts')
    p.add_argument('--resume', action='store_true', help='Continue a previous --out directory')
    p.add_argument('--retry-blocked', action='store_true', help='Recheck blocked or failed cases on resume')
    p.add_argument('--execute', action='store_true', help='Enable actual Docker case execution')
    p.add_argument('--ack-lab', action='store_true', help='Explicitly acknowledge controlled Docker lab')
    p.add_argument('--allow-pull', action='store_true', help='Permit bounded Docker Hub image pulls')
    p.add_argument('--max-new', type=int, default=30, help='Maximum new one-CVE pilot executions')
    p.add_argument('--per-cve-seconds', type=int, default=420)
    p.add_argument('--redeploy-seconds', type=int, default=180)
    p.add_argument('--per-image-seconds', type=int, default=150)
    p.add_argument('--total-seconds', type=int, default=14400)
    p.add_argument('--service-memory', default='2g')
    p.add_argument('--min-disk-gb', type=int, default=12)
    p.add_argument('--agent', action='store_true', help='Optional read-only Ollama failure diagnosis; cannot set PASS')
    p.add_argument('--start-ollama', action='store_true', help='Start existing local Ollama when --agent is set')
    p.add_argument('--model', default='qwen2.5:3b', help='Local Ollama model for diagnosis only')
    p.add_argument('--registry-fail-threshold', type=int, default=2)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if not (1 <= args.max_new <= 30 and 20 <= args.per_cve_seconds <= 3600
            and 20 <= args.redeploy_seconds <= 3600
            and 20 <= args.per_image_seconds <= 3600
            and 60 <= args.total_seconds <= 86400
            and 1 <= args.registry_fail_threshold <= 5):
        raise SystemExit('INVALID_BUDGET_OR_COUNT')
    try:
        if args.execute:
            report = execute_batch(args)
        else:
            report = compute_preflight(args)
        out = Path(args.out).expanduser().resolve()
        print_final(report, out)
        if args.execute and report['summary']['completed_deliveries'] < report['summary']['requested']:
            return 2
        return 0
    except (TaskError, ValueError, OSError) as exc:
        print('BATCH_FAILED=' + str(getattr(exc,'code',type(exc).__name__)), file=sys.stderr)
        print('DETAIL=' + str(exc), file=sys.stderr)
        return 3


if __name__ == '__main__':
    raise SystemExit(main())
