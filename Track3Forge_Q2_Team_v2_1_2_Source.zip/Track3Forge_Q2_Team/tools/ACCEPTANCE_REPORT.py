#!/usr/bin/env python3
"""Read-only L1/L2/L3 evidence aggregation for a Track3Forge pilot."""
import json
import sys
from pathlib import Path


def load(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def report(root):
    pilot = load(root / 'pilot_summary.json')
    if not isinstance(pilot, dict):
        raise SystemExit('FAILED=PILOT_SUMMARY_MISSING')
    records = []
    for item in pilot.get('cases', []):
        cve = item.get('cve')
        if not isinstance(cve, str) or '/' in cve or '..' in cve:
            continue
        case = root / cve
        service = load(case / 'service_check.json') or {}
        proof_paths = [
            case / 'proof' / 'known' / 'known_proof.json',
            case / 'proof' / 'apache' / 'apache_proof.json',
            case / 'proof' / 'activemq' / 'activemq_proof.json',
        ]
        proofs = [p for path in proof_paths if (p := load(path))]
        verified = any(p.get('cve') == cve and p.get('status') == 'BEHAVIOR_VERIFIED'
                       and p.get('vulnerability_verified') is True for p in proofs)
        redeploy = load(case / 'redeploy_result.json') or {}
        redeploy_status = redeploy.get('status') or item.get('redeploy', 'UNKNOWN')
        records.append({
            'cve': cve,
            'build': item.get('build', 'UNKNOWN'),
            'redeploy': redeploy_status,
            'service': service.get('status', 'NOT_RUN'),
            'verified': verified,
        })
    return records


def main(argv):
    if len(argv) != 2:
        raise SystemExit('USAGE: python3 tools/ACCEPTANCE_REPORT.py /path/to/pilot')
    root = Path(argv[1]).expanduser().resolve()
    rows = report(root)
    print('========== TRACK3FORGE REAL EVIDENCE ==========')
    print(f'{"CVE":<20} {"EXPORTED":<9} {"REDEPLOY":<9} {"SERVICE":<9} {"PROOF"}')
    counts = [0, 0, 0, 0]
    for r in rows:
        built = r['build'] == 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF'
        redeployed = r['redeploy'] == 'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF'
        ready = r['service'] in ('APPLICATION_RESPONDED_NOT_CVE_PROOF',
                                  'OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF',
                                  'GENERIC_TCP_REACHABLE_NOT_CVE_PROOF')
        flags = [built, redeployed, ready, r['verified']]
        counts = [x+int(y) for x, y in zip(counts, flags)]
        print(f'{r["cve"]:<20} {"PASS" if built else "NO":<9} '
              f'{"PASS" if redeployed else "NO":<9} '
              f'{"PASS" if ready else "NO":<9} '
              f'{"VERIFIED" if r["verified"] else "NOT_VERIFIED"}')
    print(f'TOTAL={len(rows)} EXPORTED={counts[0]} REDEPLOY={counts[1]} '
          f'SERVICE={counts[2]} VERIFIED={counts[3]}')
    print('GPU=NO TRAINING=NO')
    print('OFFICIAL_ACCEPTED=UNKNOWN')


if __name__ == '__main__':
    main(sys.argv)
