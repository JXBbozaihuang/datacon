#!/usr/bin/env python3
"""Select only build failures and unresolved portable-delivery cases.

Never edits the previous run. A new result directory must be used for retries.
This is a deterministic worklist, not a vulnerability-success claim.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

CVE = re.compile(r'CVE-\d{4}-\d{4,}', re.I)

def select(summary):
    records = []
    seen = set()
    for case in summary.get('cases', []):
        cve = str(case.get('cve', '')).upper()
        if not CVE.fullmatch(cve):
            raise ValueError('Invalid CVE in summary: '+cve)
        if cve in seen:
            raise ValueError('Duplicated CVE in summary: '+cve)
        seen.add(cve)
        build, redeploy = case.get('build'), case.get('redeploy')
        if build == 'FAILED':
            reason = case.get('error_code') or 'BUILD_FAILED_UNCLASSIFIED'
        elif build == 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF' and redeploy in (
            'FAILED', 'BLOCKED_EXTERNAL_DATA_NOT_PACKAGED',
        ):
            reason = case.get('redeploy_error_code') or redeploy
        else:
            continue
        records.append({'cve': cve, 'reason': reason,
                        'previous_build': build, 'previous_redeploy': redeploy})
    return records

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pilot_summary',type=Path)
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args(argv)
    d=json.loads(args.pilot_summary.read_text(encoding='utf-8'))
    if not isinstance(d.get('cases'),list):
        raise ValueError('Not a pilot summary (missing cases)')
    selected=select(d)
    args.out.mkdir(parents=True,exist_ok=True)
    if args.out.resolve()==args.pilot_summary.parent.resolve():
        raise ValueError('Retry selection must use a separate directory')
    (args.out/'retry_cves.txt').write_text(''.join(x['cve']+'\n' for x in selected),encoding='utf-8')
    (args.out/'retry_reasons.json').write_text(
        json.dumps({'previous_summary':str(args.pilot_summary.resolve()),'cases':selected},
                   ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
    for item in selected:
        print(item['cve'],item['reason'])
    print('RETRY_SELECTED='+str(len(selected)))
    print('RETRY_CVES='+str(args.out/'retry_cves.txt'))
    print('ORIGINAL_RUN_UNMODIFIED=YES')
    return 0

if __name__=='__main__':
    sys.exit(main())
