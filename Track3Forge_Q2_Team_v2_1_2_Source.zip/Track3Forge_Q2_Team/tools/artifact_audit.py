#!/usr/bin/env python3
"""Read-only offline OCI / Docker archive integrity auditor. No Docker or network calls."""
import argparse
import hashlib
import json
import os
import re
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path, PurePosixPath
import io

MAX_JSON = 16 * 1024 * 1024
MANIFEST_TYPES = {'application/vnd.oci.image.index.v1+json', 'application/vnd.docker.distribution.manifest.list.v2+json', 'application/vnd.oci.image.manifest.v1+json', 'application/vnd.docker.distribution.manifest.v2+json'}
HEX = re.compile(r'^[0-9a-f]{64}$')
ARCHIVE_SUFFIX = ('.tar', '.tar.gz', '.tgz')

class AuditError(Exception):
    pass

def require(condition, message):
    if not condition:
        raise AuditError(message)

def canonical(name):
    while name.startswith('./'):
        name = name[2:]
    name = name.rstrip('/')
    require(name and not name.startswith('/') and '\\' not in name and
            all(x not in ('', '.', '..') for x in name.split('/')), 'unsafe archive path: '+repr(name))
    return name

def audit_archive(path):
    errors = []
    blobs = 0
    mode = 'UNKNOWN'
    try:
        with tarfile.open(path, 'r:*') as tf:
            files = {}
            names = set()
            for m in tf:
                if m.isdir() and m.name in ('.','./'):
                    continue
                n = canonical(m.name)
                require(n not in names, 'duplicate archive member: '+n)
                names.add(n)
                require(m.isfile() or m.isdir(), 'unsupported archive member: '+n)
                if m.isfile():
                    files[n] = m
            if not any(n in files for n in ('index.json','manifest.json','oci-layout')):
                return dict(path=str(path), status='NOT_IMAGE_ARCHIVE', mode=mode, blobs_checked=0, errors=[])
            def read_json(n):
                require(n in files, 'missing JSON: '+n)
                require(files[n].size <= MAX_JSON, 'JSON exceeds audit limit: '+n)
                with tf.extractfile(files[n]) as f:
                    return json.load(f)
            hashes = {}
            def hash_member(n):
                if n not in hashes:
                    require(n in files, 'missing member: '+n)
                    h = hashlib.sha256()
                    with tf.extractfile(files[n]) as f:
                        for chunk in iter(lambda: f.read(1024*1024), b''):
                            h.update(chunk)
                    hashes[n] = h.hexdigest()
                return hashes[n]
            if 'index.json' in files or 'oci-layout' in files:
                mode = 'OCI_SHA256'
                layout = read_json('oci-layout')
                require(isinstance(layout, dict) and layout.get('imageLayoutVersion') == '1.0.0', 'unsupported OCI layout')
                index = read_json('index.json')
                require(isinstance(index, dict) and index.get('schemaVersion') == 2, 'invalid OCI index')
                require(isinstance(index.get('manifests'), list) and index['manifests'], 'empty OCI index')
                visited = set()
                def visit(d, depth=0):
                    require(depth < 64, 'descriptor nesting exceeds limit')
                    require(isinstance(d, dict), 'invalid descriptor')
                    digest = d.get('digest','')
                    require(isinstance(digest,str) and digest.startswith('sha256:') and HEX.fullmatch(digest[7:]), 'unsupported descriptor digest')
                    n = 'blobs/sha256/'+digest[7:]
                    require(n in files, 'missing blob: '+digest)
                    require(type(d.get('size')) is int and d['size'] == files[n].size, 'descriptor size mismatch: '+digest)
                    require(hash_member(n) == digest[7:], 'digest mismatch: '+digest)
                    mt = d.get('mediaType','')
                    require(isinstance(mt,str) and mt, 'missing descriptor mediaType')
                    if (digest,mt) in visited:
                        return
                    visited.add((digest,mt))
                    if mt in ('application/vnd.oci.image.index.v1+json','application/vnd.docker.distribution.manifest.list.v2+json'):
                        obj = read_json(n)
                        require(isinstance(obj,dict) and obj.get('schemaVersion')==2 and isinstance(obj.get('manifests'),list) and obj['manifests'], 'invalid nested index')
                        for child in obj['manifests']:
                            require(isinstance(child,dict) and child.get('mediaType') in MANIFEST_TYPES, 'unsupported nested manifest type')
                            visit(child,depth+1)
                    elif mt in ('application/vnd.oci.image.manifest.v1+json','application/vnd.docker.distribution.manifest.v2+json'):
                        obj = read_json(n)
                        require(isinstance(obj,dict) and obj.get('schemaVersion')==2 and isinstance(obj.get('layers'),list), 'invalid image manifest')
                        visit(obj.get('config'),depth+1)
                        for child in obj['layers']: visit(child,depth+1)
                        if 'subject' in obj: visit(obj['subject'],depth+1)
                    elif mt.endswith('+json') and ('manifest' in mt or 'index' in mt):
                        raise AuditError('unsupported manifest mediaType: '+mt)
                for d in index['manifests']:
                    require(isinstance(d,dict) and d.get('mediaType') in MANIFEST_TYPES, 'unsupported root manifest type')
                    visit(d)
                for n in files:
                    if n.startswith('blobs/sha256/'):
                        digest = n.split('/')[-1]
                        require(HEX.fullmatch(digest) and n == 'blobs/sha256/'+digest, 'invalid blob path: '+n)
                        require(hash_member(n) == digest, 'digest mismatch: '+n)
                        blobs += 1
            if 'manifest.json' in files:
                if mode == 'UNKNOWN': mode = 'DOCKER_LEGACY_STRUCTURE'
                manifest = read_json('manifest.json')
                require(isinstance(manifest,list) and manifest, 'invalid Docker manifest')
                for entry in manifest:
                    require(isinstance(entry,dict) and isinstance(entry.get('Config'),str) and isinstance(entry.get('Layers'),list), 'invalid Docker manifest entry')
                    config = canonical(entry['Config'])
                    require(isinstance(read_json(config),dict), 'invalid image config')
                    for layer in entry['Layers']:
                        require(isinstance(layer,str), 'invalid layer reference')
                        require(canonical(layer) in files, 'missing layer: '+layer)
                    if mode == 'DOCKER_LEGACY_STRUCTURE':
                        base = PurePosixPath(config).name.removesuffix('.json')
                        if HEX.fullmatch(base): require(hash_member(config)==base, 'config digest mismatch')
            return dict(path=str(path), status='PASS' if mode=='OCI_SHA256' else 'STRUCTURE_ONLY', mode=mode, blobs_checked=blobs, errors=[])
    except (AuditError, OSError, ValueError, TypeError, KeyError, tarfile.TarError, EOFError, RecursionError) as e:
        errors.append(str(e))
    return dict(path=str(path), status='FAIL', mode=mode, blobs_checked=blobs, errors=errors)

def fixture(path, variant='ok'):
    files = {}
    def blob(data, media):
        if not isinstance(data,bytes): data=json.dumps(data).encode()
        h=hashlib.sha256(data).hexdigest(); files['blobs/sha256/'+h]=data
        return dict(digest='sha256:'+h,size=len(data),mediaType=media)
    cfg=blob({'architecture':'arm64','os':'linux'},'application/vnd.oci.image.config.v1+json')
    layer=blob(b'synthetic test data','application/vnd.oci.image.layer.v1.tar')
    manifest=blob(dict(schemaVersion=2,config=cfg,layers=[layer]),'application/vnd.oci.image.manifest.v1+json')
    files['index.json']=json.dumps(dict(schemaVersion=2,manifests=[manifest])).encode()
    files['oci-layout']=b'{"imageLayoutVersion":"1.0.0"}'
    key='blobs/sha256/'+layer['digest'][7:]
    if variant=='missing': del files[key]
    if variant=='tampered': files[key]=b'X'*len(files[key])
    if variant=='size': files[key]+=b'X'
    if variant=='traversal': files['../outside']=b'bad'
    if variant=='badindex': files['index.json']=b'{}'
    if variant=='legacy': files={'manifest.json':b'[{"Config":"config.json","Layers":["layer.tar"]}]','config.json':b'{}','layer.tar':b'data'}
    if variant=='ordinary': files={'notes.txt':b'hello'}
    with tarfile.open(path,'w') as tf:
        for n,data in files.items():
            info=tarfile.TarInfo(n); info.size=len(data); tf.addfile(info,io.BytesIO(data))
        if variant=='duplicate':
            info=tarfile.TarInfo('index.json'); info.size=2; tf.addfile(info,io.BytesIO(b'{}'))

def verify_file_manifest(manifest_path):
    """Check explicit file inventory; never claim that the contents prove an event."""
    rows=[]
    try:
        require(manifest_path.stat().st_size <= MAX_JSON, 'file inventory too large')
        inventory=json.loads(manifest_path.read_text(encoding='utf-8'))
        require(isinstance(inventory,list) and inventory, 'file inventory must be a nonempty list')
        root=manifest_path.parent.resolve()
        seen=set()
        for item in inventory:
            require(isinstance(item,dict), 'invalid inventory entry')
            name=item.get('path'); expected=item.get('sha256'); size=item.get('size')
            require(isinstance(name,str) and canonical(name)==name and name not in seen, 'invalid or duplicate inventory path')
            require(isinstance(expected,str) and HEX.fullmatch(expected), 'missing or invalid expected sha256')
            require(type(size) is int and size>=0, 'invalid expected size')
            seen.add(name); f=root/name
            try:
                require(f.resolve().is_relative_to(root) and not any(x.is_symlink() for x in [f,*[p for p in f.parents if p!=root and p.is_relative_to(root)]]), 'symlink or outside inventory root')
                require(f.is_file(), 'file missing')
                require(f.stat().st_size==size,'size mismatch')
                h=hashlib.sha256()
                with f.open('rb') as stream:
                    for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
                require(h.hexdigest()==expected,'digest mismatch')
                rows.append(dict(path=name,status='PASS'))
            except (AuditError,OSError) as e: rows.append(dict(path=name,status='FAIL',error=str(e)))
    except (AuditError,OSError,ValueError,TypeError) as e: rows.append(dict(path=str(manifest_path),status='FAIL',error=str(e)))
    return rows

class Tests(unittest.TestCase):
    def check_variant(self,variant,expected):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'test.tar'; fixture(p,variant)
            self.assertEqual(audit_archive(p)['status'],expected)
    def test_valid(self): self.check_variant('ok','PASS')
    def test_missing(self): self.check_variant('missing','FAIL')
    def test_tampered(self): self.check_variant('tampered','FAIL')
    def test_size(self): self.check_variant('size','FAIL')
    def test_traversal(self): self.check_variant('traversal','FAIL')
    def test_badindex(self): self.check_variant('badindex','FAIL')
    def test_duplicate(self): self.check_variant('duplicate','FAIL')
    def test_legacy(self): self.check_variant('legacy','STRUCTURE_ONLY')
    def test_ordinary(self): self.check_variant('ordinary','NOT_IMAGE_ARCHIVE')
    def test_file_inventory(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); f=p/'evidence.txt'; f.write_bytes(b'abc'); m=p/'inventory.json'
            m.write_text(json.dumps([dict(path=f.name,sha256=hashlib.sha256(b'abc').hexdigest(),size=3)]))
            self.assertEqual(verify_file_manifest(m)[0]['status'],'PASS')
            f.write_bytes(b'xyz'); self.assertEqual(verify_file_manifest(m)[0]['status'],'FAIL')
            f.unlink(); self.assertEqual(verify_file_manifest(m)[0]['status'],'FAIL')
    def test_invalid_tar(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.tar'; p.write_bytes(b'not a tar')
            self.assertEqual(audit_archive(p)['status'],'FAIL')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('paths',type=Path,nargs='*',help='archive files or directories to scan')
    p.add_argument('--self-test',action='store_true')
    p.add_argument('--file-manifest',type=Path,help='optional trusted inventory JSON: [{path, size, sha256}]')
    args=p.parse_args()
    print('GPU=NO TRAINING=NO DOCKER=NO NETWORK=NO',flush=True)
    if args.self_test:
        r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
        print('SELF_TEST='+('PASS' if r.wasSuccessful() else 'FAIL'),flush=True)
        if not r.wasSuccessful(): return 1
    if not args.paths and not args.file_manifest: return 0 if args.self_test else 2
    found=set()
    for pth in args.paths:
        pth=pth.expanduser()
        if pth.is_symlink(): print('SKIP_SYMLINK='+str(pth)); continue
        if pth.is_file(): found.add(pth.resolve())
        elif pth.is_dir():
            for root,dirs,files in os.walk(pth,followlinks=False):
                dirs[:]=[d for d in dirs if not (Path(root)/d).is_symlink()]
                for name in files:
                    f=Path(root)/name
                    if name.lower().endswith(ARCHIVE_SUFFIX) and not f.is_symlink(): found.add(f.resolve())
        else: print('MISSING_INPUT='+str(pth)); return 2
    counts={k:0 for k in ['PASS','FAIL','STRUCTURE_ONLY','NOT_IMAGE_ARCHIVE']}
    print('ARCHIVES_FOUND='+str(len(found)),flush=True)
    for i,path in enumerate(sorted(found),1):
        print(f'CHECKING={i}/{len(found)} {path}',flush=True)
        row=audit_archive(path); counts[row['status']]+=1
        print(json.dumps(row,ensure_ascii=False),flush=True)
    print('========== FINAL ==========',flush=True)
    for k,v in counts.items(): print(k+'='+str(v))
    print('ARCHIVE_INTEGRITY='+('PASS' if counts['PASS']>0 and not counts['FAIL'] and not counts['STRUCTURE_ONLY'] else 'INCOMPLETE_OR_FAIL'))
    inventory_ok=None
    if args.file_manifest:
        rows=verify_file_manifest(args.file_manifest.expanduser())
        for row in rows: print('FILE_INVENTORY '+json.dumps(row,ensure_ascii=False),flush=True)
        inventory_ok=bool(rows) and all(r['status']=='PASS' for r in rows)
    print('FILE_INVENTORY_CHECK='+('NOT_REQUESTED' if inventory_ok is None else 'PASS' if inventory_ok else 'FAIL'))
    print('RUNTIME_REVALIDATED=NO\nHISTORICAL_PROOF_REVALIDATED=NO\nOFFICIAL_ACCEPTANCE=UNKNOWN\nINPUT_FILES_MODIFIED=NO\nFINISHED=YES',flush=True)
    archive_ok=bool(counts['PASS']) and not counts['FAIL'] and not counts['STRUCTURE_ONLY']
    return 0 if (archive_ok if args.paths else True) and inventory_ok is not False else 2

if __name__=='__main__': sys.exit(main())
