#!/usr/bin/env python3
"""Read-only review of a Track3Forge pilot's failed cases and local image cache.
No pulls, no Docker container starts, no changes to the original evidence.
"""
import argparse
import json
import subprocess
from pathlib import Path


def load(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def image_refs(compose):
    if not isinstance(compose, dict):
        return []
    return sorted({service.get('image') for service in (compose.get('services') or {}).values()
                   if isinstance(service, dict) and service.get('image')})


def docker_local(ref):
    try:
        p = subprocess.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', ref],
                           capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 'CHECK_ERROR: '+str(exc)[:100]
    return 'CACHED '+p.stdout.strip()[:30] if p.returncode == 0 else 'NOT_CACHED'


def audit(pilot: Path, inspect_images: bool=False, tail: int=900):
    summary = load(pilot/'pilot_summary.json')
    if not isinstance(summary, dict):
        raise ValueError('PILOT_SUMMARY_NOT_FOUND_OR_INVALID: '+str(pilot))
    for row in summary.get('cases', []):
        if row.get('build')!='FAILED' and row.get('redeploy') not in ('FAILED', 'BLOCKED_EXTERNAL_DATA_NOT_PACKAGED'):
            continue
        cve=row.get('cve','UNKNOWN')
        case=pilot/cve
        receipt=load(case/'result.json') or {}
        attempts=load(case/'compose_up_attempts.json') or []
        print('\n'+'='*65)
        print('CVE=', cve)
        print('BUILD=',row.get('build'),'REDEPLOY=',row.get('redeploy'))
        print('SECONDS=',row.get('seconds'),'ERROR_CODE=',row.get('error_code'))
        print('FAILURE_PHASE=',receipt.get('phase','UNKNOWN_OLD_VERSION'))
        print('ERROR=',str(receipt.get('error') or row.get('error') or 'NONE')[-500:])
        print('CHECKS=',receipt.get('checks',[]))
        print('ATTEMPTS=',len(attempts))
        for a in attempts:
            print('ATTEMPT=',a.get('attempt'),'SECONDS=',a.get('elapsed_seconds'),
                  'CATEGORY=',a.get('classification'),'TIMEOUT=',a.get('timed_out'))
            log=Path(a['log']) if a.get('log') else case/f"compose_up_attempt_{a.get('attempt')}.log"
            if not log.is_file(): log=case/f"compose_up_attempt_{a.get('attempt')}.log"
            if log.is_file():
                print('ATTEMPT_LOG_LAST=',log.read_text(encoding='utf-8',errors='replace')[-tail:])
        for key in ('compose.log','compose_up_attempt_1.log'):
            file=case/key
            if file.is_file() and (key=='compose.log' or not attempts):
                print(key.replace('.','_').upper()+'_LAST=',
                      file.read_text(encoding='utf-8',errors='replace')[-tail:])
        refs=image_refs(load(case/'isolated.compose.json'))
        print('IMAGES=',refs)
        if inspect_images:
            for ref in refs:
                print('LOCAL_IMAGE=',ref, docker_local(ref))
    print('\nGPU=NO TRAINING=NO DOCKER_READONLY='+('YES' if inspect_images else 'NO'))
    print('AUDIT_COMPLETE=YES')

if __name__ == '__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('pilot',type=Path)
    ap.add_argument('--inspect-images',action='store_true',help='docker image inspect only; no pull')
    ap.add_argument('--tail',type=int,default=900)
    args=ap.parse_args()
    audit(args.pilot.resolve(),args.inspect_images,max(0,min(args.tail,5000)))
