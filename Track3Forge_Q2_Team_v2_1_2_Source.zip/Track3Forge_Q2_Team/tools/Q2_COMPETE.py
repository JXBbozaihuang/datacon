#!/usr/bin/env python3
"""One-command Q2 lab pipeline: CVE list -> trusted recipes -> Docker -> gate -> output/main.

The reference environments and service checks are real; a clean redeploy is NOT
proof of the CVE's vulnerable behavior or of acceptance by contest judges.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import queue
import subprocess
import sys
import threading
import time
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from track3forge import catalog
from tools.SUBMISSION_GATE import package_report


def read_list(value: str):
    values=catalog.read_cves(value)
    if not values or len(values)>1000:
        raise ValueError('CVE_COUNT_OUT_OF_RANGE')
    if len(set(values))!=len(values):
        raise ValueError('DUPLICATE_CVE_LIST')
    return values


def key_for(cves: list[str], source: Path) -> str:
    text='\n'.join(cves)+'\n'+str(source.resolve())
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def run_stream(command, logfile: Path, *, timeout: float):
    logfile.parent.mkdir(parents=True,exist_ok=True)
    print('COMMAND='+' '.join(command[:2])+' ...',flush=True)
    q=queue.Queue()
    p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                       text=True,bufsize=1,cwd=ROOT,env={**os.environ,'PYTHONUNBUFFERED':'1'})
    def read_output():
        try:
            for line in p.stdout:
                q.put(line)
        finally:
            q.put(None)
    t=threading.Thread(target=read_output,daemon=True)
    t.start()
    start=time.monotonic(); last_heartbeat=start; stream_closed=False
    try:
        with logfile.open('a',encoding='utf-8') as f:
            while not stream_closed or p.poll() is None:
                try: item=q.get(timeout=1)
                except queue.Empty: item=''
                if item is None:
                    stream_closed=True
                elif item:
                    print(item,end='',flush=True)
                    f.write(item); f.flush()
                now=time.monotonic()
                if now-start>timeout:
                    p.terminate()
                    try:p.wait(timeout=7)
                    except subprocess.TimeoutExpired:p.kill();p.wait()
                    print('PIPELINE_TIMEOUT=YES',flush=True)
                    return 124
                if now-last_heartbeat>30:
                    print('PIPELINE_HEARTBEAT_SECONDS='+str(int(now-start)),flush=True)
                    last_heartbeat=now
    finally:
        if p.poll() is None:
            p.kill();p.wait()
    return p.returncode


def build_args():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list',required=True,help='CVE text, CSV, JSON or a single CVE')
    p.add_argument('--source',default=str(ROOT/'data'/'vulhub'),help='Trusted Vulhub recipe checkout')
    p.add_argument('--fetch',action='store_true',help='Download official Vulhub snapshot if missing')
    p.add_argument('--allow-pull',action='store_true',help='Permit bounded Docker registry image download')
    p.add_argument('--ack-lab',action='store_true',help='Acknowledge isolated authorized lab')
    p.add_argument('--minimum',type=int,default=20)
    p.add_argument('--agent',action='store_true',help='Optional Ollama postmortem advice')
    p.add_argument('--start-ollama',action='store_true')
    p.add_argument('--model',default='qwen2.5:3b')
    p.add_argument('--min-disk-gb',type=int,default=12)
    p.add_argument('--per-image-seconds',type=int,default=180)
    p.add_argument('--per-cve-seconds',type=int,default=420)
    p.add_argument('--redeploy-seconds',type=int,default=180)
    p.add_argument('--total-seconds',type=int,default=10800)
    p.add_argument('--service-memory',default='2g')
    p.add_argument('--registry-fail-threshold',type=int,default=2)
    p.add_argument('--max-new',type=int,default=30)
    p.add_argument('--copy-mode',choices=('hardlink','copy'),default='hardlink')
    p.add_argument('--plan-only',action='store_true')
    return p


def batch_final_exit(batch_code: int, gate: str) -> int:
    """An interrupted/crashed subprocess cannot be a clean delivery-gate pass."""
    if batch_code not in (0, 2):
        return 3
    return 0 if gate == 'PASS' else 2


def main(argv=None):
    args=build_args().parse_args(argv)
    print('GPU=OLLAMA_AUTO_OR_NO TRAINING=NO',flush=True)
    print('DOCKER='+('NO' if args.plan_only else 'YES'),flush=True)
    print('MAX_BUDGET_SECONDS='+str(args.total_seconds),flush=True)
    if not args.plan_only and not args.ack_lab:
        print('ERROR=ACK_LAB_REQUIRED: pass --ack-lab for controlled lab execution',flush=True)
        return 3
    try:
        cves=read_list(args.list)
        if args.minimum<1 or args.minimum>len(cves):
            raise ValueError('MINIMUM_MUST_BE_WITHIN_CVE_COUNT')
        source=Path(args.source).expanduser().resolve()
        if args.fetch and not source.is_dir():
            print('SOURCE_FETCH=START '+str(source),flush=True)
            receipt=catalog.fetch_snapshot(source)
            print('SOURCE_FETCH='+json.dumps(receipt,ensure_ascii=False),flush=True)
        if not source.is_dir():
            raise ValueError('SOURCE_MISSING: '+str(source)+'; rerun with --fetch or --source')
        # BATCH_DEPENDENCY_PREFETCH_V212: fail before any batch starts if a
        # required image-acquisition module was omitted from the ZIP.
        if args.allow_pull and not (ROOT/'tools'/'PREFETCH_MISSING.py').is_file():
            raise ValueError('BATCH_DEPENDENCY_MISSING: tools/PREFETCH_MISSING.py')
        output=ROOT/'output'
        fingerprint=key_for(cves,source)
        run=output/'work'/fingerprint
        report=run/'batch30_report.json'
        resume=report.is_file()
        print('REQUESTED='+str(len(cves))+'\nMINIMUM='+str(args.minimum),flush=True)
        print('SOURCE='+str(source)+'\nRESUME='+str(resume)+'\nWORK_DIR='+str(run),flush=True)
        cmd=[sys.executable,'-u',str(ROOT/'tools'/'BATCH30.py'),
             '--cves',args.list,'--source',str(source),'--out',str(run),
             '--runs-dir',str(ROOT/'runs'), '--reuse-all',
             '--per-image-seconds',str(args.per_image_seconds),
             '--per-cve-seconds',str(args.per_cve_seconds),
             '--redeploy-seconds',str(args.redeploy_seconds),
             '--total-seconds',str(args.total_seconds),
             '--service-memory',args.service_memory,
             '--min-disk-gb',str(args.min_disk_gb),
             '--registry-fail-threshold',str(args.registry_fail_threshold),
             '--max-new',str(args.max_new)]
        if resume:cmd+=['--resume','--retry-blocked']
        if not args.plan_only:cmd+=['--execute','--ack-lab']
        if args.allow_pull:cmd+=['--allow-pull']
        if args.agent:cmd+=['--agent','--model',args.model]
        if args.agent and args.start_ollama:cmd+=['--start-ollama']
        log=output/'logs'/(fingerprint+'.log')
        print('========== BATCH ENVIRONMENT PIPELINE ==========',flush=True)
        code=run_stream(cmd,log,timeout=args.total_seconds+180)
        print('BATCH_EXIT_CODE='+str(code),flush=True)
        print('BATCH_EXECUTION_COMPLETED='+('YES' if code in (0,2) else 'NO'),flush=True)
        if code not in (0,2):
            print('BATCH_ABORTED_EARLY=YES; inspect '+str(log),flush=True)
        if args.plan_only:
            print('PLAN_REPORT='+str(report)+'\nFINISHED=YES',flush=True)
            return 0 if code==0 else code
        if not report.is_file():
            print('BATCH_REPORT_MISSING='+str(report)+'\nFINISHED=YES',flush=True)
            return 3
        print('========== INDEPENDENT SUBMISSION GATE ==========',flush=True)
        summary=package_report(report,ROOT,output,minimum=args.minimum,
                               mode=args.copy_mode,docker_parse=True,runtime_validate=True)
        summary['batch_exit_code']=code
        summary['batch_execution_completed']=code in (0,2)
        (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        final=batch_final_exit(code,summary['gate'])
        print('RUN_LOG='+str(log),flush=True)
        print('FINAL_EXIT_CODE='+str(final),flush=True)
        return final
    except Exception as e:
        print('PIPELINE_ERROR='+type(e).__name__+': '+str(e)[:800],file=sys.stderr,flush=True)
        print('FINISHED=YES',flush=True)
        return 3

if __name__=='__main__':
    raise SystemExit(main())
