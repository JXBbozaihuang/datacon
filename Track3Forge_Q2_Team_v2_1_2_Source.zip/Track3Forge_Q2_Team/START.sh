#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ "${1:-}" == "test" ]]; then
  shift
  echo 'GPU=NO TRAINING=NO TESTS=UNIT_AND_MOCKED_INTEGRATION'
  python3 -m unittest discover -s tests -v "$@"
else
  exec python3 -m track3forge "$@"
fi
