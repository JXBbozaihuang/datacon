#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
echo "========== TRACK3FORGE Q2 FULL PIPELINE =========="
echo "GPU=OLLAMA_AUTO_OR_NO TRAINING=NO"
echo "TARGET=20/30 DELIVERY_GATE"
echo "MAX_RUN_BUDGET_SECONDS=10800"
echo "PHASE=OFFLINE_REGRESSION"
python3 -m unittest discover -s tests -q >/tmp/track3-q2-unit-tests-$$.log 2>&1 || {
  cat /tmp/track3-q2-unit-tests-$$.log
  rm -f /tmp/track3-q2-unit-tests-$$.log
  echo 'UNIT_TESTS=FAIL FINISHED=YES'
  exit 1
}
tail -n 4 /tmp/track3-q2-unit-tests-$$.log
rm -f /tmp/track3-q2-unit-tests-$$.log
echo "UNIT_TESTS=PASS"
echo "PHASE=DOCKER_Q2_BATCH"
if command -v caffeinate >/dev/null 2>&1; then
  caffeinate -i bash RUN_Q2.sh \
    --list examples/cve30_reviewed.txt \
    --fetch --allow-pull --ack-lab \
    --agent --start-ollama --model qwen2.5:3b \
    --minimum 20 --max-new 30 \
    --per-image-seconds 180 --per-cve-seconds 420 \
    --redeploy-seconds 180 --total-seconds 10800 \
    --registry-fail-threshold 3
else
  bash RUN_Q2.sh \
    --list examples/cve30_reviewed.txt \
    --fetch --allow-pull --ack-lab \
    --agent --start-ollama --model qwen2.5:3b \
    --minimum 20 --max-new 30 \
    --per-image-seconds 180 --per-cve-seconds 420 \
    --redeploy-seconds 180 --total-seconds 10800 \
    --registry-fail-threshold 3
fi
