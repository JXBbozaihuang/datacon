#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONDONTWRITEBYTECODE=1
printf 'GPU=NO TRAINING=NO DOCKER=NO NETWORK=NO\n'
LOG="$(mktemp -t track3-team-unit.XXXXXX)"
trap 'rm -f "$LOG"' EXIT
if python3 -m unittest discover -s tests -q >"$LOG" 2>&1; then
  tail -n 6 "$LOG"
  printf 'UNIT_TESTS=PASS FINISHED=YES\n'
else
  tail -n 100 "$LOG"
  printf 'UNIT_TESTS=FAIL FINISHED=YES\n'
  exit 1
fi
