#!/usr/bin/env python3
"""Read a local Q2 summary without Docker access."""
from pathlib import Path
import json
import sys
root=Path(__file__).resolve().parents[1]
p=Path(sys.argv[1]) if len(sys.argv)>1 else root/'output'/'summary.json'
if not p.is_file():
    print('SUMMARY_NOT_FOUND='+str(p))
    print('FINISHED=YES')
    raise SystemExit(1)
try:
    obj=json.loads(p.read_text(encoding='utf-8'))
except (OSError,ValueError) as exc:
    print('SUMMARY_INVALID='+str(exc))
    raise SystemExit(2)
print('========== Q2 LOCAL DELIVERY ==========',flush=True)
for label,field in [('REQUESTED','requested'),('MAIN_READY','ready'),('MINIMUM','minimum'),('DELIVERY_GATE','gate'),('BATCH_EXECUTION_COMPLETED','batch_execution_completed')]:
    print(f'{label}={obj.get(field,"UNKNOWN")}',flush=True)
for row in obj.get('cases',[]):
    print(row.get('cve','UNKNOWN'),row.get('status','UNKNOWN'),row.get('reason','-'),flush=True)
print('CVE_BEHAVIOR_VERIFIED_THIS_PASS=NOT_INFERRED')
print('OFFICIAL_ACCEPTANCE=UNKNOWN')
print('MAIN='+str(root/'output'/'main'))
print('FINISHED=YES')
