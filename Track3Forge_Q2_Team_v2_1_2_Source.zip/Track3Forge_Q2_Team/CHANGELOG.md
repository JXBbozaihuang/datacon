# Changelog

## 2.1.2-team

- Consolidated the integrated v2.1 source tree for Git collaboration.
- Included macOS symlink-alias handling from v2.1.1 and regression tests.
- Included `PREFETCH_MISSING.py`, cached-first scheduling, early-abort exit classification from v2.1.2.
- Added `.gitignore`, team README, collaboration guide, CI workflow and read-only summary helper.
- Excluded user-generated Docker archives, reports, image caches and local backups.
- CI covers unit/mocked tests only; actual CVE behavior and official acceptance remain separate.
