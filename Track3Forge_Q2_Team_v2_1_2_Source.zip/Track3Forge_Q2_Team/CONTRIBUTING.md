# 团队贡献约定

## 分工建议

- **Source/Catalog**：配方来源、版本追溯及可信性（`track3forge/catalog.py`）。
- **Runtime**：Docker / Compose 隔离、服务健康和平台兼容（`track3forge/compose.py`、`pilot.py`、`platform_export.py`）。
- **Scheduler**：`tools/BATCH30.py`、`PREFETCH_MISSING.py`，断点续跑与错误分类。
- **Acceptance**：`tools/SUBMISSION_GATE.py`、`artifact_audit.py`，产物完整性与独立证据门禁。

## PR 检查清单

- [ ] 变更目标及影响说明清楚。
- [ ] 新增或修改相应测试，`bash scripts/check.sh` 通过。
- [ ] 未把环境交付、漏洞行为验证或官方验收混为一谈。
- [ ] 无源码之外的镜像、数据集、运行记录、敏感配置、API token。
- [ ] Docker 运行有清晰预算、隔离和资源释放策略。
- [ ] macOS `/var` 与 `/private/var` 路径别名已考虑。

## 分支及版本

默认 `main` 只合并通过 CI 的 PR。建议用 `feat/xxx`、`fix/xxx`、`test/xxx` 分支，关键比赛日前打 `v2.x.x` tag。多人共同使用共享 Docker Desktop 时先协调，避免并发竞态与镜像缓存误删。

## 数据处理

`output/main` 及运行记录是实验成果，不进入 Git。需要队友复核时只共享无敏感信息的验收报告以及必要的授权制品，优先用内网对象存储或受控文件共享，不强推大文件入仓库。
