"""Fail-closed contract and isolated sidecar tests for Apache proof extension."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from track3forge import apache_proof as a, cli
from track3forge.core import TaskError


class Process:
    def __init__(self, stdout='', stderr='', returncode=0):
        self.stdout, self.stderr, self.returncode = stdout, stderr, returncode


class Runner:
    def __init__(self): self.calls = []
    def run(self, cmd, **kwargs):
        self.calls.append(list(cmd))
        return Process()


class ProofTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.case = Path(tmp.name)
        artifact = self.case/'container-images.tar'
        artifact.write_bytes(b'dummy-tar')
        self.report = {
            'cve':'CVE-2021-41773',
            'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
            'artifact':str(artifact),
            'archive_sha256':hashlib.sha256(b'dummy-tar').hexdigest(),
            'images':['t3-local-apache:latest'],
        }
        self.dump()
        self.runner = Runner()

    def dump(self):
        (self.case/'result.json').write_text(json.dumps(self.report))

    def context(self, mock_trial):
        return [
            patch.object(a,'assert_archive_tag', return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'}),
            patch.object(a,'_image_available'),
            patch.object(a,'_extract_config',return_value={'httpd_conf_sha256':'aa','autoindex_conf_sha256':'bb'}),
            patch.object(a,'_build_fixed',return_value={'config_test':'PASSED'}),
            patch.object(a,'_confirm_control_config',return_value='CRITICAL_CONFIG_BYTES_MATCHED'),
            patch.object(a,'_trial',side_effect=mock_trial),
        ]

    def run_mocks(self,vuln,patched):
        contexts=self.context([vuln,patched])
        mocks=[]
        try:
            for x in contexts: mocks.append(x.__enter__())
            result=a.verify_apache_case(self.case,runner=self.runner)
        finally:
            for x in reversed(contexts):x.__exit__(None,None,None)
        return result,mocks

    def valid(self,ver,ex):
        return {'health_version':ver,'positive_exact':ex,'negative_exact':False,
                'positive_http':[200 if ex else 404], 'negative_http':404}

    def test_positive_differential_only(self):
        d,mocks=self.run_mocks(self.valid('2.4.49',True),self.valid('2.4.51',False))
        self.assertEqual(d['status'],'BEHAVIOR_VERIFIED')
        self.assertTrue(d['vulnerability_verified'])
        self.assertIn('CONTROL_CRITICAL_CONFIG_BYTES_MATCHED',d['checks'])
        self.assertTrue((self.case/'proof/apache/apache_proof.json').is_file())
        self.assertTrue(any(c[:3]==['docker','image','rm'] for c in self.runner.calls))
        self.assertEqual(mocks[-1].call_count,2)
        self.assertTrue(mocks[-1].call_args_list[0].args[2] == '2.4.49')

    def test_fixed_control_still_reads_marker_is_not_verified(self):
        d,_=self.run_mocks(self.valid('2.4.49',True),self.valid('2.4.51',True))
        self.assertEqual(d['status'],'NOT_REPRODUCED')
        self.assertFalse(d['vulnerability_verified'])

    def test_normal_path_false_positive_is_not_verified(self):
        v=self.valid('2.4.49',True);v['negative_exact']=True
        d,_=self.run_mocks(v,self.valid('2.4.51',False))
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_vulnerable_control_no_canary_is_not_verified(self):
        d,_=self.run_mocks(self.valid('2.4.49',False),self.valid('2.4.51',False))
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_wrong_cve_rejected_before_docker(self):
        self.report['cve']='CVE-2023-46604';self.dump()
        d=a.verify_apache_case(self.case,runner=self.runner)
        self.assertEqual(d['error_code'],'WRONG_CVE')
        self.assertFalse(d['vulnerability_verified'])
        self.assertEqual(self.runner.calls,[])

    def test_archive_modified_rejected_before_docker(self):
        (self.case/'container-images.tar').write_bytes(b'tampered')
        d=a.verify_apache_case(self.case,runner=self.runner)
        self.assertEqual(d['error_code'],'ARTIFACT_MISMATCH')
        self.assertFalse(d['vulnerability_verified'])

    def test_missing_fixed_image_fails_closed(self):
        with patch.object(a,'assert_archive_tag',return_value={}),patch.object(
                a,'_image_available',side_effect=[None,TaskError('IMAGE_MISSING','missing')]):
            d=a.verify_apache_case(self.case,runner=self.runner)
        self.assertEqual(d['status'],'PROOF_FAILED')
        self.assertEqual(d['error_code'],'IMAGE_MISSING')

    def test_fixed_control_unavailable_fails_closed(self):
        controls=self.context([self.valid('2.4.49',True),
            {'error_code':'APACHE_NOT_READY','error':'bad configuration'}])
        try:
            for x in controls:x.__enter__()
            d=a.verify_apache_case(self.case,runner=self.runner)
        finally:
            for x in reversed(controls):x.__exit__(None,None,None)
        self.assertEqual(d['status'],'PROOF_FAILED')
        self.assertEqual(d['error_code'],'PATCHED_TRIAL_FAILED')
        self.assertFalse(d['vulnerability_verified'])

    def test_missing_configuration_check_is_rejected(self):
        mocks=self.context([])
        try:
            for x in mocks:x.__enter__()
            with patch.object(a,'_confirm_control_config',side_effect=TaskError('PATCHED_CONFIG_DRIFT','changed')):
                d=a.verify_apache_case(self.case,runner=self.runner)
        finally:
            for x in reversed(mocks):x.__exit__(None,None,None)
        self.assertEqual(d['error_code'],'PATCHED_CONFIG_DRIFT')
        self.assertFalse(d['vulnerability_verified'])

    def test_base_image_requires_explicit_pull_permission(self):
        class Fake(Runner):
            def run(self,cmd,**kw):
                self.calls.append(cmd)
                return Process(returncode=1)
        r=Fake()
        with self.assertRaises(TaskError) as e:
            a._image_available(r,a.FIXED_BASE,1000000000,False)
        self.assertEqual(e.exception.code,'IMAGE_MISSING')
        self.assertEqual(len(r.calls),1)

    def test_parser_requires_lab_ack(self):
        parsed=cli.make_parser().parse_args(['q2','verify-apache-case','--case',str(self.case)])
        self.assertEqual(parsed.budget,360)
        with self.assertRaises(TaskError) as cm:
            parsed.func(parsed)
        self.assertEqual(cm.exception.code,'LAB_ACK_REQUIRED')

    def test_trial_internal_network_no_host_ports(self):
        class VersionRunner(Runner):
            def run(self,cmd,**kw):
                self.calls.append(cmd)
                if cmd[:4]==['docker','exec','t3unused','httpd']:
                    return Process(stdout='Server version: Apache/2.4.49')
                if len(cmd)>2 and cmd[0:2]==['docker','exec'] and cmd[-2:]==['httpd','-v']:
                    return Process(stdout='Server version: Apache/2.4.49 (Unix)')
                return Process()
        runner=VersionRunner()
        with patch.object(a,'_http',side_effect=[{'http':200,'body':'ok'},
            {'http':404,'body':'not found'},{'http':200,'body':'NOT_MARKER'},
            {'http':200,'body':'NOT_MARKER'}]):
            result=a._trial(runner,'testimage','2.4.49','MARKER','abc.txt',1000000000)
        self.assertEqual(result['health_version'],'2.4.49')
        self.assertFalse(result['positive_exact'])
        calls=runner.calls
        net=next(x for x in calls if x[:3]==['docker','network','create'])
        run=next(x for x in calls if x[:3]==['docker','run','-d'])
        self.assertIn('--internal',net)
        self.assertIn('--network',run)
        self.assertNotIn('-p',run)
        self.assertNotIn('--privileged',run)
        self.assertTrue(any(x[:3]==['docker','network','rm'] for x in calls))
        self.assertTrue(any(x[:3]==['docker','rm','-f'] for x in calls))

    def test_extract_config_requires_actual_alias(self):
        class CopyRunner(Runner):
            def run(self, cmd, **kwargs):
                self.calls.append(cmd)
                if cmd[:2] == ['docker','cp']:
                    dest=Path(cmd[-1]);(dest/'extra').mkdir(parents=True)
                    (dest/'httpd.conf').write_text('Include conf/extra/httpd-autoindex.conf\n')
                    (dest/'extra/httpd-autoindex.conf').write_text('Alias /icons/ "/path/icons/"\n')
                return Process()
        with tempfile.TemporaryDirectory() as t:
            r=CopyRunner()
            conf=a._extract_config(r,'vulnerable:tag',Path(t),1000000000)
            self.assertEqual(len(conf['httpd_conf_sha256']),64)
            self.assertEqual(len(conf['autoindex_conf_sha256']),64)
            self.assertTrue(any(cmd[:3]==['docker','rm','-f'] for cmd in r.calls))

    def test_extract_config_rejects_alias_missing(self):
        class CopyRunner(Runner):
            def run(self, cmd, **kwargs):
                self.calls.append(cmd)
                if cmd[:2] == ['docker','cp']:
                    dest=Path(cmd[-1]);(dest/'extra').mkdir(parents=True)
                    (dest/'httpd.conf').write_text('Include conf/extra/httpd-autoindex.conf\n')
                    (dest/'extra/httpd-autoindex.conf').write_text('# Alias not enabled\n')
                return Process()
        with tempfile.TemporaryDirectory() as t:
            r=CopyRunner()
            with self.assertRaises(TaskError) as e:
                a._extract_config(r,'vulnerable:tag',Path(t),1000000000)
            self.assertEqual(e.exception.code,'APACHE_ALIAS_NOT_ENABLED')
            self.assertTrue(any(cmd[:3]==['docker','rm','-f'] for cmd in r.calls))

    def test_control_configuration_must_match_source_digests(self):
        class CopyRunner(Runner):
            def run(self, cmd, **kwargs):
                self.calls.append(cmd)
                if cmd[:2] == ['docker','cp']:
                    Path(cmd[-1]).write_bytes(b'original-httpd-config')
                return Process()
        with tempfile.TemporaryDirectory() as t:
            r=CopyRunner()
            digest=hashlib.sha256(b'original-httpd-config').hexdigest()
            expected={'httpd_conf_sha256':digest,'autoindex_conf_sha256':digest}
            self.assertEqual(a._confirm_control_config(r,'test',Path(t),expected,1000000000),
                             'CRITICAL_CONFIG_BYTES_MATCHED')
            self.assertTrue(any(cmd[:3]==['docker','rm','-f'] for cmd in r.calls))
            with self.assertRaises(TaskError) as e:
                a._confirm_control_config(r,'test',Path(t),dict(expected,httpd_conf_sha256='bad'),1000000000)
            self.assertEqual(e.exception.code,'PATCHED_CONFIG_DRIFT')

    def test_trial_start_failure_still_removes_network(self):
        class FailRunner(Runner):
            def run(self, cmd, **kwargs):
                self.calls.append(cmd)
                if cmd[:3]==['docker','run','-d']:
                    raise TaskError('COMMAND_FAILED','target image unable to run')
                return Process()
        r=FailRunner()
        result=a._trial(r,'image','2.4.49','marker','file.txt',1000000000)
        self.assertEqual(result['error_code'],'COMMAND_FAILED')
        self.assertTrue(any(cmd[:3]==['docker','network','rm'] for cmd in r.calls))
        self.assertFalse(any(cmd[:3]==['docker','rm','-f'] for cmd in r.calls))

    def test_control_dockerfile_has_no_network_package_install(self):
        with tempfile.TemporaryDirectory() as t:
            r=Runner()
            a._build_fixed(r,Path(t),'fixed:tag',1000000000)
            src=(Path(t)/'Dockerfile').read_text()
            self.assertEqual(src,'FROM httpd:2.4.51\nCOPY conf/ /usr/local/apache2/conf/\n')
            cmd=r.calls[0]
            self.assertEqual(cmd[:3],['docker','build','--pull=false'])
            self.assertIn('none',cmd)


if __name__=='__main__': unittest.main()
