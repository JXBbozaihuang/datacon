import copy,json,tempfile,unittest
from pathlib import Path
from track3forge.core import TaskError
from track3forge.compose import sanitize,ready_services,process_cves
class ComposeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)
        self.good={'services':{'web':{'image':'grafana/grafana:8.2.6','ports':[{'target':3000,'published':'3000'}]}}}
    def test_removes_host_ports_and_isolates(self):
        out,flags=sanitize(self.good,self.p)
        self.assertNotIn('ports',out['services']['web'])
        self.assertEqual(out['networks'],{'default':{'internal':True}})
        self.assertIn('HOST_PORTS_REMOVED',flags)
        self.assertIn('ports',self.good['services']['web'])
    def test_reject_privileged(self):
        x=copy.deepcopy(self.good);x['services']['web']['privileged']=True
        with self.assertRaises(TaskError):sanitize(x,self.p)
    def test_reject_host_network(self):
        x=copy.deepcopy(self.good);x['services']['web']['network_mode']='host'
        with self.assertRaises(TaskError):sanitize(x,self.p)
    def test_reject_docker_sock(self):
        x=copy.deepcopy(self.good)
        x['services']['web']['volumes']=[{'type':'bind','source':'/var/run/docker.sock','target':'/var/run/docker.sock'}]
        with self.assertRaises(TaskError):sanitize(x,self.p)
    def test_inside_bind_flag(self):
        a=self.p/'asset';a.write_text('x')
        x=copy.deepcopy(self.good)
        x['services']['web']['volumes']=[{'type':'bind','source':str(a),'target':'/asset','read_only':True}]
        _,flags=sanitize(x,self.p)
        self.assertIn('BIND_MOUNT_REQUIRES_PACKAGING',flags)
    def test_external_volume_rejected(self):
        x=copy.deepcopy(self.good);x['volumes']={'v':{'external':True}}
        with self.assertRaises(TaskError):sanitize(x,self.p)
    def test_named_volume_warn(self):
        x=copy.deepcopy(self.good);x['services']['web']['volumes']=[{'type':'volume','source':'db','target':'/var/lib'}]
        _,flags=sanitize(x,self.p);self.assertIn('NAMED_VOLUME_DATA_NOT_EXPORTED',flags)
    def test_ready_all_services(self):
        a={'web':{'running':True,'health':None},'db':{'running':False,'health':None}}
        self.assertFalse(ready_services(a))
        a['db']={'running':True,'health':'unhealthy'}
        self.assertFalse(ready_services(a))
        a['db']={'running':True,'health':'healthy'}
        self.assertTrue(ready_services(a))
    def test_unknown_recipe_recorded(self):
        summary=process_cves(['CVE-2024-12345'],self.p,self.p/'out')
        self.assertEqual(summary['results'][0]['status'],'NO_RECIPE')
        self.assertEqual(summary['exported_real_docker'],0)
if __name__=='__main__':unittest.main()

class BudgetTests(unittest.TestCase):
    def test_global_budget_skips_without_fabricating(self):
        from track3forge.compose import process_cves
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            r=process_cves(['CVE-2021-43798','CVE-2023-46604'],p,p/'out',total_budget=0)
            self.assertEqual(r['exported_real_docker'],0)
            self.assertTrue(all(x['status']=='GLOBAL_BUDGET_EXHAUSTED_NOT_RUN' for x in r['results']))
