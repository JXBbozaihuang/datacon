import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from track3forge.core import TaskError
from track3forge.pilot import run_pilot
from track3forge.compose import candidate_run, sanitize
from test_docker_integration_mock import FakeDocker


class DockerWithInfo(FakeDocker):
    def run(self, args, **kwargs):
        if args[:2] == ['docker', 'info']:
            from test_docker_integration_mock import Proc
            return Proc('29.9.3')
        return super().run(args, **kwargs)


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.recipe = self.root / 'grafana' / 'CVE-2021-43798' / 'docker-compose.yml'
        self.recipe.parent.mkdir(parents=True)
        self.recipe.write_text('services: {}')

    def kw(self, out='pilot'):
        return dict(runner=DockerWithInfo(self.root), ack_lab=True,
                    per_cve_seconds=30, total_seconds=90,
                    redeploy_seconds=30, min_disk_gb=0,
                    out=self.root/out)

    def test_requires_explicit_ack_before_any_docker(self):
        with self.assertRaises(TaskError) as e:
            run_pilot(['CVE-2021-43798'], self.root, self.root/'x',
                      runner=DockerWithInfo(self.root), min_disk_gb=0)
        self.assertEqual(e.exception.code, 'LAB_ACK_REQUIRED')

    def test_success_separate_from_real_vulnerability_proof(self):
        with patch('track3forge.verify.assert_archive_tag', return_value={'status': 'OK'}):
            result = run_pilot(['CVE-2021-43798'], self.root, **self.kw())
        self.assertEqual(result['exported_real_docker'], 1)
        self.assertEqual(result['redeploy_passed'], 1)
        self.assertEqual(result['verified_vulnerabilities'], 0)
        self.assertFalse(result['cases'][0]['verified_vulnerability'])
        self.assertEqual(result['cases'][0]['redeploy'],
                         'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF')
        self.assertTrue((self.root/'pilot'/'CVE-2021-43798'/'compose.log').exists())
        self.assertTrue((self.root/'pilot'/'pilot_summary.csv').exists())

    def test_cap_three_selected_no_hidden_extra(self):
        with patch('track3forge.verify.assert_archive_tag', return_value={'status': 'OK'}):
            result = run_pilot(['CVE-2021-43798','CVE-2022-99999'],self.root,
                               limit=1, **self.kw())
        self.assertEqual(result['selected'], 1)
        self.assertEqual(len(result['cases']), 1)
        self.assertFalse((self.root/'pilot'/'CVE-2022-99999').exists())

    def test_no_recipe_keeps_normalized_failure_receipt(self):
        result = run_pilot(['CVE-2022-99999'],self.root, **self.kw())
        self.assertEqual(result['cases'][0]['build'],'NO_RECIPE')
        self.assertEqual(result['exported_real_docker'],0)
        self.assertEqual(result['cases'][0]['error_code'],'NO_EXACT_COMPOSE_RECIPE')

    def test_second_run_refuses_to_mix_evidence(self):
        with patch('track3forge.verify.assert_archive_tag', return_value={'status':'OK'}):
            run_pilot(['CVE-2021-43798'],self.root, **self.kw())
        with self.assertRaises(TaskError) as e:
            run_pilot(['CVE-2021-43798'],self.root, **self.kw())
        self.assertEqual(e.exception.code,'OUTPUT_NOT_EMPTY')

    def test_failed_build_writes_compose_logs_and_cleanup(self):
        executor=DockerWithInfo(self.root, unhealthy=True)
        result=run_pilot(['CVE-2021-43798'], self.root,
                         runner=executor, ack_lab=True,min_disk_gb=0,
                         per_cve_seconds=30,total_seconds=90,redeploy_seconds=30,
                         out=self.root/'bad')
        self.assertEqual(result['cases'][0]['build'],'FAILED')
        self.assertEqual(result['cases'][0]['error_code'],'SERVICE_EXITED')
        receipt=json.loads((self.root/'bad'/'CVE-2021-43798'/'result.json').read_text())
        self.assertEqual(receipt['cleanup_status'],'OK')
        self.assertTrue((self.root/'bad'/'CVE-2021-43798'/'compose.log').is_file())
        self.assertTrue(any(' --volumes' in ' '.join(x) for x in executor.calls))

    def test_global_fixed_volume_cannot_escape_project(self):
        cfg={'services':{'web':{'image':'busybox','container_name':'app'}},
             'volumes':{'db':{'name':'production_database'}}}
        clean,flags=sanitize(cfg,self.root)
        self.assertNotIn('name',clean['volumes']['db'])
        self.assertNotIn('container_name',clean['services']['web'])
        self.assertIn('GLOBAL_VOLUME_NAME_PROJECT_SCOPED',flags)
        self.assertIn('FIXED_CONTAINER_NAME_REMOVED',flags)

    def test_original_source_unchanged_by_sanitizer(self):
        cfg={'services':{'web':{'image':'busybox','container_name':'app'}},
             'volumes':{'db':{'name':'production_database'}}}
        clean, flags = sanitize(cfg,self.root)
        self.assertEqual(cfg['volumes']['db']['name'],'production_database')
        self.assertEqual(cfg['services']['web']['container_name'],'app')


if __name__=='__main__':
    unittest.main()

class PilotCLIUnitTests(unittest.TestCase):
    def test_pilot_parser_accepts_local_source_and_optional_fetch(self):
        from track3forge.cli import make_parser
        p=make_parser()
        a=p.parse_args(['q2','pilot','--cves','CVE-2021-43798',
                        '--source','data/vulhub','--ack-lab','--limit','1'])
        self.assertEqual(a.q2_cmd,'pilot')
        self.assertFalse(a.fetch)
        self.assertEqual(a.limit,1)
        b=p.parse_args(['q2','pilot','--cves','CVE-2021-43798','--fetch'])
        self.assertTrue(b.fetch)

    def test_redeploy_exception_does_not_erase_exported_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            recipe=root/'grafana'/'CVE-2021-43798'/'docker-compose.yml'
            recipe.parent.mkdir(parents=True)
            recipe.write_text('services: {}')
            with patch('track3forge.compose.redeploy_check',
                       side_effect=TaskError('REDEPLOY_FAILED','bad standalone redeploy')):
                outcome=run_pilot(['CVE-2021-43798'],root,root/'pilot',
                                  runner=DockerWithInfo(root),ack_lab=True,min_disk_gb=0,
                                  per_cve_seconds=30,total_seconds=90,redeploy_seconds=30)
            self.assertEqual(outcome['exported_real_docker'],1)
            self.assertEqual(outcome['cases'][0]['build'],'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF')
            self.assertEqual(outcome['cases'][0]['redeploy'],'FAILED')
            self.assertEqual(outcome['cases'][0]['redeploy_error_code'],'REDEPLOY_FAILED')
