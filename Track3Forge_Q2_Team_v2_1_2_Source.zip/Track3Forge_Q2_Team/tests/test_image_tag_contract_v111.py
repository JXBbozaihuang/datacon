import hashlib
import io
import json
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from track3forge import compose, verify
from track3forge.core import TaskError
from test_docker_integration_mock import FakeDocker, Proc


def make_tar(path, tag):
    cfg = b'{"architecture":"amd64","os":"linux"}'
    config_name = hashlib.sha256(cfg).hexdigest() + '.json'
    payloads = {
        'manifest.json': json.dumps([{'Config': config_name, 'RepoTags': [tag],
                                      'Layers': ['layer/layer.tar']}]).encode(),
        config_name: cfg,
        'layer/layer.tar': b'layer content',
    }
    with tarfile.open(path, 'w') as out:
        for name, content in payloads.items():
            info = tarfile.TarInfo(name)
            info.size = len(content)
            out.addfile(info, io.BytesIO(content))


class SaveAgainRunner:
    def __init__(self, archive):
        self.archive = Path(archive)
        self.calls = []

    def run(self, argv, **kwargs):
        self.calls.append(argv)
        if argv[:3] == ['docker', 'image', 'inspect']:
            return Proc('[{"Id":"sha256:some-manifest"}]')
        if argv[:3] == ['docker', 'save', '-o']:
            Path(argv[3]).write_bytes(self.archive.read_bytes())
            return Proc()
        raise AssertionError(argv)


class ImageTagContractTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)

    def test_compose_implicit_latest_must_match_archive(self):
        archive = self.root/'old-apache.tar'
        make_tar(archive, 't3old-apache:latest')
        result = verify.assert_archive_tag(archive, 't3old-apache', SaveAgainRunner(archive))
        self.assertEqual(result['status'], 'ARCHIVE_TAG_CONFIG_MATCHED')

    def test_wrong_image_tag_is_still_rejected(self):
        archive = self.root/'old-apache.tar'
        make_tar(archive, 't3old-apache:latest')
        with self.assertRaises(TaskError) as caught:
            verify.assert_archive_tag(archive, 'unrelated-service', SaveAgainRunner(archive))
        self.assertEqual(caught.exception.code, 'IMAGE_NOT_IN_ARTIFACT')

    def test_explicit_different_tag_does_not_alias(self):
        self.assertNotEqual(verify.canonical_image_ref('repo/app:old'),
                            verify.canonical_image_ref('repo/app:latest'))

    def test_build_only_recipe_gets_explicit_exportable_tag(self):
        recipe = self.root/'httpd'/'CVE-2021-41773'/'docker-compose.yml'
        recipe.parent.mkdir(parents=True)
        recipe.write_text('services:\n  apache:\n    build: .\n')
        # Run only planning. It is enough to inspect the compose that would be
        # executed; do not exercise Docker with synthetic image metadata.
        fake = FakeDocker(self.root, services={'apache': {'build': {'context':str(recipe.parent)}}})
        res = compose.candidate_run('CVE-2021-41773', recipe, self.root,
                                    self.root/'out', execute=False, runner=fake)
        self.assertEqual(res['status'], 'RECIPE_FOUND_NOT_RUN')
        model = json.loads((self.root/'out'/'isolated.compose.json').read_text())
        self.assertTrue(model['services']['apache']['image'].startswith('track3forge-local/'))
        self.assertTrue(model['services']['apache']['image'].endswith(':build'))

    def test_existing_source_tag_is_not_rewritten(self):
        recipe = self.root/'app'/'CVE-2021-43798'/'docker-compose.yml'
        recipe.parent.mkdir(parents=True)
        recipe.write_text('services:\n  web:\n    image: vulhub/grafana:8.2.6\n')
        fake = FakeDocker(self.root, services={'web': {'image':'vulhub/grafana:8.2.6'}})
        res = compose.candidate_run('CVE-2021-43798', recipe, self.root,
                                    self.root/'out', execute=False, runner=fake)
        self.assertEqual(res['status'],'RECIPE_FOUND_NOT_RUN')
        model = json.loads((self.root/'out'/'isolated.compose.json').read_text())
        self.assertEqual(model['services']['web']['image'], 'vulhub/grafana:8.2.6')

    def test_pilot_counts_redeploy_failure(self):
        from track3forge.pilot import run_pilot
        from test_pilot import DockerWithInfo
        recipe = self.root/'app'/'CVE-2021-43798'/'docker-compose.yml'
        recipe.parent.mkdir(parents=True)
        recipe.write_text('services: {}')
        with patch('track3forge.compose.redeploy_check',
                   side_effect=TaskError('IMAGE_NOT_IN_ARTIFACT','missing')):
            result = run_pilot(['CVE-2021-43798'],self.root,self.root/'pilot',
                               runner=DockerWithInfo(self.root), ack_lab=True,
                               per_cve_seconds=30,total_seconds=90,
                               redeploy_seconds=30,min_disk_gb=0)
        self.assertEqual(result['exported_real_docker'], 1)
        self.assertEqual(result['redeploy_failed'], 1)
        self.assertEqual(result['build_failed'], 0)
        self.assertEqual(result['failed'], 1)
        self.assertEqual(result['cases'][0]['redeploy_error_code'], 'IMAGE_NOT_IN_ARTIFACT')


if __name__ == '__main__':
    unittest.main()
