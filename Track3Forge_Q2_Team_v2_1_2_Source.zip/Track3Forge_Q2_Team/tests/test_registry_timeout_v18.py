import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'tools'))
from BATCH30 import classify_registry
class RegistryClassificationTest(unittest.TestCase):
    def test_deadline_is_not_registry_outage(self):
        self.assertFalse(classify_registry({'failure':'PULL_DEADLINE_EXCEEDED'}))
        self.assertTrue(classify_registry({'failure':'REGISTRY_AUTH_NETWORK_TRANSIENT'}))
        self.assertTrue(classify_registry({'failure':'REGISTRY_TRANSFER_TRANSIENT'}))
