import tempfile,unittest
from pathlib import Path
from track3forge.cli import make_parser,main
from track3forge.llm import choose_model
from track3forge.core import within
class CliTests(unittest.TestCase):
    def test_explicit_q2_input(self):
        with self.assertRaises(SystemExit):make_parser().parse_args(['q2','run'])
    def test_cve_explicit_parse(self):
        a=make_parser().parse_args(['q2','plan','--cves','CVE-2021-43798'])
        self.assertEqual(a.cves,'CVE-2021-43798')
    def test_choose_existing_qwen(self):
        self.assertEqual(choose_model(['qwen3:4b','qwen2.5:3b']),'qwen2.5:3b')
        self.assertIsNone(choose_model(['llama3:8b']))
    def test_within_macos_path_safe(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'asset').write_text('ok')
            self.assertTrue(within(p/'asset',p))
            self.assertFalse(within(p/'../../etc/passwd',p))
    def test_help_exits_zero(self):
        with self.assertRaises(SystemExit) as e:make_parser().parse_args(['--help'])
        self.assertEqual(e.exception.code,0)
if __name__=='__main__':unittest.main()

class DiscoveryTests(unittest.TestCase):
    def test_discover_no_docker(self):
        from track3forge.cli import cmd_discover
        import argparse,io,contextlib,json
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);x=p/'grafana'/'CVE-2021-43798';x.mkdir(parents=True)
            (x/'docker-compose.yml').write_text('services: {}')
            a=argparse.Namespace(source=str(p),fetch=False,cves='CVE-2021-43798',out=str(p/'out'))
            with contextlib.redirect_stdout(io.StringIO()):cmd_discover(a)
            self.assertEqual(json.loads((p/'out'/'discovery.json').read_text())['recipes_found'],1)
