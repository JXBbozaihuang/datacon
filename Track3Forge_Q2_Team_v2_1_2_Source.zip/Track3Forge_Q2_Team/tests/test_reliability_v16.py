"""General mechanisms: registry transport resilience + static delivery assets."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

from track3forge.compose import (classify_compose_error, compose_up_with_retries,
                                 snapshot_static_binds, bundle_static_binds,
                                 candidate_run)
from track3forge.core import TaskError
from test_docker_integration_mock import FakeDocker

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from RETRY_FROM_PILOT import select

class Proc:
    def __init__(self,rc,err=''):
        self.stdout='';self.stderr=err;self.returncode=rc

class UpSequence:
    def __init__(self,outputs):
        self.outputs=list(outputs);self.calls=[]
    def run(self,args,**kwargs):
        self.calls.append(list(args))
        return self.outputs.pop(0)

class RegistryTests(unittest.TestCase):
    def test_auth_eof_retriable(self):
        code,retry=classify_compose_error(
          'failed to authorize: failed to fetch oauth token: '
          'Post "https://auth.docker.io/token": EOF')
        self.assertEqual(code,'REGISTRY_AUTH_NETWORK_TRANSIENT')
        self.assertTrue(retry)

    def test_429_not_retried(self):
        code,retry=classify_compose_error(
            'toomanyrequests: You have reached your unauthenticated pull rate limit')
        self.assertEqual(code,'REGISTRY_RATE_LIMIT')
        self.assertFalse(retry)

    def test_missing_image_not_retried(self):
        code,retry=classify_compose_error('manifest unknown: manifest unknown')
        self.assertEqual(code,'IMAGE_UNAVAILABLE_OR_PLATFORM_MISMATCH')
        self.assertFalse(retry)

    def test_eof_then_success_writes_durable_attempts(self):
        with tempfile.TemporaryDirectory() as t:
            import time
            r=UpSequence([Proc(1,'failed to fetch oauth token https://auth.docker.io/token: EOF'),
                          Proc(0,'')])
            with patch('track3forge.compose.time.sleep',return_value=None):
                records=compose_up_with_retries(r,['docker','compose','up'],Path(t),time.monotonic()+30)
            self.assertEqual(len(records),2)
            self.assertEqual(records[0]['classification'],'REGISTRY_AUTH_NETWORK_TRANSIENT')
            self.assertEqual(records[-1]['exit_code'],0)
            self.assertEqual(json.loads((Path(t)/'compose_up_attempts.json').read_text())[-1]['exit_code'],0)
            self.assertEqual(len(r.calls),2)

    def test_missing_image_one_attempt_only(self):
        with tempfile.TemporaryDirectory() as t:
            import time
            r=UpSequence([Proc(1,'manifest unknown')])
            with self.assertRaises(TaskError) as e:
                compose_up_with_retries(r,['docker','compose','up'],Path(t),time.monotonic()+30)
            self.assertEqual(e.exception.code,'IMAGE_UNAVAILABLE_OR_PLATFORM_MISMATCH')
            self.assertEqual(len(r.calls),1)

class BindDeliveryTests(unittest.TestCase):
    def test_static_bind_file_portable_relative_source(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            file=root/'entrypoint.sh';file.write_text('#!/bin/sh\nexit 0\n')
            src={'services':{'web':{'volumes':[{'type':'bind','source':str(file),
                                              'target':'/entrypoint.sh'}]}}}
            before=snapshot_static_binds(src,root)
            portable,copied,blocked=bundle_static_binds(src,before,root/'case')
            self.assertFalse(blocked)
            self.assertEqual(len(copied),1)
            rel=portable['services']['web']['volumes'][0]['source']
            self.assertTrue(rel.startswith('./delivery_bind_assets/'))
            self.assertEqual((root/'case'/rel).read_bytes(),file.read_bytes())
            self.assertEqual(src['services']['web']['volumes'][0]['source'],str(file))

    def test_changed_bind_is_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);f=root/'entrypoint.sh';f.write_text('before')
            config={'services':{'web':{'volumes':[{'type':'bind','source':str(f)}]}}}
            snap=snapshot_static_binds(config,root)
            f.write_text('after')
            _,copies,blockers=bundle_static_binds(config,snap,root/'case')
            self.assertEqual(copies,[])
            self.assertEqual(blockers[0]['reason'],'BIND_CHANGED_DURING_EXECUTION')

    def test_named_volume_stays_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            config={'services':{'db':{'volumes':[{'type':'volume','source':'dbdata',
                                                  'target':'/var/lib/mysql'}]}}}
            _,copies,blockers=bundle_static_binds(config,{},Path(t))
            self.assertFalse(copies)
            self.assertEqual(blockers[0]['reason'],'RUNTIME_VOLUME_DATA_NOT_EXPORTED')

    def test_cacti_style_bind_delivery_is_exported(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            recipe=root/'cacti'/'CVE-2022-46169'/'docker-compose.yml'
            recipe.parent.mkdir(parents=True)
            recipe.write_text('services: {}')
            entry=recipe.parent/'entrypoint.sh';entry.write_text('#!/bin/sh\nexec "$@"\n')
            fake=FakeDocker(root,services={'web':{'image':'grafana/grafana:8.2.6',
                'volumes':[{'type':'bind','source':str(entry),'target':'/entrypoint.sh'}]}})
            result=candidate_run('CVE-2022-46169',recipe,root,root/'out',
                runner=fake,execute=True,acknowledge=True,budget=35)
            self.assertEqual(result['status'],'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF')
            self.assertEqual(result['portability'],'REDEPLOY_NOT_TESTED')
            self.assertIn('UNCHANGED_SOURCE_BIND_FILES_BUNDLED',result['checks'])
            self.assertEqual(len(json.loads((root/'out'/'delivery_assets.json').read_text())
                                 ['packaged_static_binds']),1)

class RetrySelectionTests(unittest.TestCase):
    def test_only_failed_or_blocked_cases_retried(self):
        cases=[
            {'cve':'CVE-2021-43798','build':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
             'redeploy':'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF'},
            {'cve':'CVE-2017-12635','build':'FAILED','redeploy':'NOT_RUN',
             'error_code':'COMMAND_FAILED'},
            {'cve':'CVE-2022-46169','build':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
             'redeploy':'BLOCKED_EXTERNAL_DATA_NOT_PACKAGED'},
        ]
        out=select({'cases':cases})
        self.assertEqual([r['cve'] for r in out],['CVE-2017-12635','CVE-2022-46169'])

if __name__=='__main__':unittest.main()
