import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from BATCH30 import init_report

class ResumePathTests(unittest.TestCase):
    def test_path_alias_and_legacy_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve(); source=root/'src'; source.mkdir()
            alias=root/'alias'; alias.symlink_to(source, target_is_directory=True)
            out=root/'out'; cves=['CVE-2021-43798']
            init_report(cves, alias, out)
            p=out/'batch30_report.json'; d=json.loads(p.read_text())
            self.assertEqual(d['source'],str(source))
            d['source']=str(alias); p.write_text(json.dumps(d))
            self.assertEqual(init_report(cves, source, out, resume=True)['cves'],cves)
            self.assertEqual(init_report(cves, alias, out, resume=True)['cves'],cves)
            self.assertEqual(json.loads(p.read_text())['source'],str(alias))
            with self.assertRaisesRegex(ValueError,'RESUME_INPUT_MISMATCH'):
                init_report(['CVE-2021-41773'],source,out,resume=True)
            other=root/'other'; other.mkdir()
            with self.assertRaisesRegex(ValueError,'RESUME_INPUT_MISMATCH'):
                init_report(cves,other,out,resume=True)
