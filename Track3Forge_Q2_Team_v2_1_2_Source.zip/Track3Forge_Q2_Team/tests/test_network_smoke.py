import argparse,unittest
from unittest.mock import patch
from track3forge import cli
from track3forge.core import TaskError
class Proc:
    def __init__(self,rc=0,text='',stderr=''):self.returncode=rc;self.stdout=text;self.stderr=stderr
class FakeRuntime:
    calls=[]
    fail=False
    def run(self,args,**kw):
        self.calls.append(args)
        if args[:3]==['docker','run','--rm']:
            return Proc(1 if self.fail else 0, 'failure' if self.fail else '<html>ok</html>__T3:200')
        return Proc(0,'')
class NetworkSmokeTests(unittest.TestCase):
    def test_real_command_path_no_host_port(self):
        fake=FakeRuntime();fake.calls=[]
        with patch.object(cli,'Executor',return_value=fake):
            self.assertEqual(cli.cmd_network_smoke(argparse.Namespace(allow_pull=False)),0)
        flat=[' '.join(x) for x in fake.calls]
        self.assertTrue(any('network create --internal' in x for x in flat))
        self.assertTrue(any('network rm' in x for x in flat))
        self.assertTrue(any('docker rm -f' in x for x in flat))
        self.assertFalse(any(' -p ' in ' '+x+' ' for x in flat))
        self.assertFalse(any('docker port' in x for x in flat))
    def test_failed_probe_cleans_up_and_refuses_pass(self):
        fake=FakeRuntime();fake.calls=[];fake.fail=True
        with patch.object(cli,'Executor',return_value=fake),patch.object(cli.time,'sleep',return_value=None):
            with self.assertRaises(TaskError):cli.cmd_network_smoke(argparse.Namespace(allow_pull=False))
        flat=[' '.join(x) for x in fake.calls]
        self.assertTrue(any('docker rm -f' in x for x in flat))
        self.assertTrue(any('network rm' in x for x in flat))
