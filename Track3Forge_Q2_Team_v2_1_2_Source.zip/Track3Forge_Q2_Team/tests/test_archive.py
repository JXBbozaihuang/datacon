import hashlib, io, json, tarfile, tempfile, unittest
from pathlib import Path
from track3forge.archive import inventory,recover
from track3forge.core import TaskError

def make_tar(path,*,has_layer=True,has_config=True,config=b'{"architecture":"amd64"}',tags=['test:old'],bad_member=None):
    config_name=hashlib.sha256(config).hexdigest()+'.json'
    layer='1111111111111111/layer.tar'
    manifest=[{'Config':config_name,'RepoTags':tags,'Layers':[layer]}]
    entries={'manifest.json':json.dumps(manifest).encode()}
    if has_config:entries[config_name]=config
    if has_layer:entries[layer]=b'fake layer bytes'
    if bad_member:entries[bad_member]=b'evil'
    with tarfile.open(path,'w') as tar:
        for n,v in entries.items():
            item=tarfile.TarInfo(n);item.size=len(v);tar.addfile(item,io.BytesIO(v))
    return config_name,layer

class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)
        self.target=self.p/'damaged.tar';self.donor=self.p/'donor.tar';self.output=self.p/'repaired.tar'
    def test_inventory_ok(self):
        make_tar(self.target)
        self.assertEqual(inventory(self.target)['status'],'STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF')
    def test_inventory_missing_layer(self):
        _,layer=make_tar(self.target,has_layer=False)
        v=inventory(self.target)
        self.assertEqual(v['status'],'INCOMPLETE');self.assertEqual(v['missing'],[layer])
    def test_recover_from_same_image(self):
        make_tar(self.target,has_layer=False);make_tar(self.donor)
        v=recover(self.target,self.donor,self.output)
        self.assertEqual(v['status'],'IMAGE_ARCHIVE_RECOVERED_NOT_RUNTIME_PROOF')
        self.assertEqual(inventory(self.output)['status'],'STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF')
        self.assertEqual(inventory(self.target)['status'],'INCOMPLETE')
    def test_recover_config_missing(self):
        make_tar(self.target,has_config=False);make_tar(self.donor)
        self.assertEqual(len(recover(self.target,self.donor,self.output)['recovered_members']),1)
    def test_reject_wrong_donor(self):
        make_tar(self.target,has_layer=False);make_tar(self.donor,config=b'{"different":1}')
        with self.assertRaises(TaskError) as e: recover(self.target,self.donor,self.output)
        self.assertEqual(e.exception.code,'DONOR_IDENTITY_MISMATCH')
        self.assertFalse(self.output.exists())
    def test_reject_same_destination(self):
        make_tar(self.target,has_layer=False);make_tar(self.donor)
        with self.assertRaises(TaskError):recover(self.target,self.donor,self.target)
    def test_corrupt_config_digest(self):
        correct=hashlib.sha256(b'original').hexdigest()+'.json'
        manifest=[{'Config':correct,'Layers':['x/layer.tar'],'RepoTags':['foo:1']}]
        with tarfile.open(self.target,'w') as tar:
            for name,data in [('manifest.json',json.dumps(manifest).encode()),(correct,b'altered'),('x/layer.tar',b'layer')]:
                info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
        self.assertEqual(inventory(self.target)['status'],'CORRUPT_CONFIG')
    def test_reject_traversal(self):
        make_tar(self.target,bad_member='../outside')
        with self.assertRaises(TaskError) as e:inventory(self.target)
        self.assertEqual(e.exception.code,'UNSAFE_ARCHIVE_PATH')
    def test_bad_tar(self):
        self.target.write_bytes(b'nothing')
        with self.assertRaises(TaskError) as e:inventory(self.target)
        self.assertEqual(e.exception.code,'INVALID_TAR')
    def test_no_recover_needed(self):
        make_tar(self.target);make_tar(self.donor)
        with self.assertRaises(TaskError):recover(self.target,self.donor,self.output)

if __name__=='__main__':unittest.main()

class DockerArchiveCompatibilityTests(unittest.TestCase):
    def test_leading_dot_and_directory_entries(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'archive.tar'
            conf=b'{}';name=hashlib.sha256(conf).hexdigest()+'.json'
            manifest=[{'Config':name,'Layers':['dir/layer.tar'],'RepoTags':['a:1']}]
            with tarfile.open(path,'w') as t:
                folder=tarfile.TarInfo('dir/');folder.type=tarfile.DIRTYPE;t.addfile(folder)
                for n,blob in [('./manifest.json',json.dumps(manifest).encode()),(name,conf),('dir/layer.tar',b'layer')]:
                    info=tarfile.TarInfo(n);info.size=len(blob);t.addfile(info,io.BytesIO(blob))
            self.assertEqual(inventory(path)['status'],'STRUCTURE_COMPLETE_NOT_RUNTIME_PROOF')
