"""Fail-closed validation of local, no-command OpenWire callback differential."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
import time
from unittest.mock import patch

from track3forge import activemq_proof as a, cli
from track3forge.core import TaskError


class Process:
    def __init__(self, stdout='', stderr='', returncode=0):
        self.stdout, self.stderr, self.returncode = stdout, stderr, returncode


class DummyRunner:
    def __init__(self):self.calls=[]
    def run(self,argv,**kwargs):
        self.calls.append(list(argv))
        return Process()


def valid(version, hit):
    return {'status':'TRIAL_COMPLETE','component_version':{'openwire_component_version':version},
            'baseline_no_callback':True,'trigger_sent':True,'callback_from_broker':hit,
            'cleanup_ok':True,'host_ports_published':False,'network_isolation':'internal_only_sidecar'}


class ProofContract(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        self.case=Path(t.name)
        self.artifact=self.case/'images.tar'
        self.artifact.write_bytes(b'archive-placeholder')
        self.record={'cve':a.CVE,'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
                     'artifact':str(self.artifact),
                     'archive_sha256':hashlib.sha256(b'archive-placeholder').hexdigest(),
                     'images':['vulhub/activemq:5.17.3']}
        self.save()

    def save(self):
        (self.case/'result.json').write_text(json.dumps(self.record))

    def verify(self, vuln=None, fixed=None):
        vuln=vuln or valid('5.17.3',True)
        fixed=fixed or valid('5.17.6',False)
        with patch.object(a,'assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'}),\
             patch.object(a,'_present'),\
             patch.object(a,'_trial',side_effect=[vuln,fixed]) as trials:
            result=a.verify_activemq_case(self.case,runner=DummyRunner())
        return result,trials

    def test_real_callback_and_patched_control_can_verify(self):
        d,trials=self.verify()
        self.assertEqual(d['status'],'BEHAVIOR_VERIFIED')
        self.assertTrue(d['vulnerability_verified'])
        self.assertFalse(d['command_execution_demonstrated'])
        self.assertEqual(trials.call_count,2)
        self.assertTrue((self.case/'proof'/'activemq'/'activemq_proof.json').exists())

    def test_patched_callback_is_fail_closed(self):
        d,_=self.verify(fixed=valid('5.17.6',True))
        self.assertEqual(d['status'],'NOT_REPRODUCED')
        self.assertFalse(d['vulnerability_verified'])

    def test_no_vulnerable_callback_is_not_verified(self):
        d,_=self.verify(vuln=valid('5.17.3',False))
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_wrong_patched_jar_version_does_not_verify(self):
        f=valid('5.17.3',False)
        d,_=self.verify(fixed=f)
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_unisolated_probe_does_not_verify(self):
        v=valid('5.17.3',True);v['network_isolation']='host'
        d,_=self.verify(vuln=v)
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_published_ports_does_not_verify(self):
        f=valid('5.17.6',False);f['host_ports_published']=True
        d,_=self.verify(fixed=f)
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_preexisting_callback_blocks_success(self):
        v=valid('5.17.3',True);v['baseline_no_callback']=False
        d,_=self.verify(vuln=v)
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_missing_openwire_packet_blocks_success(self):
        v=valid('5.17.3',True);v['trigger_sent']=False
        d,_=self.verify(vuln=v)
        self.assertEqual(d['status'],'NOT_REPRODUCED')

    def test_cleanup_failure_blocks_success(self):
        v=valid('5.17.3',True);v['cleanup_ok']=False
        d,_=self.verify(vuln=v)
        self.assertEqual(d['status'],'PROOF_FAILED')
        self.assertEqual(d['error_code'],'VULNERABLE_TRIAL_FAILED')

    def test_patched_trial_error_blocks_success(self):
        f=valid('5.17.6',False);f['error_code']='OPENWIRE_NOT_READY';f['error']='Port refused'
        d,_=self.verify(fixed=f)
        self.assertEqual(d['status'],'PROOF_FAILED')
        self.assertEqual(d['error_code'],'PATCHED_TRIAL_FAILED')

    def test_wrong_cve_rejected_before_docker(self):
        self.record['cve']='CVE-2021-43798';self.save()
        d,_=self.verify()
        self.assertEqual(d['error_code'],'CASE_NOT_EXPORTED')

    def test_wrong_image_not_accepted(self):
        self.record['images']=['attacker-control:latest'];self.save()
        d,_=self.verify()
        self.assertEqual(d['error_code'],'UNEXPECTED_VULNERABLE_IMAGE')

    def test_corrupt_archive_blocks_success(self):
        self.artifact.write_bytes(b'mutated')
        d,_=self.verify()
        self.assertEqual(d['error_code'],'ARTIFACT_MISMATCH')

    def test_no_implicit_download(self):
        runner=DummyRunner()
        runner.run=lambda argv,**kwargs: Process(returncode=1)
        with self.assertRaises(TaskError) as cm:
            a._present(runner,'apache/activemq-classic:5.17.6',time.monotonic()+100000,False)
        self.assertEqual(cm.exception.code,'CONTROL_IMAGE_MISSING')

    def test_version_check_requires_jar_version(self):
        runner=DummyRunner()
        runner.run=lambda argv,**kwargs: Process(stdout='/opt/a/activemq-client-5.17.3.jar\n')
        with self.assertRaises(TaskError):
            a._component_version(runner,'victim','5.17.6',time.monotonic()+100000)
        self.assertEqual(a._component_version(runner,'victim','5.17.3',time.monotonic()+100000)['openwire_component_version'],'5.17.3')

    def test_callback_must_be_exact_and_from_target_ip(self):
        nonce='t3'+'f'*24
        logs='T3_XML_CALLBACK='+nonce+' FROM=172.18.0.11\n'
        self.assertTrue(a._callback_from_target(logs,nonce,'172.18.0.11'))
        self.assertFalse(a._callback_from_target(logs,nonce,'172.18.0.12'))
        self.assertFalse(a._callback_from_target(logs,nonce+'f','172.18.0.11'))

    def test_no_host_ports_and_no_processbuilder_in_payload(self):
        self.assertNotIn('ProcessBuilder',a.SINK_CODE)
        self.assertNotIn('subprocess',a.SINK_CODE)
        self.assertNotIn('os.system',a.PROBE_CODE)
        self.assertIn('http://sink:8000/',a.PROBE_CODE)
        self.assertIn("--internal",__import__('inspect').getsource(a._trial))
        self.assertNotIn("'--publish'",__import__('inspect').getsource(a._trial))

    def test_cli_registered_with_ack_lab(self):
        parser=cli.make_parser()
        args=parser.parse_args(['q2','verify-activemq-case','--case','/tmp/case','--ack-lab'])
        self.assertTrue(args.ack_lab)
        self.assertEqual(args.budget,480)
        self.assertIs(args.func,cli.cmd_verify_activemq_case)


class DockerMockProtocol(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        self.token='t3'+'a'*24
        self.ip='172.21.0.6'

    def execute(self,argv,**kwargs):
        argv=list(argv)
        self.calls.append(argv)
        if argv[:3]==['docker','network','inspect']:
            return Process(stdout=json.dumps([{'Internal':True}]))
        if argv[:2]==['docker','inspect']:
            net=next(c[4] for c in self.calls if c[:3]==['docker','network','create'])
            return Process(stdout=json.dumps([{'NetworkSettings':{'Networks':{net:{'IPAddress':self.ip}}},
                                                'HostConfig':{'PortBindings':{}}}]))
        if argv[:3]==['docker','exec',next((c[4] for c in self.calls if c[:4]==['docker','run','-d','--name'] and 'target' in c[4]),'x')]:
            return Process(stdout='/opt/activemq/lib/activemq-client-5.17.3.jar\n')
        if argv[:2]==['docker','exec']:
            return Process(stdout='/opt/activemq/lib/activemq-client-5.17.3.jar\n')
        if argv[:2]==['docker','logs']:
            triggered=any(c[-2:]==['trigger',self.token] for c in self.calls)
            return Process(stdout=('T3_XML_CALLBACK='+self.token+' FROM='+self.ip+'\n') if triggered else '')
        return Process()

    def test_full_command_path_with_no_host_port(self):
        with patch.object(a.secrets,'token_hex',return_value='a'*24),\
             patch.object(a.time,'sleep',return_value=None):
            d=a._trial(type('ExecutorShim',(),{'run':self.execute})(),'vulhub/activemq:5.17.3','5.17.3',time.monotonic()+100000)
        self.assertEqual(d['status'],'TRIAL_COMPLETE')
        self.assertTrue(d['callback_from_broker'])
        self.assertTrue(d['cleanup_ok'])
        self.assertTrue(d['baseline_no_callback'])
        self.assertEqual(len(d['cleanup']),3)
        self.assertFalse(any('-p' in c or '--publish' in c for c in self.calls))
        self.assertTrue(any(c[:3]==['docker','network','create'] and '--internal' in c for c in self.calls))
        self.assertTrue(any(c[:3]==['docker','network','rm'] for c in self.calls))

if __name__=='__main__':unittest.main()
