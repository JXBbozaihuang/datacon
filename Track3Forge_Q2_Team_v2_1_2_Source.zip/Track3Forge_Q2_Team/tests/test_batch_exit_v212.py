"""A partial batch report may be packaged but never misreported as complete."""
import unittest
from tools.Q2_COMPETE import batch_final_exit

class BatchExitV212Tests(unittest.TestCase):
    def test_normal_full_target(self):
        self.assertEqual(batch_final_exit(0,'PASS'),0)

    def test_expected_partial_but_minimum_reached(self):
        self.assertEqual(batch_final_exit(2,'PASS'),0)

    def test_expected_partial_below_target(self):
        self.assertEqual(batch_final_exit(2,'BELOW_TARGET'),2)

    def test_crashed_batch_cannot_claim_success(self):
        self.assertEqual(batch_final_exit(3,'PASS'),3)

    def test_timeout_cannot_claim_success(self):
        self.assertEqual(batch_final_exit(124,'PASS'),3)

if __name__=='__main__': unittest.main()
