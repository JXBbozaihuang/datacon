import json, tempfile, unittest, zipfile
from pathlib import Path
from track3forge.catalog import read_cves,find_recipes,safe_zip_extract,validate_cve
from track3forge.core import TaskError
class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)
    def test_exact_cve(self):
        x=self.p/'app'/'CVE-2023-46604';x.mkdir(parents=True)
        y=self.p/'app'/'CVE-2023-466040';y.mkdir(parents=True)
        (x/'docker-compose.yml').write_text('services: {}');(y/'docker-compose.yml').write_text('services: {}')
        self.assertEqual(find_recipes(self.p,'CVE-2023-46604'),[x/'docker-compose.yml'])
    def test_compose_yaml(self):
        x=self.p/'CVE-2021-43798';x.mkdir();(x/'compose.yaml').write_text('services: {}')
        self.assertEqual(len(find_recipes(self.p,'CVE-2021-43798')),1)
    def test_reject_invalid_cve(self):
        for bad in ['CVE-3-1234','CVE-2025-12','../CVE-2025-1234','abc']:
            with self.assertRaises(TaskError):validate_cve(bad)
    def test_txt_csv_json(self):
        t=self.p/'l.txt';t.write_text('CVE-2021-43798\n# hi\nCVE-2021-43798\nCVE-2023-46604\n')
        self.assertEqual(len(read_cves(t)),2)
        c=self.p/'l.csv';c.write_text('cve,product\nCVE-2023-46604,activemq\n')
        self.assertEqual(read_cves(c),['CVE-2023-46604'])
        j=self.p/'l.json';j.write_text(json.dumps({'cves':['CVE-2021-43798']}))
        self.assertEqual(read_cves(j),['CVE-2021-43798'])
    def test_zip_slip_rejected(self):
        z=self.p/'evil.zip'
        with zipfile.ZipFile(z,'w') as f:f.writestr('../bad','content')
        with self.assertRaises(TaskError) as e:safe_zip_extract(z,self.p/'out')
        self.assertEqual(e.exception.code,'ZIP_SLIP')
    def test_empty_cves(self):
        t=self.p/'empty.txt';t.write_text('\n')
        with self.assertRaises(TaskError):read_cves(t)
if __name__=='__main__':unittest.main()

class SamplingTests(unittest.TestCase):
    def test_balanced_sample(self):
        from track3forge.catalog import sample_recipes
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for family,cve in [('a','CVE-2021-10001'),('b','CVE-2022-10002'),('a','CVE-2023-10003')]:
                x=p/family/cve;x.mkdir(parents=True);(x/'compose.yaml').write_text('services: {}')
            got=sample_recipes(p,count=2,seed=1)
            self.assertEqual(len(got),2)
            self.assertEqual(len(set(got)),2)
            self.assertEqual(got,sample_recipes(p,count=2,seed=1))
