import io, json, os, tarfile, tempfile, time, unittest
from pathlib import Path
from unittest.mock import patch
from track3forge.core import TaskError
from track3forge.platform_export import (platform_of, runtime_platform, resolve_export_platform,
    archive_platforms, save_candidate, save_identity_check)
from track3forge.compose import _docker_state

class Proc:
    def __init__(self, stdout=''): self.stdout=stdout; self.stderr=''; self.returncode=0

class FakeRunner:
    def __init__(self, *, failure='missing', actual='amd64'):
        self.failure=failure;self.actual=actual;self.commands=[]
    def run(self, args, **kwargs):
        self.commands.append(args)
        if args[:3]==['docker','image','inspect']:
            return Proc(json.dumps([{'Id':'sha256:example'}]))
        if args[:2]==['docker','save']:
            if '--platform' not in args and self.failure:
                raise TaskError('COMMAND_FAILED','content digest sha256:abc not found' if self.failure=='missing' else 'permission denied')
            out=Path(args[args.index('-o')+1]);refs=args[args.index('-o')+2:]
            with tarfile.open(out,'w') as tar:
                entries=[{'Config':'config.json','Layers':[],'RepoTags':refs}]
                for name,b in [('manifest.json',json.dumps(entries).encode()),('config.json',json.dumps({'os':'linux','architecture':self.actual}).encode())]:
                    i=tarfile.TarInfo(name);i.size=len(b);tar.addfile(i,io.BytesIO(b))
            return Proc()
        raise AssertionError(args)

class PlatformExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.file=Path(self.tmp.name)/'images.tar'
        self.refs=['test/app:1','test/db:2']
        self.states={str(i):{'image_ref':r,'runtime_platform':'linux/amd64'} for i,r in enumerate(self.refs)}
        self.metadata={r:{} for r in self.refs}
        self.env=patch.dict(os.environ,{'TRACK3_EXPORT_PLATFORM':''});self.env.start();self.addCleanup(self.env.stop)
    def save(self,runner):
        return save_candidate(runner,self.file,self.refs,self.states,self.metadata,time.monotonic()+30,30)
    def test_descriptor_uses_runtime_not_host(self):
        s=_docker_state({'State':{},'Config':{'Image':'x'},'ImageManifestDescriptor':{'platform':{'os':'linux','architecture':'amd64'}}})
        self.assertEqual(s['runtime_platform'],'linux/amd64')
        self.assertEqual(platform_of({'Os':'','Architecture':''}),None)
    def test_fallback_and_archive_platforms(self):
        runner=FakeRunner();r=self.save(runner)
        self.assertEqual(r['platform'],'linux/amd64')
        self.assertEqual(r['mode'],'EXPLICIT_PLATFORM_FALLBACK')
        self.assertEqual(archive_platforms(self.file,self.refs),{r:{'linux/amd64'} for r in self.refs})
        self.assertTrue(all('--platform' in c for c in runner.commands if c[:3]==['docker','image','inspect']))
    def test_no_fallback_on_unrelated_error(self):
        runner=FakeRunner(failure='other')
        with self.assertRaisesRegex(TaskError,'permission denied'): self.save(runner)
        self.assertEqual(len(runner.commands),1)
    def test_unknown_does_not_infer_peer(self):
        self.states['0']['runtime_platform']=None
        with self.assertRaises(TaskError) as ctx: self.save(FakeRunner())
        self.assertEqual(ctx.exception.code,'EXPORT_PLATFORM_UNRESOLVED')
    def test_tag_hint_requires_matching_runtime_id(self):
        self.states['0'].update(runtime_platform=None,image_id='sha256:runtime')
        self.metadata[self.refs[0]]={'Id':'sha256:other','Os':'linux','Architecture':'amd64'}
        with self.assertRaises(TaskError) as ctx:self.save(FakeRunner())
        self.assertEqual(ctx.exception.code,'EXPORT_PLATFORM_UNRESOLVED')
        self.metadata[self.refs[0]]['Id']='sha256:runtime'
        self.assertEqual(self.save(FakeRunner())['platform'],'linux/amd64')
    def test_explicit_operator_fallback(self):
        self.states['0']['runtime_platform']=None
        with patch.dict(os.environ,{'TRACK3_EXPORT_PLATFORM':'linux/amd64'}):
            self.assertEqual(self.save(FakeRunner())['platform'],'linux/amd64')
    def test_conflict_and_mixed_rejected(self):
        self.states['0']['runtime_platform']='linux/arm64'
        with self.assertRaises(TaskError) as ctx:self.save(FakeRunner())
        self.assertEqual(ctx.exception.code,'EXPORT_MIXED_PLATFORM_UNSUPPORTED')
    def test_wrong_archive_platform_rejected(self):
        with self.assertRaises(TaskError) as ctx:self.save(FakeRunner(actual='arm64'))
        self.assertEqual(ctx.exception.code,'EXPORT_ARCHIVE_PLATFORM_MISMATCH')
        self.assertFalse(self.file.exists())
    def test_normal_export_unchanged(self):
        r=FakeRunner(failure=None)
        self.assertEqual(self.save(r)['mode'],'DEFAULT')
        self.assertEqual(len(r.commands),1)
    def test_identity_reexport_reuses_archive_platform(self):
        self.save(FakeRunner())
        new=self.file.with_name('new.tar');r=FakeRunner()
        save_identity_check(r,self.file,self.refs[0],new)
        self.assertEqual(archive_platforms(new,[self.refs[0]])[self.refs[0]],{'linux/amd64'})
        self.assertIn('--platform',r.commands[-1])
