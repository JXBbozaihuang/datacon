import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tools.artifact_audit import fixture
from tools.SUBMISSION_GATE import (inspect_candidate, package_report, promote_one,
                                   sha, check_compose, validate_packaged_runtime)
from tools.Q2_COMPETE import key_for, read_list

CVE='CVE-2021-43798'

class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.case=self.root/'runs'/'pilot-smoke'/CVE
        self.case.mkdir(parents=True)
        self.tar=self.case/(CVE+'-docker-images.tar')
        fixture(self.tar)
        self.digest=sha(self.tar)
        self.build={'cve':CVE,'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
                    'artifact':str(self.tar),'archive_sha256':self.digest}
        self.redo={'status':'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF',
                   'fresh_project':True,'image_archive_sha256':self.digest}
        self.compose={'services':{'web':{'image':'sample:old'}},'networks':{'default':{'internal':True}}}
        self.rec={'status':'NEW_REDEPLOY_PASS','artifact':str(self.tar),
                  'artifact_sha256_recorded':self.digest}
        self.refresh()
    def refresh(self):
        for name,obj in [('result.json',self.build),('redeploy_result.json',self.redo),
                         ('portable.compose.json',self.compose)]:
            (self.case/name).write_text(json.dumps(obj))
    def inspect(self):
        return inspect_candidate(CVE,self.rec,self.root)
    def test_runtime_validated_mock(self):
        cfg=self.case/'portable.compose.json'
        from subprocess import CompletedProcess
        fake=CompletedProcess(['docker'],0,stdout='{}',stderr='')
        state={'web':{'status':'running'}}
        with patch('subprocess.run',return_value=fake), \
             patch('track3forge.compose.inspect_services',return_value=state), \
             patch('track3forge.compose.ready_services',return_value=True):
            result=validate_packaged_runtime(cfg,timeout=20)
        self.assertEqual(result['status'],'PASS')
        self.assertTrue(result['cleaned_up'])

    def test_runtime_rejects_ports(self):
        self.compose['services']['web']['ports']=['127.0.0.1:3000:3000']
        self.refresh()
        with self.assertRaisesRegex(ValueError,'UNSAFE_PACKAGED_SERVICE'):
            validate_packaged_runtime(self.case/'portable.compose.json')

    def test_runtime_fails_safely(self):
        from subprocess import CompletedProcess
        broken=CompletedProcess(['docker'],1,stdout='',stderr='fake network failure')
        with patch('subprocess.run',return_value=broken):
            with self.assertRaisesRegex(ValueError,'PACKAGED_RUNTIME_FAILED'):
                validate_packaged_runtime(self.case/'portable.compose.json',timeout=20)

    def test_no_symlink_archive(self):
        original=self.tar
        replacement=self.case/'elsewhere.tar'
        original.rename(replacement)
        original.symlink_to(replacement)
        with self.assertRaisesRegex(ValueError,'UNSAFE_OR_MISSING_FILE'): self.inspect()

    def test_good_archive(self):
        self.assertEqual(self.inspect()['integrity']['status'],'PASS')
    def test_corrupt_archive(self):
        self.tar.write_bytes(self.tar.read_bytes()+b'broken')
        self.rec['artifact_sha256_recorded']=sha(self.tar)
        self.build['archive_sha256']=sha(self.tar)
        self.redo['image_archive_sha256']=sha(self.tar)
        self.refresh()
        # Extra trailing bytes don't necessarily invalidate tar; this tests digest mismatch separately.
        self.redo['image_archive_sha256']='0'*64
        self.refresh()
        with self.assertRaisesRegex(ValueError,'ARCHIVE_SHA256_MISMATCH'):self.inspect()
    def test_missing_archive(self):
        self.tar.unlink()
        with self.assertRaisesRegex(ValueError,'UNSAFE_OR_MISSING_FILE'):self.inspect()
    def test_bad_build_status(self):
        self.build['status']='FAILED';self.refresh()
        with self.assertRaisesRegex(ValueError,'BUILD_RECEIPT'):self.inspect()
    def test_bad_redeploy_status(self):
        self.redo['status']='FAILED';self.refresh()
        with self.assertRaisesRegex(ValueError,'REDEPLOY_NOT_PROVEN'):self.inspect()
    def test_missing_clean_project(self):
        self.redo.pop('fresh_project');self.refresh()
        with self.assertRaisesRegex(ValueError,'REDEPLOY_NOT_PROVEN'):self.inspect()
    def test_wrong_cve(self):
        self.build['cve']='CVE-2021-42013';self.refresh()
        with self.assertRaisesRegex(ValueError,'BUILD_RECEIPT'):self.inspect()
    def test_compose_build_not_allowed(self):
        self.compose['services']['web']['build']='.';self.refresh()
        with self.assertRaisesRegex(ValueError,'COMPOSE_NOT_SELF_CONTAINED'):self.inspect()
    def test_network_required(self):
        self.compose['networks']['default']['internal']=False;self.refresh()
        with self.assertRaisesRegex(ValueError,'COMPOSE_ISOLATION_MISSING'):self.inspect()
    def test_good_promotion(self):
        row=promote_one(CVE,self.rec,self.root,self.root/'output'/'main',self.root/'output'/'rejected',docker_parse=False)
        self.assertEqual(row['status'],'MAIN_READY')
        dest=self.root/'output'/'main'/CVE
        self.assertTrue((dest/'docker-images.tar').is_file())
        self.assertEqual(sha(dest/'docker-images.tar'),self.digest)
        self.assertTrue((dest/'docker-compose.yml').is_file())
        self.assertEqual(json.loads((dest/'validation.json').read_text())['official_accepted'],None)
        self.assertTrue((dest/'manifest.json').is_file())
    def test_idempotent(self):
        self.test_good_promotion()
        row=promote_one(CVE,self.rec,self.root,self.root/'output'/'main',self.root/'output'/'rejected',docker_parse=False)
        self.assertEqual(row['status'],'MAIN_ALREADY_VALID')
    def test_repair_bad_existing(self):
        self.test_good_promotion()
        p=self.root/'output'/'main'/CVE/'README.md'
        p.write_text('tampered')
        row=promote_one(CVE,self.rec,self.root,self.root/'output'/'main',self.root/'output'/'rejected',docker_parse=False)
        self.assertEqual(row['status'],'MAIN_READY')
        self.assertTrue(list((self.root/'output'/'rejected').iterdir()))
    def test_copy_mode(self):
        row=promote_one(CVE,self.rec,self.root,self.root/'output'/'main',self.root/'output'/'rejected',mode='copy',docker_parse=False)
        self.assertEqual(row['status'],'MAIN_READY')
    def test_bundle_bind_mismatch(self):
        (self.case/'assets.txt').write_text('bad')
        (self.case/'delivery_assets.json').write_text(json.dumps({'portability_blockers':[],
            'packaged_static_binds':[{'relative_path':'assets.txt','size_bytes':4,'sha256':'0'*64}]}))
        with self.assertRaisesRegex(ValueError,'DELIVERY_BIND_HASH_MISMATCH'):self.inspect()
    def test_bundle_blockers(self):
        (self.case/'delivery_assets.json').write_text(json.dumps({'portability_blockers':[{'reason':'named volume'}]}))
        with self.assertRaisesRegex(ValueError,'PORTABILITY_BLOCKERS'):self.inspect()
    def test_bad_archive_not_in_main(self):
        self.tar.write_bytes(b'not tar')
        digest=sha(self.tar)
        self.rec['artifact_sha256_recorded']=digest
        self.build['archive_sha256']=digest
        self.redo['image_archive_sha256']=digest
        self.refresh()
        with self.assertRaisesRegex(ValueError,'ARCHIVE_INTEGRITY_FAILED'):self.inspect()
        self.assertFalse((self.root/'output'/'main'/CVE).exists())
    def test_report_gate(self):
        report=self.root/'report.json'
        report.write_text(json.dumps({'cves':[CVE],'cases':{CVE:self.rec}}))
        out=package_report(report,self.root,self.root/'output',minimum=1,docker_parse=False)
        self.assertEqual(out['gate'],'PASS')
        self.assertEqual(out['ready'],1)
    def test_report_rejected(self):
        self.rec['status']='NO_RECIPE'
        report=self.root/'report.json'
        report.write_text(json.dumps({'cves':[CVE],'cases':{CVE:self.rec}}))
        out=package_report(report,self.root,self.root/'output',minimum=1,docker_parse=False)
        self.assertEqual(out['gate'],'BELOW_TARGET')
        self.assertEqual(out['ready'],0)
    def test_key_stable(self):
        self.assertEqual(key_for([CVE],self.root),key_for([CVE],self.root))
    def test_read_list(self):
        test=self.root/'cves.txt';test.write_text(CVE+'\n')
        self.assertEqual(read_list(str(test)),[CVE])

if __name__=='__main__':unittest.main()
