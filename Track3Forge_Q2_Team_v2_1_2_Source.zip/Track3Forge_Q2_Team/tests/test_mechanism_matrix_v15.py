import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from track3forge import mechanism
from track3forge.cli import make_parser
from track3forge.core import TaskError


class MechanismMatrixTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)/'vulhub'
        self.root.mkdir()
        samples=[
            ('CVE-2021-43798','grafana','Grafana',['Path Traversal','Info Disclosure']),
            ('CVE-2021-41773','httpd','Apache HTTP Server',['Path Traversal','RCE']),
            ('CVE-2023-46604','activemq','Apache ActiveMQ',['Deserialization','RCE']),
            ('CVE-2021-35042','django','Django',['SQL Injection']),
            ('CVE-2018-8715','appweb','AppWeb',['Auth Bypass']),
            ('CVE-2021-25646','druid','Apache Druid',['RCE']),
            ('CVE-2023-51449','gradio','Gradio',['Path Traversal']),
            ('CVE-2017-12635','couchdb','CouchDB',['Auth Bypass']),
        ]
        entries=[]
        for cve,dir,app,tags in samples:
            p=self.root/dir/cve
            p.mkdir(parents=True)
            (p/'docker-compose.yml').write_text('services: {}\n')
            t=', '.join(json.dumps(v) for v in tags)
            entries.append('[[environment]]\n'+
                f'name = "{app} test"\ncve = ["{cve}"]\napp = "{app}"\n'+
                f'path = "{dir}/{cve}"\ntags = [{t}]\n')
        (self.root/'environments.toml').write_text('\n'.join(entries))
        self.cves=[x[0] for x in samples]

    def test_registry_classifies_different_products(self):
        a=mechanism.assess(self.cves,self.root)
        self.assertEqual(a['requested'],8)
        self.assertEqual(a['registered_recipe_matches'],8)
        self.assertEqual(a['oracle_implemented'],3)
        by={r['cve']:r for r in a['rows']}
        self.assertEqual(by['CVE-2021-35042']['primary_family'],'SQL_INJECTION')
        self.assertIn('CODE_EXECUTION',by['CVE-2023-46604']['families'])
        self.assertEqual(by['CVE-2018-8715']['primary_family'],'AUTHORIZATION_BYPASS')
        self.assertEqual(by['CVE-2023-51449']['oracle_status'],'ORACLE_REQUIRED')

    def test_diverse_selection_and_holdout_are_stable(self):
        a=mechanism.assess(self.cves,self.root)
        first,holdout=mechanism.choose_diverse(a,5,42)
        again,_=mechanism.choose_diverse(a,5,42)
        self.assertEqual([x['cve'] for x in first],[x['cve'] for x in again])
        self.assertEqual(len({x['cve'] for x in first}),5)
        self.assertEqual(len(holdout),3)
        self.assertGreaterEqual(len({x['primary_family'] for x in first}),4)
        out=Path(self.tmp.name)/'out'
        mechanism.write_matrix(out,a,choose=5,seed=42)
        self.assertEqual(len((out/'selected_cves.txt').read_text().splitlines()),5)
        self.assertEqual(len((out/'holdout_cves.txt').read_text().splitlines()),3)

    def test_registry_path_escape_rejected(self):
        p=self.root/'environments.toml'
        p.write_text('[[environment]]\nname="bad"\npath="../escape"\ncve=["CVE-2021-43798"]\n')
        with self.assertRaises(TaskError) as e:
            mechanism.assess(self.cves,self.root)
        self.assertEqual(e.exception.code,'REGISTRY_UNSAFE_PATH')

    def test_missing_registry_fails_closed(self):
        (self.root/'environments.toml').unlink()
        with self.assertRaises(TaskError) as e:mechanism.assess(self.cves,self.root)
        self.assertEqual(e.exception.code,'REGISTRY_MISSING')

    def test_unregistered_cve_never_gets_oracle(self):
        cve='CVE-2024-99999'
        p=self.root/'newproduct'/cve;p.mkdir(parents=True)
        (p/'docker-compose.yml').write_text('services: {}\n')
        r=mechanism.assess([cve],self.root)['rows'][0]
        self.assertEqual(r['recipe_status'],'UNREGISTERED_RECIPE_FOUND')
        self.assertEqual(r['oracle_status'],'ORACLE_REQUIRED')
        self.assertEqual(r['proof']['status'],'NOT_EVALUATED')

    def test_forged_proof_is_rejected(self):
        cve='CVE-2023-46604'
        case=Path(self.tmp.name)/'pilot'/cve
        (case/'proof/activemq').mkdir(parents=True)
        artifact=case/'sample.tar'
        artifact.write_bytes(b'expected protected local artifact')
        digest=hashlib.sha256(artifact.read_bytes()).hexdigest()
        (case/'result.json').write_text(json.dumps({'cve':cve,'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF','archive_sha256':digest,'artifact':str(artifact)}))
        proof={'cve':cve,'status':'BEHAVIOR_VERIFIED','vulnerability_verified':True,
               'identity':{'artifact_sha256':'b'*64},
               'vulnerable_trial':{'callback_from_broker':True,'baseline_no_callback':True,'cleanup_ok':True},
               'fixed_trial':{'callback_from_broker':False,'baseline_no_callback':True,'cleanup_ok':True}}
        p=case/'proof/activemq/activemq_proof.json'
        p.write_text(json.dumps(proof))
        r=mechanism.assess([cve],self.root,pilot=case.parent)['rows'][0]
        self.assertEqual(r['proof']['status'],'PROOF_UNTRUSTED_OR_ARTIFACT_MISMATCH')
        proof['identity']['artifact_sha256']=digest
        p.write_text(json.dumps(proof))
        r=mechanism.assess([cve],self.root,pilot=case.parent)['rows'][0]
        self.assertEqual(r['proof']['status'],'BEHAVIOR_VERIFIED')
        proof['fixed_trial']['callback_from_broker']=True
        p.write_text(json.dumps(proof))
        r=mechanism.assess([cve],self.root,pilot=case.parent)['rows'][0]
        self.assertEqual(r['proof']['status'],'PROOF_CONTRACT_FAILED')

    def test_cli_arguments(self):
        args=make_parser().parse_args(['q2','matrix','--cves','CVE-2024-10000','--select','1'])
        self.assertEqual(args.seed,42)
        self.assertEqual(args.select,1)
        self.assertEqual(args.q2_cmd,'matrix')

    def test_unregistered_cannot_be_selected(self):
        a=mechanism.assess(['CVE-2024-99999'],self.root)
        with self.assertRaises(TaskError) as err:mechanism.choose_diverse(a,1)
        self.assertEqual(err.exception.code,'INSUFFICIENT_REGISTERED_RECIPES')


if __name__=='__main__':unittest.main()
