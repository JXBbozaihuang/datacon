"""Regression for relative --source passed to Q2 plan/discover."""
import argparse
import contextlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from track3forge.cli import _source
from track3forge.compose import process_cves
from track3forge.core import TaskError

class _Proc:
    def __init__(self, stdout):
        self.stdout=stdout

class _CheckingExecutor:
    def __init__(self):
        self.calls=[]
    def run(self, argv, **kwargs):
        self.calls.append((argv,kwargs))
        candidate=Path(argv[argv.index('-f')+1])
        cwd=Path(kwargs['cwd'])
        if not candidate.is_absolute():
            candidate=cwd/candidate
        if not candidate.is_file():
            raise TaskError('COMMAND_FAILED',f'Docker cannot find Compose config at {candidate}')
        return _Proc(json.dumps({'services':{'web':{'image':'example.com/project:1'}}}))

class RelativeSourceTests(unittest.TestCase):
    def test_relative_source_becomes_absolute_in_cli(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous=os.getcwd()
            try:
                os.chdir(tmp)
                Path('data/vulhub').mkdir(parents=True)
                source,_=_source(argparse.Namespace(source='data/vulhub',fetch=False))
                self.assertEqual(source, Path(tmp,'data/vulhub').resolve())
                self.assertTrue(source.is_absolute())
            finally:
                os.chdir(previous)

    def test_q2_plan_from_relative_root_uses_real_compose_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous=os.getcwd()
            try:
                os.chdir(tmp)
                path=Path('data/vulhub/grafana/CVE-2021-43798/docker-compose.yml')
                path.parent.mkdir(parents=True)
                path.write_text('services:\n  web:\n    image: example.com/project:1\n')
                runner=_CheckingExecutor()
                summary=process_cves(['CVE-2021-43798'],Path('data/vulhub'),Path('results'),
                                      runner=runner,execute=False)
                self.assertEqual(summary['results'][0]['status'],'RECIPE_FOUND_NOT_RUN',
                                 (Path('results/CVE-2021-43798/result.json').read_text()))
                self.assertTrue(runner.calls[0][0][runner.calls[0][0].index('-f')+1].startswith('/'))
            finally:
                os.chdir(previous)
