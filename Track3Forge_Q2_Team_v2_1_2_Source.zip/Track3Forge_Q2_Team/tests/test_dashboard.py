import json,tempfile,unittest
from pathlib import Path
from track3forge.dashboard import get_case,run_index
from track3forge.core import TaskError
class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name);r=self.p/'run-123';r.mkdir()
        (r/'summary.json').write_text(json.dumps({'requested':2,'results':[{'cve':'CVE-2021-43798','status':'NO_RECIPE'}]}))
        (r/'CVE-2021-43798').mkdir()
        (r/'CVE-2021-43798'/'result.json').write_text('{"status":"NO_RECIPE"}')
    def test_index_and_case(self):
        self.assertEqual(run_index(self.p)[0]['requested'],2)
        self.assertEqual(get_case(self.p,'run-123','CVE-2021-43798')['status'],'NO_RECIPE')
    def test_no_path_traversal(self):
        with self.assertRaises(TaskError):get_case(self.p,'../','CVE-2021-43798')
        with self.assertRaises(TaskError):get_case(self.p,'run-123','../')
if __name__=='__main__':unittest.main()

class ProofViewTests(unittest.TestCase):
    def test_proof_count_from_real_evidence_file(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);case=root/'run-111'/'CVE-2021-43798';case.mkdir(parents=True)
            (root/'run-111'/'summary.json').write_text(json.dumps({'requested':1,'results':[{'cve':'CVE-2021-43798','status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF'}]}))
            proof=case/'proof';proof.mkdir()
            (proof/'known_proof.json').write_text(json.dumps({'status':'BEHAVIOR_VERIFIED','vulnerability_verified':True}))
            items=run_index(root)
            self.assertEqual(items[0]['verified_vulnerabilities'],1)
            self.assertEqual(items[0]['results'][0]['proof_status'],'BEHAVIOR_VERIFIED')
