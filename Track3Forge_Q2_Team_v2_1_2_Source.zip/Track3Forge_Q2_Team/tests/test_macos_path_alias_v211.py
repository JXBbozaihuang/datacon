"""Cross-platform reproduction of macOS /var => /private/var alias."""
import tempfile
import unittest
from pathlib import Path
from tools.SUBMISSION_GATE import ensure_file

class PathAliasTests(unittest.TestCase):
    def test_project_root_seen_via_alias(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            real=base/'private'/'var'/'folders'/'job'/'project'
            real.mkdir(parents=True)
            (real/'data.tar').write_bytes(b'test')
            (base/'var').symlink_to(base/'private'/'var',target_is_directory=True)
            lexical=base/'var'/'folders'/'job'/'project'/'data.tar'
            ensure_file(lexical,real)
            ensure_file(real/'data.tar',lexical.parent)

    def test_symlink_inside_project_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'project'
            (root/'real').mkdir(parents=True)
            (root/'real'/'data.tar').write_bytes(b'test')
            (root/'link').symlink_to(root/'real',target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'SYMLINK_PARENT'):
                ensure_file(root/'link'/'data.tar',root)

    def test_file_outside_root_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            root=base/'project';root.mkdir()
            outside=base/'outside.tar';outside.write_bytes(b'test')
            with self.assertRaisesRegex(ValueError,'UNSAFE_OR_MISSING_FILE'):
                ensure_file(outside,root)

if __name__=='__main__': unittest.main()
