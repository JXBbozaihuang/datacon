import hashlib,io,json,shutil,tarfile,tempfile,unittest
from pathlib import Path
from track3forge.verify import assert_archive_tag
from track3forge.core import TaskError
class Proc:
    def __init__(self,rc=0,stdout=''):self.returncode=rc;self.stdout=stdout
class Docker29Fake:
    def __init__(self,source,wrong=False):self.source=Path(source);self.wrong=wrong;self.calls=[]
    def run(self,args,**kwargs):
        self.calls.append(args)
        if args[:3]==['docker','image','inspect']:
            # Different from Config SHA, as on some Docker 29 image stores.
            return Proc(0,'[{"Id":"sha256:ffffffffffff"}]')
        if args[:2]==['docker','save']:
            out=Path(args[args.index('-o')+1])
            if not self.wrong:shutil.copy2(self.source,out)
            else:
                conf=b'{"different":1}';name=hashlib.sha256(conf).hexdigest()+'.json'
                blob={'manifest.json':json.dumps([{'Config':name,'Layers':['x/layer.tar'],'RepoTags':['x:1']}]).encode(),name:conf,'x/layer.tar':b'thing'}
                with tarfile.open(out,'w') as tar:
                    for n,data in blob.items():
                        ent=tarfile.TarInfo(n);ent.size=len(data);tar.addfile(ent,io.BytesIO(data))
            return Proc()
        return Proc()
class Docker29Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'image.tar'
        conf=b'{"created":"test"}';name=hashlib.sha256(conf).hexdigest()+'.json'
        blob={'manifest.json':json.dumps([{'Config':name,'Layers':['x/layer.tar'],'RepoTags':['x:1']}]).encode(),name:conf,'x/layer.tar':b'thing'}
        with tarfile.open(self.path,'w') as tar:
            for n,data in blob.items():
                ent=tarfile.TarInfo(n);ent.size=len(data);tar.addfile(ent,io.BytesIO(data))
    def test_different_image_store_id_allowed_when_reexport_matches(self):
        d=assert_archive_tag(self.path,'x:1',Docker29Fake(self.path))
        self.assertEqual(d['status'],'ARCHIVE_TAG_CONFIG_MATCHED')
    def test_config_mismatch_rejected(self):
        with self.assertRaises(TaskError) as e:assert_archive_tag(self.path,'x:1',Docker29Fake(self.path,wrong=True))
        self.assertEqual(e.exception.code,'IMAGE_CONTENT_MISMATCH')
    def test_archive_tag_required(self):
        with self.assertRaises(TaskError) as e:assert_archive_tag(self.path,'other:1',Docker29Fake(self.path))
        self.assertEqual(e.exception.code,'IMAGE_NOT_IN_ARTIFACT')
if __name__=='__main__':unittest.main()
