import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from track3forge import verify
from track3forge.core import TaskError
class Process:
    def __init__(self,returncode=0,stdout=''):self.returncode=returncode;self.stdout=stdout
class Fake:
    def __init__(self):self.calls=[]
    def run(self,args,**kwargs):
        self.calls.append(args)
        return Process()
class ProofTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name);self.artifact=self.p/'saved.tar';self.artifact.write_bytes(b'placeholder')
    @patch.object(verify,'assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'})
    @patch.object(verify,'probe_trial')
    def test_strict_positive_fixed_negative(self,probe,identity):
        probe.side_effect=[{'health_version':'8.2.6','positive_http':200,'positive_exact':True,'negative_exact':False},
                           {'health_version':'8.2.7','positive_http':404,'positive_exact':False,'negative_exact':False}]
        d=verify.verify_known('CVE-2021-43798',self.artifact,'vulhub/grafana:8.2.6',self.p/'e',runner=Fake())
        self.assertEqual(d['status'],'BEHAVIOR_VERIFIED');self.assertTrue(d['vulnerability_verified'])
        self.assertEqual(probe.call_count,2)
    @patch.object(verify,'assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'})
    @patch.object(verify,'probe_trial')
    def test_requires_fixed_negative(self,probe,identity):
        probe.side_effect=[{'health_version':'8.2.6','positive_http':200,'positive_exact':True,'negative_exact':False},
                           {'health_version':'8.2.7','positive_http':200,'positive_exact':True,'negative_exact':False}]
        d=verify.verify_known('CVE-2021-43798',self.artifact,'vulhub/grafana:8.2.6',self.p/'e',runner=Fake())
        self.assertEqual(d['status'],'NOT_REPRODUCED')
        self.assertFalse(d['vulnerability_verified'])
    @patch.object(verify,'assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'})
    @patch.object(verify,'probe_trial')
    def test_requires_normal_path_negative(self,probe,identity):
        probe.side_effect=[{'health_version':'8.2.6','positive_http':200,'positive_exact':True,'negative_exact':True},
                           {'health_version':'8.2.7','positive_http':404,'positive_exact':False,'negative_exact':False}]
        d=verify.verify_known('CVE-2021-43798',self.artifact,'vulhub/grafana:8.2.6',self.p/'e',runner=Fake())
        self.assertEqual(d['status'],'NOT_REPRODUCED')
    def test_unknown_cve_is_not_proven(self):
        d=verify.verify_known('CVE-2023-46604',self.artifact,'x',self.p/'e',runner=Fake())
        self.assertEqual(d['status'],'PROOF_FAILED')
        self.assertEqual(d['error_code'],'ORACLE_NOT_IMPLEMENTED')
    def test_curl_uses_only_internal_network_no_port(self):
        class CurlFake(Fake):
            def run(self,args,**kwargs):
                self.calls.append(args)
                return Process(stdout='hello\n__T3HTTP__:200')
        runner=CurlFake();x=verify._curl(runner,'test_internal','target','/api/health')
        self.assertEqual(x,{'http':200,'body':'hello'})
        s=' '.join(runner.calls[0])
        self.assertIn('--network test_internal',s)
        self.assertNotIn(' -p ',s)
        self.assertIn('--path-as-is',s)
    def test_target_probe_failure_cleanup(self):
        class Runner(Fake):
            def run(self,args,**kwargs):
                self.calls.append(args)
                if args[:3]==['docker','run','-d']:raise TaskError('IMAGE_FAILED','bad image')
                return Process(stdout='x')
        r=Runner();v=verify.probe_trial(r,'bad:tag','marker','vulnerable',expected_version='8.2.6')
        self.assertEqual(v['error_code'],'IMAGE_FAILED')
        self.assertTrue(any(x[:3]==['docker','network','rm'] for x in r.calls))
if __name__=='__main__':unittest.main()
