import json
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from track3forge.core import Executor, TaskError
from track3forge.compose import compose_up_with_retries


class Runner:
    def __init__(self):
        self.calls=0
    def run(self, args, **kwargs):
        self.calls+=1
        err=TaskError('TIMEOUT','docker timed out')
        err.partial_stdout='9aa Downloading 53.48MB\n'
        err.partial_stderr='Get auth.docker.io/token: context deadline exceeded\n'
        raise err


class TimeoutEvidenceTests(unittest.TestCase):
    def test_executor_retains_partial_output_in_timeout_error(self):
        with self.assertRaises(TaskError) as cm:
            Executor().run([sys.executable,'-c',
                 'import sys,time; print("DOWNLOAD_PROGRESS=15MB",flush=True);'
                 'print("TOKEN_FETCH_PENDING",file=sys.stderr,flush=True);time.sleep(4)'],
                 timeout=1.0)
        self.assertEqual(cm.exception.code,'TIMEOUT')
        self.assertIn('DOWNLOAD_PROGRESS=15MB',cm.exception.partial_stdout)
        self.assertIn('TOKEN_FETCH_PENDING',cm.exception.partial_stderr)

    def test_compose_timeout_logs_partial_output_without_retry(self):
        with tempfile.TemporaryDirectory() as t:
            runner=Runner()
            with self.assertRaises(TaskError) as cm:
                compose_up_with_retries(runner,['docker','compose','up'],Path(t),time.monotonic()+60)
            self.assertEqual(cm.exception.code,'COMPOSE_UP_TIMEOUT')
            self.assertEqual(runner.calls,1)
            attempts=json.loads((Path(t)/'compose_up_attempts.json').read_text())
            self.assertEqual(len(attempts),1)
            self.assertEqual(attempts[0]['exit_code'],124)
            self.assertTrue(attempts[0]['timed_out'])
            self.assertFalse(attempts[0]['retryable'])
            self.assertEqual(attempts[0]['classification'],'COMPOSE_UP_TIMEOUT')
            self.assertIn('auth.docker.io', (Path(t)/'compose_up_attempt_1.log').read_text())

    def test_audit_image_ref_extract(self):
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
        from AUDIT_TIMEOUTS import image_refs
        d={'services':{'web':{'image':'vulhub/test:1'},'db':{'image':'postgres:12'},'bad':{}}}
        self.assertEqual(image_refs(d),['postgres:12','vulhub/test:1'])


if __name__=='__main__':unittest.main()
