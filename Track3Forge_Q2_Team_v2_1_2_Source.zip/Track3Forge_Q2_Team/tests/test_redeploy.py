import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from track3forge import compose
from track3forge.core import TaskError
from test_docker_integration_mock import FakeDocker
class RedeployTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name);self.case=self.p/'case';self.case.mkdir()
        a=self.case/'images.tar';a.write_bytes(b'fake-only')
        (self.case/'portable.compose.json').write_text(json.dumps({'services':{'web':{'image':'grafana/grafana:8.2.6'}},
          'networks':{'default':{'internal':True}}}))
        (self.case/'result.json').write_text(json.dumps({'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
           'portability':'REDEPLOY_NOT_TESTED','artifact':str(a),'images':['grafana/grafana:8.2.6']}))
    @patch('track3forge.verify.assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'})
    def test_new_project_redeploy(self,identity):
        run=FakeDocker(self.p)
        result=compose.redeploy_check(self.case,runner=run,budget=40)
        self.assertEqual(result['status'],'CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF')
        self.assertFalse(result['verified_vulnerability'])
        self.assertTrue(any(' up ' in ' '.join(x) for x in run.calls))
        self.assertTrue(any(' down ' in ' '.join(x) for x in run.calls))
    def test_volume_state_blocks_delivery(self):
        p=self.case/'result.json';d=json.loads(p.read_text())
        d['portability']='SOURCE_OR_VOLUME_REQUIRED';p.write_text(json.dumps(d))
        with self.assertRaises(TaskError) as e:compose.redeploy_check(self.case)
        self.assertEqual(e.exception.code,'PORTABILITY_UNRESOLVED')
    @patch('track3forge.verify.assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'})
    def test_reject_portable_compose_with_build(self,identity):
        p=self.case/'portable.compose.json';d=json.loads(p.read_text())
        d['services']['web']['build']={'context':'/tmp'};p.write_text(json.dumps(d))
        result=compose.redeploy_check(self.case,runner=FakeDocker(self.p),budget=40)
        self.assertEqual(result['status'],'FAILED')
        self.assertEqual(result['error_code'],'PORTABILITY_UNSAFE')
