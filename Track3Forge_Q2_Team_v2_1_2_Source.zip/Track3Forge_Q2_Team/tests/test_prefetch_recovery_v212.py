"""v2.1.2: real import contract + mocked pull receipts; no Docker/network."""
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS=Path(__file__).resolve().parents[1]/'tools'
sys.path.insert(0,str(TOOLS))
from BATCH30 import try_pull, execution_order
from PREFETCH_MISSING import classify, tail_log, pull_image


class PrefetchRecoveryTests(unittest.TestCase):
    def test_cached_ready_cases_prioritized_without_changing_report_order(self):
        original=['CVE-2020-17518','CVE-2021-43798','CVE-2021-45232','CVE-2022-26134']
        report={'cves':original[:],'cases':{
            original[0]:{'status':'BLOCKED_REGISTRY'},
            original[1]:{'status':'READY_TO_RUN'},
            original[2]:{'status':'READY_TO_RUN'},
            original[3]:{'status':'BLOCKED_REGISTRY'},
        }}
        self.assertEqual(execution_order(report), [original[1], original[2], original[0], original[3]])
        self.assertEqual(report['cves'], original)

    def test_prefetch_module_interface_present(self):
        self.assertTrue(callable(pull_image))
        self.assertTrue(callable(classify))
        self.assertTrue(callable(tail_log))

    def test_pull_success_verified_by_inspect_not_by_exit_alone(self):
        with tempfile.TemporaryDirectory() as td:
            def puller(image, log, seconds, progress=True):
                log.write_text('Downloaded newer image\n',encoding='utf-8')
                return 0,False,.01
            r=try_pull('example/fixture:v1', Path(td),budget=30,puller=puller,
                inspector=lambda image: {'id':'sha256:abc','platform':'linux/arm64'})
            self.assertTrue(r['ok']); self.assertIsNone(r['failure'])

    def test_pull_exit_zero_without_cached_image_not_pass(self):
        with tempfile.TemporaryDirectory() as td:
            def puller(image, log, seconds, progress=True):
                log.write_text('Pull complete\n',encoding='utf-8')
                return 0,False,.01
            r=try_pull('example/fixture:v1',Path(td),budget=30,puller=puller,
                       inspector=lambda image: None)
            self.assertFalse(r['ok'])

    def test_transient_transport_error_classified(self):
        with tempfile.TemporaryDirectory() as td:
            def puller(image, log, seconds, progress=True):
                log.write_text('unexpected EOF\n',encoding='utf-8')
                return 1,False,.01
            r=try_pull('example/fixture:v1',Path(td),budget=30,puller=puller,
                       inspector=lambda image: None)
            self.assertEqual(r['failure'],'REGISTRY_TRANSFER_TRANSIENT')

if __name__=='__main__': unittest.main()
