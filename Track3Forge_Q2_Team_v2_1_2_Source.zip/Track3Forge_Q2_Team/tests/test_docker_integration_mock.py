import io, json,hashlib,tarfile,tempfile,unittest
from pathlib import Path
from track3forge.compose import candidate_run
from track3forge.core import TaskError
class Proc:
    def __init__(self,text='',rc=0):self.stdout=text;self.stderr='';self.returncode=rc
class FakeDocker:
    def __init__(self,base,*,unhealthy=False,image_drift=False,services=None):
        self.root=Path(base);self.calls=[];self.unhealthy=unhealthy;self.image_drift=image_drift
        self.services=services or {'web':{'image':'grafana/grafana:8.2.6'}}
    def run(self,args,**kwargs):
        self.calls.append(list(args));cmd=' '.join(args)
        if ' config --format json' in cmd:
            return Proc(json.dumps({'services':self.services}))
        if cmd.startswith('docker compose ') and ' ps -q ' in cmd:
            return Proc('fake-id\n')
        if cmd.startswith('docker inspect fake-id'):
            s={'Status':'exited' if self.unhealthy else 'running',
               'Running':not self.unhealthy,'ExitCode':1 if self.unhealthy else 0,
               'Health':{'Status':'unhealthy' if self.unhealthy else 'healthy'}}
            return Proc(json.dumps([{'State':s,'Config':{'Image':'grafana/grafana:8.2.6'},'Image':'sha256:old'}]))
        if cmd.startswith('docker image inspect'):
            count=sum(1 for c in self.calls if ' '.join(c).startswith('docker image inspect'))
            digest='sha256:changed' if self.image_drift and count>=2 else 'sha256:original'
            return Proc(json.dumps([{'Id':digest}]))
        if cmd.startswith('docker save -o '):
            path=Path(args[args.index('-o')+1]);path.parent.mkdir(parents=True,exist_ok=True)
            conf=b'{"architecture":"amd64"}';name=hashlib.sha256(conf).hexdigest()+'.json'
            members={'manifest.json':json.dumps([{'Config':name,'Layers':['layer/layer.tar'],'RepoTags':['grafana/grafana:8.2.6']}]).encode(),
                     name:conf,'layer/layer.tar':b'layer content'}
            with tarfile.open(path,'w') as t:
                for n,b in members.items():
                    i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
            return Proc()
        return Proc('')
class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.recipe=self.root/'CVE-2021-43798'/'docker-compose.yml'
        self.recipe.parent.mkdir();self.recipe.write_text('services: {}')
    def test_realistic_mock_build_export_cleanup(self):
        runner=FakeDocker(self.root)
        x=candidate_run('CVE-2021-43798',self.recipe,self.root,self.root/'out',execute=True,
                        acknowledge=True,runner=runner,budget=60)
        self.assertEqual(x['status'],'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF')
        self.assertFalse(x['verified_vulnerability'])
        self.assertTrue(Path(x['artifact']).exists())
        self.assertTrue(any(' down ' in ' '.join(c) for c in runner.calls))
        sanitized=json.loads((self.root/'out'/'isolated.compose.json').read_text())
        self.assertTrue(sanitized['networks']['default']['internal'])
    def test_unhealthy_service_fails_not_exports(self):
        runner=FakeDocker(self.root,unhealthy=True)
        x=candidate_run('CVE-2021-43798',self.recipe,self.root,self.root/'out',execute=True,
                        acknowledge=True,runner=runner,budget=60)
        self.assertEqual(x['status'],'FAILED')
        self.assertEqual(x['error_code'],'SERVICE_EXITED')
        self.assertFalse((self.root/'out'/'CVE-2021-43798-docker-images.tar').exists())
    def test_image_tag_changes_during_save(self):
        runner=FakeDocker(self.root,image_drift=True)
        x=candidate_run('CVE-2021-43798',self.recipe,self.root,self.root/'out',execute=True,
                        acknowledge=True,runner=runner,budget=60)
        self.assertEqual(x['status'],'FAILED')
        self.assertEqual(x['error_code'],'IMAGE_CHANGED_DURING_EXPORT')
    def test_plan_cannot_start_docker(self):
        runner=FakeDocker(self.root)
        x=candidate_run('CVE-2021-43798',self.recipe,self.root,self.root/'out',execute=False,
                        acknowledge=False,runner=runner,budget=60)
        self.assertEqual(x['status'],'RECIPE_FOUND_NOT_RUN')
        self.assertFalse(any(' up ' in ' '.join(c) for c in runner.calls))
    def test_no_ack_fails_before_up(self):
        runner=FakeDocker(self.root)
        x=candidate_run('CVE-2021-43798',self.recipe,self.root,self.root/'out',execute=True,
                        acknowledge=False,runner=runner,budget=60)
        self.assertEqual(x['status'],'FAILED')
        self.assertEqual(x['error_code'],'LAB_ACK_REQUIRED')
        self.assertFalse(any(' up ' in ' '.join(c) for c in runner.calls))
if __name__=='__main__':unittest.main()
