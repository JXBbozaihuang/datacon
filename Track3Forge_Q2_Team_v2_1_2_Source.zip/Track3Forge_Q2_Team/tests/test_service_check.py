import argparse
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from track3forge import service_check, cli
from track3forge.core import TaskError


class Process:
    def __init__(self, stdout='', returncode=0, stderr=''):
        self.stdout, self.returncode, self.stderr = stdout, returncode, stderr


class DockerFake:
    def __init__(self, *, http_good=True, internal=True, published=False, fail_up=False):
        self.calls=[]
        self.http_good=http_good
        self.internal=internal
        self.published=published
        self.fail_up=fail_up

    def run(self, argv, **kwargs):
        self.calls.append(list(argv))
        s=' '.join(argv)
        if ' up -d ' in ' '+s+' ' and self.fail_up:
            raise TaskError('COMMAND_FAILED','compose up could not start')
        if s.startswith('docker compose ') and ' ps -q ' in s:
            return Process('CONTAINER01\n')
        if s.startswith('docker inspect CONTAINER01'):
            return Process(json.dumps([{'NetworkSettings':{'Networks':{'t3svc_default':{}}},
                'HostConfig':{'PortBindings':{'80/tcp':[{'HostPort':'80'}]} if self.published else {}}}]))
        if s.startswith('docker network inspect t3svc_default'):
            return Process(json.dumps([{'Internal':self.internal}]))
        if '--entrypoint curl' in s:
            if not self.http_good:
                return Process('server down\n__T3STATUS__:503')
            return Process('It works!\n__T3STATUS__:200')
        if '--entrypoint python' in s and 'python:3.12-alpine' in s:
            return Process('{"tcp_connected":true}\n')
        return Process('')


class ServiceAcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.case=self.root/'CVE-2021-41773'
        self.case.mkdir()
        self.tar=self.case/'CVE-2021-41773-docker-images.tar'
        self.tar.write_bytes(b'test bytes')
        self.config={'services':{'apache':{'image':'test/apache:1'}},
                     'networks':{'default':{'internal':True}}}
        (self.case/'portable.compose.json').write_text(json.dumps(self.config))
        self.case_report={'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
            'portability':'REDEPLOY_NOT_TESTED','cve':'CVE-2021-41773',
            'artifact':str(self.tar),'archive_sha256':'fake-sha',
            'images':['test/apache:1']}
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        self.state={'apache':{'running':True,'health':None,'status':'running','image_ref':'test/apache:1'}}

    def execute(self,runner,**kw):
        with patch.object(service_check,'sha256_file',return_value='fake-sha'),\
             patch.object(service_check,'assert_archive_tag',return_value={'status':'OK'}),\
             patch.object(service_check,'inspect_services',return_value=self.state):
            return service_check.check_case(self.case,runner=runner,**kw)

    def test_apache_real_traffic_and_cleanup_not_cve_proof(self):
        r=DockerFake(); d=self.execute(r)
        self.assertEqual(d['status'],'APPLICATION_RESPONDED_NOT_CVE_PROOF')
        self.assertFalse(d['verified_vulnerability'])
        self.assertEqual(d['trial']['http'],200)
        cmds=[' '.join(x) for x in r.calls]
        self.assertTrue(any('docker run --rm --network t3svc_default' in x for x in cmds))
        self.assertTrue(any('docker compose' in x and 'down --remove-orphans --volumes' in x for x in cmds))
        self.assertTrue(any('docker network inspect t3svc_default' in x for x in cmds))
        self.assertFalse(any('docker port' in x for x in cmds))
        self.assertFalse(any(' -p 127.0.0.1' in x for x in cmds))
        self.assertTrue((self.case/'service_check.json').exists())

    def test_http_503_not_a_pass(self):
        # Simulate elapsed time without sleeping for a real 120-second budget.
        class Clock:
            t=1000.0
            def monotonic(self):return self.t
            def sleep(self,sec):self.t+=sec
        clock=Clock()
        with patch.object(service_check.time,'monotonic',side_effect=clock.monotonic), \
             patch.object(service_check.time,'sleep',side_effect=clock.sleep):
            d=self.execute(DockerFake(http_good=False),budget=30)
        self.assertEqual(d['status'],'SERVICE_CHECK_FAILED')
        self.assertEqual(d['error_code'],'APPLICATION_NOT_READY')
        self.assertEqual(d['readiness']['status'],'TIMEOUT')
        self.assertGreaterEqual(len(d['readiness']['attempts']),2)
        self.assertEqual(d['cleanup'],'OK')

    def test_transient_grafana_connection_refused_then_health_passes(self):
        class StartupRace(DockerFake):
            n=0
            def run(self,argv,**kwargs):
                if '--entrypoint' in argv and 'curl' in argv:
                    self.n+=1
                    if self.n<3:
                        raise TaskError('COMMAND_FAILED','docker exit=7: curl: (7) Failed to connect to web port 3000')
                    self.calls.append(list(argv))
                    return Process('{"version":"8.2.6"}\n__T3STATUS__:200')
                return super().run(argv,**kwargs)
        self.case_report['cve']='CVE-2021-43798';self.case_report['images']=['test/apache:1']
        self.config['services']={'web':{'image':'test/apache:1'}}
        self.state={'web':{'running':True,'health':None,'status':'running','image_ref':'test/apache:1'}}
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        (self.case/'portable.compose.json').write_text(json.dumps(self.config))
        class Clock:
            t=1000.0
            def monotonic(self):return self.t
            def sleep(self,sec):self.t+=sec
        clock=Clock()
        with patch.object(service_check.time,'monotonic',side_effect=clock.monotonic), \
             patch.object(service_check.time,'sleep',side_effect=clock.sleep):
            d=self.execute(StartupRace())
        self.assertEqual(d['status'],'APPLICATION_RESPONDED_NOT_CVE_PROOF')
        self.assertEqual(d['readiness']['status'],'READY')
        self.assertEqual(len(d['readiness']['attempts']),3)
        self.assertFalse(d['verified_vulnerability'])

    def test_transient_activemq_connection_refused_then_tcp_connects(self):
        self.case_report['cve']='CVE-2023-46604';self.case_report['images']=['test/activemq:1']
        self.config['services']={'activemq':{'image':'test/activemq:1'}}
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        (self.case/'portable.compose.json').write_text(json.dumps(self.config))
        state={'activemq':{'running':True,'health':None,'status':'running','image_ref':'test/activemq:1'}}
        class StartupRace(DockerFake):
            n=0
            def run(self,argv,**kwargs):
                if '--entrypoint' in argv and 'python' in argv:
                    self.n+=1
                    if self.n<3:
                        raise TaskError('COMMAND_FAILED','docker exit=1: ConnectionRefusedError: [Errno 111] Connection refused')
                return super().run(argv,**kwargs)
        class Clock:
            t=1000.0
            def monotonic(self):return self.t
            def sleep(self,sec):self.t+=sec
        clock=Clock()
        with patch.object(service_check.time,'monotonic',side_effect=clock.monotonic), \
             patch.object(service_check.time,'sleep',side_effect=clock.sleep), \
             patch.object(service_check,'sha256_file',return_value='fake-sha'), \
             patch.object(service_check,'assert_archive_tag',return_value={}), \
             patch.object(service_check,'inspect_services',return_value=state):
            d=service_check.check_case(self.case,runner=StartupRace())
        self.assertEqual(d['status'],'OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF')
        self.assertEqual(len(d['readiness']['attempts']),3)
        self.assertFalse(d['verified_vulnerability'])

    def test_nontransient_version_mismatch_never_retried(self):
        with patch.object(service_check,'_profile_check',side_effect=TaskError('GRAFANA_HEALTH_MISMATCH','HTTP=200 version=8.2.7')) as f:
            with self.assertRaises(TaskError):
                service_check._await_application(DockerFake(),'net',{},'CVE-2021-43798',1e12,{})
        self.assertEqual(f.call_count,1)

    def test_network_must_be_internal_and_no_port_published(self):
        for values, expected in [({'internal':False},'NETWORK_NOT_INTERNAL'),
                                 ({'published':True},'HOST_PORT_PUBLISHED')]:
            with self.subTest(values=values):
                d=self.execute(DockerFake(**values))
                self.assertEqual(d['error_code'],expected)
                self.assertEqual(d['status'],'SERVICE_CHECK_FAILED')

    def test_failed_start_also_triggers_cleanup(self):
        r=DockerFake(fail_up=True); d=self.execute(r)
        self.assertEqual(d['error_code'],'COMMAND_FAILED')
        self.assertTrue(any('down --remove-orphans --volumes' in ' '.join(x) for x in r.calls))

    def test_tampered_artifact_fails_before_docker(self):
        runner=DockerFake()
        with patch.object(service_check,'sha256_file',return_value='incorrect'):
            d=service_check.check_case(self.case,runner=runner)
        self.assertEqual(d['error_code'],'ARTIFACT_SHA_MISMATCH')
        self.assertEqual(runner.calls,[])

    def test_non_exported_case_fails_closed(self):
        self.case_report['status']='FAILED'
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        d=service_check.check_case(self.case,runner=DockerFake())
        self.assertEqual(d['error_code'],'NOT_EXPORTED_CASE')

    def test_active_mq_real_sidecar_tcp_not_exploit_proof(self):
        self.case_report['cve']='CVE-2023-46604'; self.case_report['images']=['test/activemq:1']
        self.config['services']={'activemq':{'image':'test/activemq:1'}}
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        (self.case/'portable.compose.json').write_text(json.dumps(self.config))
        state={'activemq':{'running':True,'health':None,'status':'running','image_ref':'test/activemq:1'}}
        with patch.object(service_check,'sha256_file',return_value='fake-sha'),\
             patch.object(service_check,'assert_archive_tag',return_value={}),\
             patch.object(service_check,'inspect_services',return_value=state):
            r=DockerFake(); d=service_check.check_case(self.case,runner=r)
        self.assertEqual(d['status'],'OPENWIRE_PORT_REACHABLE_NOT_CVE_PROOF')
        self.assertFalse(d['verified_vulnerability'])
        self.assertTrue(any('--entrypoint python python:3.12-alpine' in ' '.join(x) for x in r.calls))

    def test_http_probe_explicit_container_network(self):
        r=DockerFake()
        x=service_check._http(r,'net','apache',80,'/',100000000000.0)
        self.assertEqual(x['http'],200)
        command=r.calls[0]
        self.assertIn('--path-as-is',command)
        self.assertIn('--network',command)
        self.assertNotIn('-p',command)

    def test_grafana_version_required(self):
        r=DockerFake()
        with patch.object(service_check,'_http',return_value={'http':200,'body':'{"version":"wrong"}'}):
            with self.assertRaises(TaskError) as ctx:
                service_check._profile_check(r,'net',{'web':{}},'CVE-2021-43798',100000000000.0)
        self.assertEqual(ctx.exception.code,'GRAFANA_HEALTH_MISMATCH')

    def test_unknown_cve_generic_tcp_cannot_be_cve_proof(self):
        r=DockerFake()
        with patch.object(service_check,'_image_ports',return_value=[8123]):
            x=service_check._profile_check(r,'net',{'app':{'image_ref':'example:1'}},'CVE-2024-99999',100000000000.0)
        self.assertEqual(x['status'],'GENERIC_TCP_REACHABLE_NOT_CVE_PROOF')

    def test_apache_canary_exact_marker_only_and_no_cve_pass(self):
        with patch.object(service_check.secrets,'token_hex',side_effect=lambda n:'c'*(2*n)), \
             patch.object(service_check,'_http') as request:
            marker='T3_NON_SECRET_'+'c'*48
            request.side_effect=[{'http':404,'body':'not here'},
                                 {'http':200,'body':marker},
                                 {'http':404,'body':'not here'}]
            runner=DockerFake()
            x=service_check._apache_canary(runner,'internal','apache','cid',1e12)
        self.assertEqual(x['status'],'LOCAL_CANARY_OBSERVED_NO_PATCHED_CONTROL')
        self.assertTrue(x['observed'])
        self.assertFalse(x['verified_vulnerability'])
        command=' '.join(runner.calls[0])
        self.assertIn('docker exec --user 0 cid sh -c',command)
        self.assertEqual(request.call_count,3)
        self.assertIn('.%2e',request.call_args_list[1].args[4])

    def test_canary_rejects_false_positive_normal_path(self):
        with patch.object(service_check.secrets,'token_hex',side_effect=lambda n:'c'*(2*n)), \
             patch.object(service_check,'_http') as request:
            marker='T3_NON_SECRET_'+'c'*48
            request.side_effect=[{'http':200,'body':marker},
                                 {'http':200,'body':marker},
                                 {'http':200,'body':marker}]
            x=service_check._apache_canary(DockerFake(),'internal','apache','cid',1e12)
        self.assertEqual(x['status'],'LOCAL_CANARY_NOT_OBSERVED')
        self.assertFalse(x['verified_vulnerability'])

    def test_mismatch_exported_tags_prevents_docker_actions(self):
        self.case_report['images']=['unrelated/other:v1']
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        runner=DockerFake()
        with patch.object(service_check,'sha256_file',return_value='fake-sha'):
            d=service_check.check_case(self.case,runner=runner)
        self.assertEqual(d['error_code'],'CASE_IMAGE_REFERENCES_MISMATCH')
        self.assertEqual(runner.calls,[])

    def test_verify_case_uses_evidence_image_not_user_input(self):
        self.case_report['cve']='CVE-2021-43798'
        self.case_report['services']={'web':{'image_ref':'vulhub/grafana:8.2.6'}}
        (self.case/'result.json').write_text(json.dumps(self.case_report))
        opts=cli.make_parser().parse_args(['q2','verify-case','--case',str(self.case),'--ack-lab'])
        with patch.object(cli.verify,'verify_known',return_value={'status':'BEHAVIOR_VERIFIED'}) as f:
            self.assertEqual(cli.cmd_verify_case(opts),0)
        self.assertEqual(f.call_args.args[0],'CVE-2021-43798')
        self.assertEqual(f.call_args.args[2],'vulhub/grafana:8.2.6')
        self.assertFalse(f.call_args.kwargs['allow_load'])

    def test_parser_and_required_ack(self):
        opts=cli.make_parser().parse_args(['q2','service-check','--case',str(self.case)])
        self.assertEqual(opts.budget,240)
        with self.assertRaises(TaskError) as ctx:cli.cmd_service_check(opts)
        self.assertEqual(ctx.exception.code,'LAB_ACK_REQUIRED')
        opts=cli.make_parser().parse_args(['q2','verify-case','--case',str(self.case),'--ack-lab'])
        with self.assertRaises(TaskError) as ctx:cli.cmd_verify_case(opts)
        self.assertEqual(ctx.exception.code,'ORACLE_NOT_IMPLEMENTED')

    def test_pilot_batch_saves_durable_summary(self):
        p=self.root/'pilot'
        p.mkdir()
        self.case_report['artifact']=str(self.tar)
        (p/'CVE-2021-41773').mkdir()
        for f in ['result.json','portable.compose.json']:
            (p/'CVE-2021-41773'/f).write_bytes((self.case/f).read_bytes())
        (p/'pilot_summary.json').write_text(json.dumps({'cases':[{'cve':'CVE-2021-41773'}]}))
        with patch.object(service_check,'check_case',return_value={'status':'APPLICATION_RESPONDED_NOT_CVE_PROOF'}):
            d=service_check.check_pilot(p)
        self.assertEqual(d['service_passed'],1)
        self.assertEqual(d['verified_vulnerabilities'],0)
        self.assertTrue((p/'service_summary.json').is_file())

if __name__=='__main__':unittest.main()
