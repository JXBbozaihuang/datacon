"""Batch30 v1.7 regression; zero Docker or network in this test module."""
import argparse
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from BATCH30 import (BUILD_OK, REDEPLOY_OK, classify_registry, compute_preflight,
                     default_case, digest_cves, dockerfile_bases, evidence_for_case,
                     execute_batch, init_report, inspect_recipe, reuse_candidates,
                     save_report)


class Done:
    stdout = '29.9.3'
    returncode = 0


class FakeRunner:
    def run(self, argv, **kwargs):
        return Done()


def receipt(case, cve, *, proof=False):
    case.mkdir(parents=True, exist_ok=True)
    artifact = case / (cve + '-docker-images.tar')
    artifact.write_bytes(b'x'*1024)
    (case/'result.json').write_text(json.dumps({
        'cve':cve,'status':BUILD_OK,'artifact':str(artifact),'archive_sha256':'a'*64
    }))
    (case/'redeploy_result.json').write_text(json.dumps({'status':REDEPLOY_OK}))
    if proof:
        p = case/'proof/known/known_proof.json'
        p.parent.mkdir(parents=True)
        p.write_text(json.dumps({'cve':cve,'status':'BEHAVIOR_VERIFIED',
                                 'vulnerability_verified':True}))
    return artifact


class Batch30Tests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.source=self.root/'src'; self.source.mkdir()
        self.out=self.root/'out'
        self.cves=self.root/'cves.txt'
        self.cves.write_text('CVE-2021-43798\nCVE-2021-41773\n')
        self.recipe=self.source/'x'/'CVE-2021-43798'/'docker-compose.yml'
        self.recipe.parent.mkdir(parents=True)
        self.recipe.write_text('services: {}')
        self.args=argparse.Namespace(
            cves=str(self.cves),source=str(self.source),out=str(self.out),
            runs_dir=str(self.root/'runs'),reuse_all=False,resume=False,
            retry_blocked=False,execute=False,ack_lab=False,allow_pull=False,
            max_new=30,per_cve_seconds=60,redeploy_seconds=30,
            per_image_seconds=30,total_seconds=180,service_memory='2g',
            min_disk_gb=0,registry_fail_threshold=2,
        )

    def plan_model(self, image='example/service:old', build=False):
        d={'services': {'web': {'image': image}}, 'networks': {'default': {}}}
        if build:
            d['services']['web']={'build':{'context':str(self.recipe.parent)}}
        return d

    def test_list_digest_deterministic_ordered(self):
        self.assertNotEqual(digest_cves(['CVE-1','CVE-2']),digest_cves(['CVE-2','CVE-1']))

    def test_reuse_requires_both_receipts(self):
        c=self.root/'old'/'CVE-2021-43798'; c.mkdir(parents=True)
        (c/'redeploy_result.json').write_text(json.dumps({'status':REDEPLOY_OK}))
        self.assertIsNone(evidence_for_case(c,'CVE-2021-43798'))

    def test_reuse_accepts_old_failed_summary_after_fixed_redeploy(self):
        cve='CVE-2021-43798'
        pilot=self.root/'runs/pilot-old'; case=pilot/cve
        receipt(case,cve,proof=True)
        pilot.mkdir(parents=True,exist_ok=True)
        (pilot/'pilot_summary.json').write_text(json.dumps({'cases':[{'cve':cve,'redeploy':'FAILED'}]}))
        r=reuse_candidates(self.root/'runs',[cve])
        self.assertEqual(r[cve]['status'],'REUSED_REDEPLOY_PASS')
        self.assertEqual(r[cve]['proof'],'VERIFIED_PREVIOUS_EVIDENCE')
        self.assertFalse(r[cve]['artifact_rehashed'])

    def test_reuse_rejects_artifact_outside_case(self):
        cve='CVE-2021-43798'; case=self.root/'case';case.mkdir()
        outside=self.root/'not-verified.tar';outside.write_bytes(b'x'*1024)
        (case/'result.json').write_text(json.dumps({'cve':cve,'status':BUILD_OK,'artifact':str(outside),'archive_sha256':'a'*64}))
        (case/'redeploy_result.json').write_text(json.dumps({'status':REDEPLOY_OK}))
        self.assertIsNone(evidence_for_case(case,cve))

    def test_reuse_rejects_wrong_cve_proof(self):
        cve='CVE-2021-43798';case=self.root/'case';receipt(case,cve,proof=True)
        p=case/'proof/known/known_proof.json'
        p.write_text(json.dumps({'cve':'CVE-2022-OTHER','status':'BEHAVIOR_VERIFIED','vulnerability_verified':True}))
        self.assertEqual(evidence_for_case(case,cve)['proof'],'NOT_VERIFIED')

    def test_missing_artifact_invalidates_historical_success(self):
        case=self.root/'case'; cve='CVE-2021-43798'
        receipt(case,cve).unlink()
        self.assertIsNone(evidence_for_case(case,cve))

    def test_report_outputs_and_counts(self):
        d=init_report(['CVE-2021-43798','CVE-2021-41773'],self.source,self.out)
        d['cases']['CVE-2021-43798']={'cve':'CVE-2021-43798','status':'REUSED_REDEPLOY_PASS',
            'build':BUILD_OK,'redeploy':REDEPLOY_OK,'proof':'VERIFIED_PREVIOUS_EVIDENCE','attempts':[]}
        d['cases']['CVE-2021-41773']={'cve':'CVE-2021-41773','status':'BLOCKED_REGISTRY','attempts':[]}
        save_report(self.out,d)
        self.assertEqual(d['summary']['completed_deliveries'],1)
        self.assertEqual(d['summary']['blocked_registry'],1)
        self.assertIn('CVE-2021-41773',(self.out/'blocked_cves.txt').read_text())
        self.assertIn('CVE-2021-43798',(self.out/'batch30_summary.csv').read_text())

    def test_resume_refuses_different_cve_list(self):
        init_report(['CVE-2021-43798'],self.source,self.out)
        with self.assertRaisesRegex(ValueError,'RESUME_INPUT_MISMATCH'):
            init_report(['CVE-2021-41773'],self.source,self.out,resume=True)

    def test_non_resume_refuses_overwrite(self):
        init_report(['CVE-2021-43798'],self.source,self.out)
        with self.assertRaisesRegex(ValueError,'OUTPUT_NOT_EMPTY'):
            init_report(['CVE-2021-43798'],self.source,self.out)

    def test_requires_ack_before_docker_execution(self):
        with self.assertRaisesRegex(ValueError,'LAB_ACK_REQUIRED'):
            execute_batch(self.args,runner=FakeRunner())
        self.assertFalse(self.out.exists())

    def test_preflight_missing_image_blocks_without_network(self):
        self.cves.write_text('CVE-2021-43798\n')
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value=None):
            report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'BLOCKED_REGISTRY')
        self.assertEqual(report['cases']['CVE-2021-43798']['reason'],'IMAGE_NOT_CACHED')

    def test_preflight_cached_image_ready(self):
        self.cves.write_text('CVE-2021-43798\n')
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value={'id':'sha256:x','platform':'linux/amd64'}):
            report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'READY_TO_RUN')

    def test_no_recipe_reported_not_false_pass(self):
        self.cves.write_text('CVE-2024-99999\n')
        report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['summary']['completed_deliveries'],0)
        self.assertEqual(report['cases']['CVE-2024-99999']['status'],'NO_RECIPE')

    def test_sanitizer_rejects_privileged(self):
        self.cves.write_text('CVE-2021-43798\n')
        model={'services':{'web':{'image':'a/b:old','privileged':True}}}
        with patch('BATCH30.compose.parse_compose',return_value=model):
            stage=inspect_recipe('CVE-2021-43798',self.source,runner=FakeRunner())
        self.assertEqual(stage['status'],'RECIPE_INVALID')

    def test_dockerfile_bases_multistage_and_arg(self):
        d=self.root/'build'; d.mkdir()
        (d/'Dockerfile').write_text('ARG BASE=alpine:3.18\nFROM ${BASE} AS builder\nFROM builder as intermediate\nFROM ubuntu:22.04 AS final\n')
        bases,unknown=dockerfile_bases({'context':str(d)})
        self.assertEqual(bases,['alpine:3.18','ubuntu:22.04'])
        self.assertEqual(unknown,[])

    def test_dockerfile_dynamic_base_blocked(self):
        d=self.root/'build';d.mkdir()
        (d/'Dockerfile').write_text('FROM ${UNSET}\n')
        bases,unknown=dockerfile_bases({'context':str(d)})
        self.assertEqual(bases,[])
        self.assertIn('DYNAMIC_FROM',unknown)

    def test_dockerfile_missing_is_explicit_unknown(self):
        bases,unknown=dockerfile_bases({'context':str(self.root/'none')})
        self.assertIn('DOCKERFILE_NOT_A_REGULAR_FILE',unknown)

    def test_registry_circuit_transient_only(self):
        self.assertTrue(classify_registry({'failure':'REGISTRY_AUTH_NETWORK_TRANSIENT'}))
        self.assertFalse(classify_registry({'failure':'IMAGE_NOT_FOUND_OR_ACCESS_DENIED'}))
        self.assertFalse(classify_registry({'failure':'REGISTRY_RATE_LIMIT'}))

    def test_batch_never_accepts_success_strings_without_artifact(self):
        self.cves.write_text('CVE-2021-43798\n')
        self.args.ack_lab=True
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value={'id':'sha256:x','platform':'linux/amd64'}):
            def bogus(*a,**kw):
                return {'cases':[{'cve':'CVE-2021-43798','build':BUILD_OK,'redeploy':REDEPLOY_OK}]}
            report=execute_batch(self.args,runner=FakeRunner(),pilot_runner=bogus)
        row=report['cases']['CVE-2021-43798']
        self.assertEqual(row['status'],'RUN_FAILED')
        self.assertEqual(row['reason'],'DELIVERY_RECEIPT_MISSING')
        self.assertEqual(report['summary']['completed_deliveries'],0)

    def test_actual_artifact_receipts_required_for_new_pass(self):
        self.cves.write_text('CVE-2021-43798\n')
        self.args.ack_lab=True
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value={'id':'sha256:x','platform':'linux/amd64'}):
            def actual(cves,source,out,**kw):
                receipt(Path(out)/cves[0],cves[0])
                return {'cases':[{'cve':cves[0],'build':BUILD_OK,'redeploy':REDEPLOY_OK}]}
            report=execute_batch(self.args,runner=FakeRunner(),pilot_runner=actual)
        self.assertEqual(report['summary']['completed_deliveries'],1)
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'NEW_REDEPLOY_PASS')

    def test_resume_rechecks_registry_blocks(self):
        self.cves.write_text('CVE-2021-43798\n')
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value=None):
            compute_preflight(self.args,runner=FakeRunner())
        self.args.resume=True
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value={'id':'sha256:x','platform':'linux/arm64'}):
            report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'READY_TO_RUN')

    def test_resume_keeps_previous_build_failure_without_opt_in(self):
        self.cves.write_text('CVE-2021-43798\n')
        report=init_report(['CVE-2021-43798'],self.source,self.out)
        report['cases']['CVE-2021-43798']={'cve':'CVE-2021-43798','status':'RUN_FAILED',
                                           'attempts':[{'execution':'old'}]}
        save_report(self.out,report)
        self.args.resume=True
        report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'RUN_FAILED')

    def test_thirty_case_preflight_preserves_reused_three(self):
        from track3forge.catalog import read_cves
        src = Path(__file__).resolve().parents[1] / 'examples' / 'cve30_reviewed.txt'
        if not src.is_file():
            self.skipTest('reviewed test fixture not installed')
        all_cves = read_cves(str(src))
        self.assertEqual(len(all_cves), 30)
        self.cves.write_text('\n'.join(all_cves)+'\n')
        for cve in all_cves:
            r=self.source/'x'/cve/'docker-compose.yml'
            r.parent.mkdir(parents=True,exist_ok=True)
            r.write_text('services: {}')
        runs=self.root/'runs/pilot-simulated'
        runs.mkdir(parents=True)
        (runs/'pilot_summary.json').write_text(json.dumps({'cases':[{'cve':c} for c in all_cves[:3]]}))
        for cve in all_cves[:3]:
            receipt(runs/cve,cve,proof=True)
        self.args.reuse_all=True
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value={'id':'sha256:x','platform':'linux/amd64'}):
            report=compute_preflight(self.args,runner=FakeRunner())
        self.assertEqual(report['summary']['requested'],30)
        self.assertEqual(report['summary']['reused_deliveries'],3)
        self.assertEqual(report['summary']['completed_deliveries'],3)
        self.assertEqual(len(report['cases']),30)
        self.assertEqual(report['cases'][all_cves[-1]]['status'],'READY_TO_RUN')

    def test_circuit_breaker_stops_futile_pulls_but_preserves_receipts(self):
        cves=['CVE-2021-43798','CVE-2021-41773']
        self.cves.write_text('\n'.join(cves)+'\n')
        self.args.ack_lab=True
        self.args.allow_pull=True
        calls=[]
        def phase(cve,*a,**kw):
            return {'status':'RECIPE_VALIDATED','images':[cve.lower()+':tag'],
                    'build_services':[],'build_uncertainty':[], 'recipe':'fixture'}
        def unavailable(image,*a,**kw):
            calls.append(image)
            return {'ok':False,'failure':'REGISTRY_AUTH_NETWORK_TRANSIENT','cache':None,
                    'image':image,'log':'dummy','seconds':0}
        with patch('BATCH30.inspect_recipe',side_effect=phase),\
             patch('BATCH30.docker_cached',return_value=None),\
             patch('BATCH30.try_pull',side_effect=unavailable):
            report=execute_batch(self.args,runner=FakeRunner(),pilot_runner=lambda *a,**k:self.fail('must not build'))
        self.assertEqual(len(calls),2)
        self.assertTrue(report['registry_circuit']['open'])
        self.assertEqual(report['summary']['completed_deliveries'],0)
        self.assertEqual(report['summary']['blocked_registry'],2)

    def test_no_pull_means_missing_image_never_enters_pilot(self):
        self.cves.write_text('CVE-2021-43798\n')
        self.args.ack_lab=True
        with patch('BATCH30.compose.parse_compose',return_value=self.plan_model()),\
             patch('BATCH30.docker_cached',return_value=None),\
             patch('BATCH30.try_pull') as pull:
            report=execute_batch(self.args,runner=FakeRunner(),pilot_runner=lambda *a,**k:self.fail('must not run'))
        pull.assert_not_called()
        self.assertEqual(report['cases']['CVE-2021-43798']['status'],'BLOCKED_REGISTRY')

    def test_reuse_favors_verified_evidence_over_later_unverified(self):
        cve='CVE-2021-43798'
        runs=self.root/'runs'
        for name, proven in [('pilot-old',True),('pilot-later',False)]:
            p=runs/name;p.mkdir(parents=True)
            (p/'pilot_summary.json').write_text(json.dumps({'cases':[{'cve':cve}]}))
            receipt(p/cve,cve,proof=proven)
        reused=reuse_candidates(runs,[cve])
        self.assertEqual(reused[cve]['proof'],'VERIFIED_PREVIOUS_EVIDENCE')



if __name__=='__main__':
    unittest.main()
