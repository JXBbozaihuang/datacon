#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
printf '\n====== 1/4 OFFLINE REGRESSION ======\n'
bash START.sh test
printf '\n====== 2/4 DOCKER DOCTOR ======\n'
bash START.sh doctor
printf '\n====== 3/4 EXISTING OLLAMA ======\n'
bash START.sh models --start --smoke
printf '\n====== 4/4 REAL INTERNAL NETWORK ======\n'
bash START.sh network-smoke --allow-pull
printf '\nPASSED=LOCAL_PRECHECKS_COMPLETED\nGPU=OLLAMA_AUTO TRAINING=NO\nNEXT=Use q2 discover --fetch and q2 run for the official CVE list\n'
