# 判定准则与交付证据

## 数据分层

- 结构层（Q1）：manifest、Config 文件、层路径存在且配置内容 SHA256 可校验。
- 运行层（Q1/Q2）：真实 Docker 成功运行，所有必要服务处于 Running 且 Health 正常（没有健康检查时只能声明 Running）。
- 交付层（Q2）：镜像 tar、Compose JSON、镜像身份、摘要和可复现指令完整；含 named volume/bind 的环境不声称完全可搬迁。
- 行为层（CVE 专用）：负对照、正对照与修复版本差分均来自运行中的真实产品，且目标软件版本准确。
- 官方计分层：赛方提交规则和裁判决定，**本地项目从不自动宣称官方得分**。

## 错误状态应保留

- `PROOF_FAILED`: 验证依赖、镜像、探测器或运行环境错误；不等价于不存在漏洞。
- `NOT_REPRODUCED`: 机制探测结束但未达到全部严谨条件；不等于软件绝对安全。
- `NO_RECIPE`: 可执行的复现配方未找到；模型不能凭空构造补齐并宣布成功。
- `FAILED`: 构建/数据/配置/服务健康等失败；下次重试必须保留新的运行编号。

## 已覆盖的代码机制

- CVE-2021-43798：Grafana 8.2.6 文件遍历受控随机文件，Grafana 8.2.7 修复版差分。必须通过 `--network --internal` 的容器内 HTTP sidecar，禁止宿主端口转发和代理路径改写。

**其他 CVE 无内置行为验证器。** 复用统一 `verify.py` 接口应先定义明确、可复核的 CVE 机理、可控标记、路径及反例、版本证据、适用部署限制，并单独审定后再将其列为可给出 `BEHAVIOR_VERIFIED` 的适配器。

## 模型边界

Ollama / Qwen 只在失败时可做有限分类（`check_network`、`check_image`、`check_service`、`check_compose`、`manual_review`），只输出 JSON；不允许运行模型生成的命令或写 PASS。
