# Q2 Pilot 验收说明（v1.1）

## 三题分层实测

- `CVE-2021-43798` Grafana：单 Web 服务，优先验证真实 Docker、导出、清洁重部署。
- `CVE-2021-41773` Apache HTTP Server：不同产品族，观察版本/镜像平台问题。
- `CVE-2023-46604` ActiveMQ：消息中间件，观察非 HTTP 服务就绪和镜像交付。

这三题是为工程覆盖而选，不代表稳定成功。执行前 Docker Desktop 与 Ollama 需已启动，本地没有必要训练模型。

## 数据表解释

| 字段 | 含义 |
|---|---|
| build=ENVIRONMENT_EXPORTED_NOT_CVE_PROOF | Docker 服务运行，镜像导出成功；**不是漏洞复现** |
| redeploy=CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF | 清洁 Compose 项目成功启动全部服务；**不是漏洞复现** |
| redeploy=BLOCKED_EXTERNAL_DATA_NOT_PACKAGED | 有原配方 bind / named volume 数据，交付不完整 |
| build=FAILED | 构建/启动/导出出现明确错误，查看 error_code 和 compose.log |
| verified_vulnerability=false | **本次 Pilot 不执行漏洞行为触发** |

## 从失败中恢复

- 仅查当次 `runs/pilot-*/<CVE>/result.json` 和 `compose.log`。
- 若某题拉取/构建失败，不直接改写原始 Vulhub 配方；先看 `error_code` 和日志，再决定最小修复。
- 新批次使用新输出目录；禁止把不同运行的证据覆盖在同一个目录。
- 不使用 `docker system prune -a --volumes` 一键清理，以免删除与比赛无关的资源。

## 现实限制

此工程没有在本容器里访问你的 Mac Docker Desktop；本地 68 项测试全部离线或模拟执行。只有 Mac 真机的 `pilot_summary.json` 才能确认实际候选导出率和重新部署率。正式比赛提交成功率需按主办方实际验收统计。
