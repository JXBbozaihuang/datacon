# 工程验收记录 · v1.0（2026-11-23）

## 已在生成容器内实际完成

- 纯 Python 单元测试 + 显式 FakeDocker 集成回归（均无网络、无 Docker 实机）。
- Compose 解析/安全变换单元测试：禁特权/host 网络/外部 bind、全服务健康、端口移除。
- Docker save 缺层修复及不可信供体拒绝：合成归档（不是真实复杂损坏镜像）。
- Q2 构建/镜像导出/服务失败：模拟 Docker 命令完整执行路径，检查状态与结果。
- HTTP 容器内部网络探测：命令形式与严谨状态机模拟测试。
- CLI 解析、CVE 清单、静态 dashboard、重部署入口的静态/测试覆盖。

## 当前无法在生成容器内完成

- Docker Desktop 29.9.3 实机运行；容器内部网络 HTTP 验证真实请求；Grafana 8.2.6 vs 8.2.7 的真实差分。
- 通过 Mac Ollama 已安装 Qwen 的真实模型推理。
- 真正未知 CVE 的跨产品自主构建成功率（需要赛前真实样本和 Docker 实测）。
- 官方提交与评分（赛方接口未给出）。

在 Mac 上执行以下顺序，不要跳过失败步骤：

```bash
bash START.sh test
bash START.sh doctor
bash START.sh models --start --smoke
bash START.sh network-smoke --allow-pull
bash START.sh q2 discover --cves CVE-2021-43798 --fetch
bash START.sh q2 run --cves CVE-2021-43798 --source data/vulhub --ack-lab --per-cve-seconds 600
# 查 OUTPUT，再执行 q2 redeploy 和 q2 verify
```

不应以本地模型描述或部署日志替代独立验证输出。
