"""Audited, explicit proof dispatch. Unknown CVEs MUST remain unverified.

A generative model cannot register new exploit-like probes or claim a proof result.
Only reviewed Python verifier implementations in this registry may set the
independent BEHAVIOR_VERIFIED bit. Parser-level signals are separately counted.
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Oracle:
    cve: str
    entrypoint: str
    evidence_relative: str
    claim: str  # full_behavior | parser_only
    required_controls: tuple[str, ...]

REGISTRY = {
    'CVE-2021-43798': Oracle('CVE-2021-43798', 'grafana', 'proof/known/known_proof.json', 'full_behavior',
                             ('vulnerable', 'fixed', 'negative', 'artifact_identity')),
    'CVE-2021-41773': Oracle('CVE-2021-41773', 'apache', 'proof/apache/apache_proof.json', 'full_behavior',
                             ('vulnerable', 'fixed', 'negative', 'matched_config')),
    'CVE-2021-42013': Oracle('CVE-2021-42013', 'apache', 'proof/apache42013/apache_proof.json', 'full_behavior',
                             ('vulnerable', 'fixed', 'negative', 'matched_config')),
    'CVE-2023-46604': Oracle('CVE-2023-46604', 'activemq', 'proof/activemq/activemq_proof.json', 'full_behavior',
                             ('vulnerable', 'fixed', 'callback_control', 'artifact_identity')),
    'CVE-2014-6271': Oracle('CVE-2014-6271', 'bash', 'proof/bash/bash_proof.json', 'parser_only',
                             ('vulnerable', 'fixed', 'negative', 'artifact_identity')),
}

def lookup(cve: str) -> Oracle | None:
    return REGISTRY.get(cve)


def acceptable_verdict(oracle: Oracle, result: dict) -> bool:
    """Validation stricter than an arbitrary 'verified': required inputs evidenced."""
    if result.get('cve') != oracle.cve or result.get('vulnerability_verified') is not True:
        return False
    if oracle.claim == 'parser_only':
        return result.get('status') == 'PARSER_BEHAVIOR_VERIFIED' and bool(result.get('vulnerable_trial')) and bool(result.get('fixed_trial'))
    return (result.get('status') == 'BEHAVIOR_VERIFIED' and
            isinstance(result.get('vulnerable_trial'), dict) and
            isinstance(result.get('fixed_trial'), dict) and
            bool(result.get('checks')))
