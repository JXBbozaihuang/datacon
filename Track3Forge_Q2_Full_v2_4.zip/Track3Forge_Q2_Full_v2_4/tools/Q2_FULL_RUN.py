#!/usr/bin/env python3
"""Unified Q2 runner: vetted environment delivery, LLM planning, behavior proof.

This entrypoint runs the existing Docker pipeline without changing its safety
or acceptance contracts. It continues to evidence checks even if fewer than
requested environments were delivered. All outcomes are separately counted.
"""
from __future__ import annotations
import argparse
import json
import os
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.Q2_SKILL_GATE import read_cves, audit


def stream(command: list[str], log: Path, *, timeout: int) -> int:
    log.parent.mkdir(parents=True, exist_ok=True)
    print('COMMAND='+ ' '.join(command[:3]) + ' ...', flush=True)
    started = time.monotonic()
    with log.open('w', encoding='utf-8') as handle:
        proc = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, universal_newlines=True,
                                bufsize=1, start_new_session=True,
                                env={**os.environ, 'PYTHONUNBUFFERED':'1', 'PYTHONDONTWRITEBYTECODE':'1'})
        def pump():
            try:
                for line in proc.stdout:
                    print(line, end='', flush=True)
                    handle.write(line)
                    handle.flush()
            finally:
                proc.stdout.close()
        reader = threading.Thread(target=pump, daemon=True)
        reader.start()
        try:
            return proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try: os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError: pass
            try: proc.wait(timeout=6)
            except subprocess.TimeoutExpired:
                try: os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                proc.wait()
            print('STAGE_TIMEOUT=YES ELAPSED='+str(round(time.monotonic()-started,1)),flush=True)
            return 124
        finally:
            reader.join(timeout=2)


def run_pipeline(args) -> int:
    cves = read_cves(Path(args.list))
    if not 1 <= args.minimum_delivery <= len(cves):
        raise ValueError('MINIMUM_DELIVERY_OUT_OF_RANGE')
    if not 0 <= args.minimum_behavior <= len(cves):
        raise ValueError('MINIMUM_BEHAVIOR_OUT_OF_RANGE')
    if not args.plan_only and not args.ack_lab and not args.skip_build:
        raise ValueError('LAB_ACK_REQUIRED')
    output = ROOT / 'output'
    output.mkdir(exist_ok=True)
    logdir = output / 'logs'
    logdir.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    base = ['--list', str(Path(args.list).expanduser().resolve()),
            '--source', str(Path(args.source).expanduser().resolve()),
            '--minimum', str(args.minimum_delivery),
            '--per-image-seconds', str(args.per_image_seconds),
            '--per-cve-seconds', str(args.per_cve_seconds),
            '--redeploy-seconds', str(args.redeploy_seconds),
            '--total-seconds', str(args.total_seconds),
            '--max-new', str(args.max_new),
            '--registry-fail-threshold', str(args.registry_fail_threshold)]
    if args.fetch: base.append('--fetch')
    if args.allow_pull: base.append('--allow-pull')
    if args.ack_lab: base.append('--ack-lab')
    if args.agent: base += ['--agent','--model',args.model]
    if args.agent and args.start_ollama: base.append('--start-ollama')
    if args.plan_only: base.append('--plan-only')

    print('========== Q2 FULL 30-CVE PIPELINE ==========',flush=True)
    print('GPU=OLLAMA_AUTO_OR_NO TRAINING=NO',flush=True)
    print('REQUESTED='+str(len(cves))+' MIN_DELIVERY='+str(args.minimum_delivery)+
          ' MIN_FULL_BEHAVIOR='+str(args.minimum_behavior),flush=True)
    print('SOURCE='+str(args.source),flush=True)
    print('TOTAL_BUDGET_SECONDS='+str(args.total_seconds),flush=True)

    if not args.skip_tests:
        print('========== PHASE 0/4: REGRESSION ==========',flush=True)
        rc = stream([sys.executable,'-m','unittest','discover','-s','tests','-q'],
                    logdir / ('regression-'+stamp+'.log'),timeout=180)
        if rc:
            print('UNIT_TESTS=FAIL CODE='+str(rc)+' FINISHED=YES',flush=True)
            return 3
        print('UNIT_TESTS=PASS',flush=True)

    engine_rc = None
    if not args.skip_build:
        print('========== PHASE 1/4: REAL DOCKER DELIVERY ==========',flush=True)
        cmd = ['bash', str(ROOT/'RUN_Q2.sh')] + base
        engine_rc = stream(cmd, logdir / ('engine-'+stamp+'.log'),
                           timeout=args.total_seconds+240)
        print('ENGINE_EXIT_CODE='+str(engine_rc),flush=True)
        if args.plan_only:
            print('PLAN_ONLY=YES FINISHED=YES',flush=True)
            return engine_rc
    else:
        print('ENGINE_SKIPPED=YES (using already existing output/summary.json)',flush=True)
        if args.plan_only:
            return 0

    print('========== PHASE 2/4: AGENT EVIDENCE PLAN ==========',flush=True)
    agent_rc = stream([sys.executable,'-u',str(ROOT/'tools'/'CVE_AGENT_PLANNER.py'),
                       '--list',str(Path(args.list).resolve()),
                       '--main',str(output/'main'),
                       '--out',str(output/'agent_plans'),
                       '--cache',str(ROOT/'data'/'cve_metadata'),
                       '--model',args.model,'--agent-max',str(args.agent_max)]
                      + (['--metadata-online'] if args.metadata_online else [])
                      + (['--agent'] if args.agent_plan else [])
                      + (['--start-ollama'] if args.agent_plan and args.start_ollama else []),
                      logdir / ('agent-'+stamp+'.log'),timeout= max(120, 30*16 + args.agent_max*70))
    print('AGENT_PLAN_EXIT_CODE='+str(agent_rc),flush=True)

    print('========== PHASE 3/4: AUDITED BEHAVIOR ==========',flush=True)
    proof_report = output / 'behavior_batch.json'
    if args.skip_behavior or not args.ack_lab:
        print('BEHAVIOR_EXECUTION=SKIPPED',flush=True)
        proof_rc = None
        proof = {'requested':len(cves),'processed':0,'cases':[], 'full_behavior_verified_this_run':0,
                 'parser_only_verified_this_run':0}
    else:
        cmd = [sys.executable,'-u',str(ROOT/'tools'/'BEHAVIOR_BATCH.py'),
               '--list',str(Path(args.list).resolve()),
               '--main',str(output/'main'), '--out',str(proof_report),
               '--budget',str(args.proof_budget),'--ack-lab']
        if args.allow_pull: cmd.append('--allow-pull')
        proof_rc = stream(cmd, logdir / ('proof-'+stamp+'.log'),
                          timeout= len(cves)*(args.proof_budget+25)+60)
        proof = _load_json(proof_report)
    print('BEHAVIOR_STAGE_EXIT_CODE='+str(proof_rc),flush=True)

    print('========== PHASE 4/4: FINAL EVIDENCE GATE ==========',flush=True)
    delivery = {'delivery_verified':0,'cases':[], 'delivery_gate':'NOT_CHECKED'}
    error = None
    try:
        delivery = audit(Path(args.list), output/'summary.json', output/'main',
                         minimum_delivery=args.minimum_delivery)
    except (ValueError, OSError) as exc:
        error = str(exc)[:300]
        print('DELIVERY_AUDIT_ERROR='+error,flush=True)
    full = int(proof.get('full_behavior_verified_this_run',0)) if proof_rc == 0 else 0
    parser = int(proof.get('parser_only_verified_this_run',0)) if proof_rc == 0 else 0
    ready = delivery['delivery_verified']
    delivery_pass = ready >= args.minimum_delivery and error is None and (engine_rc in (None,0,2))
    behavior_pass = full >= args.minimum_behavior and proof_rc in (None,0)
    gate = 'PASS' if delivery_pass and behavior_pass else 'BELOW_TARGET'
    if engine_rc not in (None,0,2):
        gate = 'PIPELINE_ABORTED'
    if args.minimum_behavior == 0:
        scope = 'DELIVERY_ONLY_BEHAVIOR_REPORTED_SEPARATELY'
    else:
        scope = 'DELIVERY_AND_BEHAVIOR_REQUIRED'
    final = {
        'schema':'track3forge-full-q2-v2.4', 'requested':len(cves),
        'delivery_verified':ready, 'minimum_delivery':args.minimum_delivery,
        'full_behavior_verified_this_run':full,
        'parser_only_verified_this_run':parser,
        'minimum_behavior':args.minimum_behavior,
        'delivery_gate':delivery.get('delivery_gate'),
        'overall_gate':gate, 'overall_gate_scope':scope,
        'engine_exit_code':engine_rc, 'agent_plan_exit_code':agent_rc,
        'behavior_stage_exit_code':proof_rc,
        'official_acceptance':'UNKNOWN',
        'delivery_audit_error':error, 'delivery_cases':delivery.get('cases',[]),
        'proof_cases':proof.get('cases',[]),
        'output_main':str(output/'main'),
        'generated_at':datetime.now(timezone.utc).isoformat(),
    }
    (output/'final_report.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('REQUESTED='+str(len(cves)),flush=True)
    print('DELIVERY_VERIFIED='+str(ready),flush=True)
    print('FULL_BEHAVIOR_VERIFIED_THIS_RUN='+str(full),flush=True)
    print('PARSER_ONLY_VERIFIED_THIS_RUN='+str(parser),flush=True)
    print('MINIMUM_DELIVERY='+str(args.minimum_delivery),flush=True)
    print('MINIMUM_BEHAVIOR='+str(args.minimum_behavior),flush=True)
    print('OVERALL_GATE='+gate,flush=True)
    print('OVERALL_GATE_SCOPE='+scope,flush=True)
    print('OFFICIAL_ACCEPTANCE=UNKNOWN',flush=True)
    print('MAIN='+str(output/'main'),flush=True)
    print('REPORT='+str(output/'final_report.json'),flush=True)
    print('FINISHED=YES',flush=True)
    return 3 if gate == 'PIPELINE_ABORTED' else (0 if gate == 'PASS' else 2)


def _load_json(path: Path) -> dict:
    try:
        val=json.loads(path.read_text(encoding='utf-8'))
        return val if isinstance(val,dict) else {}
    except (OSError,ValueError):
        return {}


def build_parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list',default='examples/cve30_reviewed.txt')
    p.add_argument('--source',default='data/vulhub')
    p.add_argument('--minimum-delivery',type=int,default=10)
    p.add_argument('--minimum-behavior',type=int,default=0)
    p.add_argument('--ack-lab',action='store_true')
    p.add_argument('--fetch',action='store_true')
    p.add_argument('--allow-pull',action='store_true')
    p.add_argument('--agent',action='store_true',help='Existing bounded failure diagnosis')
    p.add_argument('--agent-plan',action='store_true',help='Use local Qwen for unknown-CVE evidence plans')
    p.add_argument('--metadata-online',action='store_true',help='Fetch public CVE metadata from CVE Services')
    p.add_argument('--agent-max',type=int,default=6)
    p.add_argument('--start-ollama',action='store_true')
    p.add_argument('--model',default='qwen2.5:3b')
    p.add_argument('--plan-only',action='store_true')
    p.add_argument('--skip-tests',action='store_true')
    p.add_argument('--skip-build',action='store_true')
    p.add_argument('--skip-behavior',action='store_true')
    p.add_argument('--total-seconds',type=int,default=10800)
    p.add_argument('--per-image-seconds',type=int,default=180)
    p.add_argument('--per-cve-seconds',type=int,default=420)
    p.add_argument('--redeploy-seconds',type=int,default=180)
    p.add_argument('--registry-fail-threshold',type=int,default=3)
    p.add_argument('--max-new',type=int,default=30)
    p.add_argument('--proof-budget',type=int,default=360)
    return p


def main(argv=None) -> int:
    args=build_parser().parse_args(argv)
    if args.proof_budget < 90 or args.proof_budget > 1800:
        print('ERROR=INVALID_PROOF_BUDGET FINISHED=YES');return 3
    if not Path(args.list).exists():
        # Relative paths are interpreted against repository root, independent
        # of the user's current terminal working directory.
        a=ROOT/args.list
        if a.is_file(): args.list=str(a)
    if not Path(args.source).is_dir():
        p=ROOT/args.source
        args.source=str(p)
    try:
        return run_pipeline(args)
    except (ValueError,OSError) as e:
        print('ERROR='+str(e)[:500]+' FINISHED=YES',flush=True)
        return 3
    except KeyboardInterrupt:
        print('INTERRUPTED=YES FINISHED=YES',flush=True)
        return 130

if __name__ == '__main__':
    raise SystemExit(main())
