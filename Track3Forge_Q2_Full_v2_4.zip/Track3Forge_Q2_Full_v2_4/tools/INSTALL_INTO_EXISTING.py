#!/usr/bin/env python3
"""Non-destructive v2.4 overlay for the current Track3Forge Q2 Team checkout.

The existing output, runs, data, Docker images, local proof evidence and .git
history remain untouched. Source changes are backed up, tested, and rolled back
if offline regression fails.
"""
from __future__ import annotations
import argparse
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
FILES = (
    'ONE_RUN_Q2_30.sh',
    'README_CN.md', 'CHANGELOG_V24.md',
    'docs/TEAM_Q2_V24.md',
    'scripts/skill_pilot5.sh',
    'docs/SKILL_PILOT5.md',
    'examples/skill_pilot5.txt',
    'tools/Q2_SKILL_GATE.py',
    'tools/VERIFY_PILOT3.py',
    'tools/Q2_FULL_RUN.py',
    'tools/CVE_AGENT_PLANNER.py',
    'tools/BEHAVIOR_BATCH.py',
    'track3forge/apache_proof.py',
    'track3forge/bash_proof.py',
    'track3forge/verification_registry.py',
    'tests/test_q2_skill_v22.py',
    'tests/test_proof_extension_v23.py',
    'tests/test_q2_full_v24.py',
)


def install(target: Path) -> int:
    dest = target.expanduser().resolve()
    if not dest.is_dir() or not (dest / 'RUN_Q2.sh').is_file() or not (dest/'tools'/'Q2_COMPETE.py').is_file():
        print('ERROR=NOT_TRACK3FORGE_TEAM_PROJECT FINISHED=YES')
        return 3
    if dest == SRC:
        print('ERROR=TARGET_IS_INSTALLER_SOURCE FINISHED=YES')
        return 3
    skill_files = tuple(str(p.relative_to(SRC)) for p in sorted((SRC/'.agents'/'skills').rglob('*.md')))
    relpaths = tuple(sorted(set(FILES + skill_files + ('AGENTS.md', 'pyproject.toml'))))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = dest / '.backup' / ('q2-v24-' + stamp + '-' + str(os.getpid()))
    backup.mkdir(parents=True,exist_ok=False)
    changed = []
    previous = {}
    try:
        for rel in relpaths:
            src = SRC / rel
            out = dest / rel
            if not src.is_file():
                raise FileNotFoundError(str(src))
            if out.is_symlink() or any((dest/Path(*Path(rel).parts[:i])).is_symlink()
                                       for i in range(1,len(Path(rel).parts))):
                raise ValueError('SYMLINK_IN_DESTINATION: '+rel)
            existed = out.exists()
            if existed and not out.is_file():
                raise ValueError('NOT_FILE_IN_DESTINATION: '+rel)
            previous[rel] = existed
            if existed:
                old = backup / rel
                old.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(out,old)
            out.parent.mkdir(parents=True,exist_ok=True)
            if rel == 'AGENTS.md' and existed:
                text = out.read_text(encoding='utf-8')
                marker = '## Q2 v2.4 Skill registry'
                if marker not in text:
                    incoming = src.read_text(encoding='utf-8')
                    addon = incoming[incoming.index(marker):]
                    out.write_text(text.rstrip()+'\n\n'+addon,encoding='utf-8')
            elif rel == 'pyproject.toml' and existed:
                text = out.read_text(encoding='utf-8')
                import re
                text = re.sub(r'(?m)^version = "[^"]+"', 'version = "2.4.0"',text,count=1)
                out.write_text(text, encoding='utf-8')
            else:
                shutil.copy2(src,out)
            changed.append(rel)
        p = subprocess.run(['bash','scripts/check.sh'],cwd=dest,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True,timeout=120,check=False)
        print('\n'.join(p.stdout.splitlines()[-12:]),flush=True)
        if p.returncode != 0:
            raise RuntimeError('REGRESSION_FAILED exit='+str(p.returncode))
        print('PATCH_APPLIED=YES',flush=True)
        print('BACKUP='+str(backup),flush=True)
        print('OUTPUT_PRESERVED=YES RUNS_PRESERVED=YES DATA_PRESERVED=YES',flush=True)
        print('DOCKER_MUTATIONS=NO GPU=NO TRAINING=NO FINISHED=YES',flush=True)
        return 0
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired) as exc:
        for rel in reversed(changed):
            out = dest / rel
            try:
                if previous[rel]:
                    shutil.copy2(backup/rel,out)
                else:
                    out.unlink(missing_ok=True)
            except OSError as restore_error:
                print('ROLLBACK_FILE_FAILED='+rel+' '+str(restore_error)[:120],flush=True)
        print('ERROR='+type(exc).__name__+': '+str(exc)[:350],flush=True)
        print('PATCH_APPLIED=NO ROLLBACK_ATTEMPTED=YES BACKUP='+str(backup),flush=True)
        print('DOCKER_MUTATIONS=NO GPU=NO TRAINING=NO FINISHED=YES',flush=True)
        return 3


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('project',type=Path)
    a=p.parse_args(argv)
    return install(a.project)

if __name__=='__main__':
    raise SystemExit(main())
