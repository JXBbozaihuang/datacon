#!/usr/bin/env python3
"""Evidence-bound five-case Track3Forge Q2 delivery auditor.

This tool is read-only unless --out is supplied. It never executes CVE probes.
It reports DELIVERY_VERIFIED separately from historical behavior-proof records.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from tools.artifact_audit import verify_file_manifest

CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}")
READY = {"MAIN_READY", "MAIN_ALREADY_VALID"}
REQUIRED = {
    "docker-images.tar", "docker-compose.yml", "submission.json",
    "validation.json", "packaged_runtime.json", "result.json",
    "redeploy_result.json", "portable.compose.json",
}


def read_json(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 16_000_000:
        raise ValueError(f"MISSING_OR_UNSAFE_JSON: {path}")
    result = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(result, dict):
        raise ValueError(f"EXPECTED_JSON_OBJECT: {path}")
    return result


def read_cves(path: Path) -> list[str]:
    if path.is_symlink() or not path.is_file():
        raise ValueError("CVE_LIST_MISSING_OR_SYMLINK")
    names = [line.strip().upper() for line in path.read_text(encoding="utf-8").splitlines()
             if line.strip() and not line.lstrip().startswith("#")]
    if not names or len(names) > 1000 or len(set(names)) != len(names):
        raise ValueError("CVE_LIST_EMPTY_OR_DUPLICATE")
    if any(not CVE_RE.fullmatch(cve) for cve in names):
        raise ValueError("BAD_CVE_IDENTIFIER")
    return names


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(2 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def below(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=True).relative_to(root.resolve(strict=True))
        return True
    except (OSError, ValueError):
        return False


def assess_case(cve: str, row: dict, main: Path) -> dict:
    result = {"cve": cve, "delivery": "FAIL", "behavior_proof_recorded": False,
              "reason": "UNKNOWN"}
    if row.get("status") not in READY:
        result["reason"] = "NOT_DELIVERED: " + str(row.get("reason", row.get("status", "UNKNOWN")))[:120]
        return result
    folder = main / cve
    if folder.is_symlink() or not folder.is_dir() or not below(folder, main):
        result["reason"] = "MAIN_DIRECTORY_MISSING_OR_UNSAFE"
        return result
    for name in REQUIRED | {"manifest.json"}:
        file = folder / name
        if file.is_symlink() or not file.is_file() or not below(file, folder):
            result["reason"] = "REQUIRED_FILE_MISSING: " + name
            return result
    try:
        manifest = folder / "manifest.json"
        checks = verify_file_manifest(manifest)
        if not checks or any(x["status"] != "PASS" for x in checks):
            result["reason"] = "MANIFEST_INTEGRITY_FAILED"
            return result
        paths = {entry["path"] for entry in checks if entry["status"] == "PASS"}
        if not REQUIRED.issubset(paths):
            result["reason"] = "MANIFEST_DOES_NOT_COVER_REQUIRED_FILES"
            return result
        sub = read_json(folder / "submission.json")
        validation = read_json(folder / "validation.json")
        runtime = read_json(folder / "packaged_runtime.json")
        if sub.get("cve") != cve or validation.get("cve") != cve:
            result["reason"] = "WRONG_CVE_IDENTITY"
            return result
        if sub.get("artifact") != "docker-images.tar" or sub.get("compose") != "docker-compose.yml":
            result["reason"] = "SUBMISSION_CONTRACT_MISMATCH"
            return result
        if (runtime.get("status") != "PASS" or runtime.get("cleaned_up") is not True
                or validation.get("packaged_runtime") != "PASS"):
            result["reason"] = "PACKAGED_RUNTIME_NOT_PROVEN"
            return result
        if validation.get("status") != "DELIVERY_ARCHIVE_AND_CLEAN_REDEPLOY_VERIFIED":
            result["reason"] = "DELIVERY_STATUS_MISMATCH"
            return result
        if validation.get("archive_content_integrity", {}).get("status") != "PASS":
            result["reason"] = "OCI_CONTENT_NOT_VERIFIED"
            return result
        if validation.get("docker_compose_parser") != "PASS":
            result["reason"] = "COMPOSE_NOT_VERIFIED"
            return result
        digest = sha256(folder / "docker-images.tar")
        if (sub.get("artifact_sha256") != digest
                or validation.get("source_archive_sha256") != digest):
            result["reason"] = "IMAGE_ARCHIVE_SHA256_MISMATCH"
            return result
        if sub.get("official_accepted") is not None or validation.get("official_accepted") is not None:
            result["reason"] = "UNSUPPORTED_OFFICIAL_ACCEPTANCE_CLAIM"
            return result
    except (OSError, ValueError, TypeError, json.JSONDecodeError, KeyError) as exc:
        result["reason"] = "INVALID_EVIDENCE: " + type(exc).__name__
        return result
    result["delivery"] = "PASS"
    result["reason"] = "DELIVERY_ARCHIVE_AND_CLEAN_REDEPLOY_VERIFIED"
    proof_dir = folder / "proof"
    if proof_dir.is_dir() and not proof_dir.is_symlink() and below(proof_dir, folder):
        for proof in sorted(proof_dir.rglob("*.json")):
            try:
                if not below(proof, proof_dir) or proof.is_symlink():
                    continue
                evidence = read_json(proof)
                if (evidence.get("cve") == cve and evidence.get("status") == "BEHAVIOR_VERIFIED"
                        and evidence.get("vulnerability_verified") is True):
                    result["behavior_proof_recorded"] = True
                    break
            except (ValueError, OSError, json.JSONDecodeError):
                continue
    return result


def audit(cve_list: Path, summary: Path, main: Path, minimum_delivery: int = 5) -> dict:
    cves = read_cves(cve_list)
    if minimum_delivery < 1 or minimum_delivery > len(cves):
        raise ValueError("MINIMUM_DELIVERY_OUT_OF_RANGE")
    doc = read_json(summary)
    rows = doc.get("cases")
    if not isinstance(rows, list) or doc.get("requested") != len(cves):
        raise ValueError("SUMMARY_COUNT_OR_CASES_INVALID")
    seen = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("SUMMARY_ROW_INVALID")
        key = row.get("cve")
        if key in seen or key not in cves:
            raise ValueError("SUMMARY_DUPLICATE_OR_UNEXPECTED_CVE")
        seen[key] = row
    if set(seen) != set(cves):
        raise ValueError("SUMMARY_CVE_LIST_MISMATCH")
    results = [assess_case(cve, seen[cve], main) for cve in cves]
    delivered = sum(x["delivery"] == "PASS" for x in results)
    historical_proofs = sum(x["behavior_proof_recorded"] for x in results)
    return {
        "schema": "track3forge-q2-skill-report-v2.2",
        "requested": len(cves), "delivery_verified": delivered,
        "minimum_delivery": minimum_delivery,
        "delivery_gate": "PASS" if delivered >= minimum_delivery else "BELOW_TARGET",
        "behavior_proof_recorded_historical": historical_proofs,
        "behavior_verified_this_run": 0,
        "official_accepted": None,
        "cases": results,
    }


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--list", type=Path, required=True)
    p.add_argument("--summary", type=Path, required=True)
    p.add_argument("--main", type=Path, required=True)
    p.add_argument("--minimum-delivery", type=int, default=5)
    p.add_argument("--out", type=Path)
    args = p.parse_args(argv)
    print("GPU=NO TRAINING=NO DOCKER=NO NETWORK=NO", flush=True)
    try:
        doc = audit(args.list, args.summary, args.main, args.minimum_delivery)
        for i, row in enumerate(doc["cases"], 1):
            print(f'CHECKING={i}/{doc["requested"]} {row["cve"]} '
                  f'DELIVERY={row["delivery"]} REASON={row["reason"]}', flush=True)
        print("========== Q2 SKILL VERIFICATION ==========")
        print("REQUESTED=" + str(doc["requested"]))
        print("DELIVERY_VERIFIED=" + str(doc["delivery_verified"]))
        print("DELIVERY_TARGET=" + str(doc["minimum_delivery"]))
        print("DELIVERY_GATE=" + doc["delivery_gate"])
        print("BEHAVIOR_PROOF_RECORDED_HISTORICAL=" + str(doc["behavior_proof_recorded_historical"]))
        print("BEHAVIOR_VERIFIED_THIS_RUN=0")
        print("OFFICIAL_ACCEPTED=UNKNOWN")
        if args.out:
            args.out.parent.mkdir(parents=True, exist_ok=True)
            args.out.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print("REPORT=" + str(args.out))
        print("INPUT_FILES_MODIFIED=NO FINISHED=YES")
        return 0 if doc["delivery_gate"] == "PASS" else 2
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as e:
        print("AUDIT_ERROR=" + str(e)[:400])
        print("FINISHED=YES")
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
