#!/usr/bin/env python3
"""Batch audited local verifiers, with hard per-case deadlines and honest states.

Only vetted CVE-specific validators may assert full behavior. Unknown cases get
ORACLE_MISSING, not a model-based success. No host ports or arbitrary commands.
"""
from __future__ import annotations
import argparse
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from track3forge.verification_registry import lookup, acceptable_verdict
from tools.Q2_SKILL_GATE import read_cves


def read_json(path):
    try:
        obj = json.loads(Path(path).read_text(encoding='utf-8'))
        return obj if isinstance(obj, dict) else {}
    except (OSError, ValueError):
        return {}


def _run_one(cve, case: Path, allow_pull: bool, budget: int) -> dict:
    from track3forge.verification_registry import lookup
    oracle = lookup(cve)
    if oracle is None:
        return {'cve': cve, 'status': 'ORACLE_MISSING', 'vulnerability_verified': False}
    if not case.is_dir():
        return {'cve': cve, 'status': 'CASE_MISSING', 'vulnerability_verified': False}
    if oracle.entrypoint == 'grafana':
        from track3forge import verify
        from track3forge.core import TaskError
        src = read_json(case / 'result.json')
        services = list((src.get('services') or {}).values())
        images = sorted({r.get('image_ref') for r in services if isinstance(r, dict) and r.get('image_ref')})
        if len(images) != 1:
            raise TaskError('UNEXPECTED_IMAGE_COUNT', repr(images))
        return verify.verify_known(cve, Path(src['artifact']), images[0],
                                   case / 'proof' / 'known', allow_pull=allow_pull)
    if oracle.entrypoint == 'apache':
        from track3forge.apache_proof import verify_apache_case
        return verify_apache_case(case, cve=cve, allow_pull=allow_pull, budget=budget)
    if oracle.entrypoint == 'activemq':
        from track3forge.activemq_proof import verify_activemq_case
        return verify_activemq_case(case, allow_pull=allow_pull, budget=budget)
    if oracle.entrypoint == 'bash':
        from track3forge.bash_proof import verify_bash_case
        return verify_bash_case(case, allow_pull=allow_pull, budget=budget)
    raise ValueError('UNREGISTERED_ORACLE_TYPE')


def one_cli(args) -> int:
    result = {'cve': args.cve, 'status': 'PROOF_FAILED', 'vulnerability_verified': False}
    try:
        if not args.ack_lab:
            raise ValueError('LAB_ACK_REQUIRED')
        result = _run_one(args.cve, Path(args.case), args.allow_pull, args.budget)
    except Exception as exc:
        result['error_code'] = type(exc).__name__
        result['error'] = str(exc)[:300]
    print('ONE_PROOF_JSON='+json.dumps(result, ensure_ascii=False), flush=True)
    # exit 2 for insufficient proof; parent must not treat nonzero as crash
    return 0 if result.get('vulnerability_verified') is True else 2


def execute_one(cve: str, main: Path, *, budget: int, allow_pull: bool,
                ack_lab: bool, logs: Path) -> dict:
    oracle = lookup(cve)
    record = {'cve': cve, 'oracle': None if oracle is None else oracle.entrypoint,
              'claim_level': None if oracle is None else oracle.claim,
              'status': 'NOT_TESTED', 'vulnerability_verified': False,
              'full_behavior_verified_this_run': False, 'parser_only_verified_this_run': False}
    case = main / cve
    if not case.is_dir() or case.is_symlink() or (case/'proof').is_symlink():
        record['status'] = 'NOT_DELIVERED'; return record
    if oracle is None:
        record['status'] = 'ORACLE_MISSING'; return record
    if not ack_lab:
        record['status'] = 'LAB_ACK_REQUIRED'; return record
    # The child process isolates each proof's execution budget. Do not execute
    # arbitrary commands from Agent advice or an unreviewed recipe.
    cmd = [sys.executable, '-u', str(Path(__file__).resolve()), '--verify-one',
           '--cve', cve, '--case', str(case), '--budget', str(budget), '--ack-lab']
    if allow_pull:
        cmd.append('--allow-pull')
    logs.mkdir(parents=True, exist_ok=True)
    log = logs / f'{cve}.log'
    start = time.time()
    with log.open('w', encoding='utf-8') as handle:
        proc = subprocess.Popen(cmd, stdout=handle, stderr=subprocess.STDOUT,
                                cwd=ROOT, start_new_session=True,
                                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        try:
            code = proc.wait(timeout=budget + 15)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait()
            code = 124
    record.update({'elapsed_seconds': round(time.time() - start, 2),
                   'exit_code': code, 'log': str(log)})
    if code == 124:
        record['status'] = 'TIMEOUT'
        record['error_code'] = 'PROOF_BUDGET_EXCEEDED'
        return record
    # Trust a freshly written, identity-matching proof, NEVER a stale file from
    # a previous run. A failing child cannot turn an old proof into new success.
    evidence_path = case / oracle.evidence_relative
    record['evidence_path'] = str(evidence_path)
    doc = read_json(evidence_path)
    fresh = (evidence_path.is_file() and not evidence_path.is_symlink()
             and evidence_path.resolve().is_relative_to(case.resolve())
             and evidence_path.stat().st_mtime >= start)
    record['status'] = doc.get('status', 'PROOF_FAILED') if fresh else 'PROOF_MISSING_THIS_RUN'
    if not fresh:
        record['error_code'] = 'NO_FRESH_EVIDENCE'
    elif doc.get('cve') != cve:
        record['status'] = 'PROOF_IDENTITY_MISMATCH'
        record['error_code'] = 'WRONG_CVE'
    elif code != 0 and not acceptable_verdict(oracle, doc):
        record['error_code'] = doc.get('error_code', 'PROOF_NOT_VERIFIED')
    valid = fresh and acceptable_verdict(oracle, doc) and code == 0
    record['vulnerability_verified'] = bool(valid)
    record['full_behavior_verified_this_run'] = bool(valid and oracle.claim == 'full_behavior')
    record['parser_only_verified_this_run'] = bool(valid and oracle.claim == 'parser_only')
    # Never publish raw canary or arbitrary proof bodies in a batch report.
    return record


def batch(args) -> int:
    cves = read_cves(Path(args.list))
    main = Path(args.main).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    logs = out.parent / 'proof_logs'
    if args.budget < 90 or args.budget > 1800:
        raise ValueError('BUDGET_RANGE_90_TO_1800')
    rows = []
    for idx, cve in enumerate(cves, 1):
        print(f'PROOF_CHECKING={idx}/{len(cves)} {cve}', flush=True)
        row = execute_one(cve, main, budget=args.budget,
                          allow_pull=args.allow_pull, ack_lab=args.ack_lab, logs=logs)
        rows.append(row)
        print(f"PROOF_RESULT {cve} STATUS={row['status']} FULL_VERIFIED={row['full_behavior_verified_this_run']} PARSER_ONLY={row['parser_only_verified_this_run']}", flush=True)
        # Save partial report after every case; interrupted work can be audited.
        write_report(out, cves, rows)
    full = sum(x['full_behavior_verified_this_run'] for x in rows)
    parser = sum(x['parser_only_verified_this_run'] for x in rows)
    print('========== BEHAVIOR BATCH FINAL ==========', flush=True)
    print('REQUESTED='+str(len(cves)), flush=True)
    print('FULL_BEHAVIOR_VERIFIED_THIS_RUN='+str(full), flush=True)
    print('PARSER_ONLY_VERIFIED_THIS_RUN='+str(parser), flush=True)
    print('ORACLE_MISSING='+str(sum(x['status']=='ORACLE_MISSING' for x in rows)), flush=True)
    print('REPORT='+str(out), flush=True)
    print('OFFICIAL_ACCEPTANCE=UNKNOWN FINISHED=YES', flush=True)
    return 0  # Completes audit even when no proof is possible; score separately.


def write_report(out: Path, cves: list, rows: list) -> None:
    obj = {'schema': 'track3forge-behavior-batch-v2.4',
           'requested': len(cves), 'processed': len(rows),
           'full_behavior_verified_this_run': sum(x['full_behavior_verified_this_run'] for x in rows),
           'parser_only_verified_this_run': sum(x['parser_only_verified_this_run'] for x in rows),
           'official_accepted': None, 'cases': rows,
           'generated_at': datetime.now(timezone.utc).isoformat()}
    out.parent.mkdir(parents=True, exist_ok=True)
    temp = out.with_suffix('.tmp')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temp.replace(out)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list')
    p.add_argument('--main', default=str(ROOT / 'output' / 'main'))
    p.add_argument('--out', default=str(ROOT / 'output' / 'behavior_batch.json'))
    p.add_argument('--budget', type=int, default=360)
    p.add_argument('--allow-pull', action='store_true')
    p.add_argument('--ack-lab', action='store_true')
    p.add_argument('--verify-one', action='store_true', help=argparse.SUPPRESS)
    p.add_argument('--cve', help=argparse.SUPPRESS)
    p.add_argument('--case', help=argparse.SUPPRESS)
    args = p.parse_args(argv)
    if args.verify_one:
        return one_cli(args)
    if not args.list:
        p.error('--list is required')
    try:
        return batch(args)
    except (OSError, ValueError) as e:
        print('BEHAVIOR_BATCH_ERROR='+str(e)[:300]+' FINISHED=YES', flush=True)
        return 3

if __name__ == '__main__':
    raise SystemExit(main())
