#!/usr/bin/env python3
"""Run audited, container-local proof checks for the three remaining pilot cases."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from track3forge.apache_proof import verify_apache_case
from track3forge.bash_proof import verify_bash_case

CANDIDATES = ('CVE-2021-42013','CVE-2014-6271','CVE-2018-8715')


def check_appweb(case):
    source = case / 'result.json'
    if not source.is_file():
        return {'cve':'CVE-2018-8715', 'status':'CASE_MISSING',
                'vulnerability_verified':False, 'reason':'result.json missing'}
    try:
        obj = json.loads(source.read_text(encoding='utf-8'))
    except (ValueError, OSError):
        return {'cve':'CVE-2018-8715','status':'CASE_INVALID',
                'vulnerability_verified':False, 'reason':'result.json unreadable'}
    images = obj.get('images') or []
    return {
        'cve':'CVE-2018-8715',
        'status':'AUTH_ORACLE_NOT_IMPLEMENTED',
        'vulnerability_verified':False,
        'image_refs':images,
        'reason':'Must configure a protected resource, valid credential, and patched-control comparison before auth-bypass proof',
    }


def main(argv=None):
    p = argparse.ArgumentParser(description='Isolated lab proof pilot for 3 CVEs')
    p.add_argument('--main', default=str(ROOT/'output'/'main'))
    p.add_argument('--budget', type=int, default=360)
    p.add_argument('--allow-pull', action='store_true')
    p.add_argument('--ack-lab', action='store_true')
    a = p.parse_args(argv)
    if not a.ack_lab:
        print('ERROR=LAB_ACK_REQUIRED FINISHED=YES'); return 3
    base = Path(a.main).expanduser().resolve()
    if not base.is_dir():
        print('ERROR=MAIN_DIRECTORY_MISSING PATH='+str(base)+' FINISHED=YES');return 3
    rows = []
    for i,cve in enumerate(CANDIDATES,1):
        print(f'CHECKING={i}/3 {cve}',flush=True)
        case = base / cve
        try:
            if not case.is_dir():
                row = {'cve':cve,'status':'CASE_MISSING','vulnerability_verified':False}
            elif cve == 'CVE-2021-42013':
                row = verify_apache_case(case, allow_pull=a.allow_pull, budget=a.budget, cve=cve)
            elif cve == 'CVE-2014-6271':
                row = verify_bash_case(case, allow_pull=a.allow_pull, budget=a.budget)
            else:
                row = check_appweb(case)
        except Exception as e:
            row = {'cve':cve,'status':'PROOF_FAILED','vulnerability_verified':False,
                   'error_code':'UNEXPECTED_VERIFIER_ERROR','error':str(e)[:400]}
        rows.append(row)
        print(f"RESULT {cve} STATUS={row.get('status')} VERIFIED={row.get('vulnerability_verified')} ERROR={row.get('error_code','-')}",flush=True)
    apache = int(any(x['cve']=='CVE-2021-42013' and x.get('status')=='BEHAVIOR_VERIFIED' and x.get('vulnerability_verified') is True for x in rows))
    parser = int(any(x['cve']=='CVE-2014-6271' and x.get('status')=='PARSER_BEHAVIOR_VERIFIED' and x.get('vulnerability_verified') is True for x in rows))
    summary = {
        'requested':3,
        'apache_differential_behavior_verified':apache,
        'bash_parser_behavior_verified':parser,
        'appweb_auth_bypass_verified':0,
        'full_behavior_verified_in_this_run':apache,
        'environment_delivery_is_not_behavior_proof':True,
        'official_acceptance':None,
        'results':rows,
    }
    out = base.parent / 'proof_extension_v23_summary.json'
    out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('\n========== PROOF PILOT3 FINAL ==========')
    for k in ('requested','apache_differential_behavior_verified','bash_parser_behavior_verified','appweb_auth_bypass_verified','full_behavior_verified_in_this_run'):
        print(k.upper()+'='+str(summary[k]))
    print('REPORT='+str(out))
    print('GPU=NO TRAINING=NO FINISHED=YES')
    return 0 if apache and parser else 2

if __name__=='__main__':sys.exit(main())
