# v2.3：三份试点环境的证据分层

命令：`python3 -u tools/VERIFY_PILOT3.py --ack-lab --allow-pull`。
仅验证 `output/main/` 中已交付的容器环境；不接受公网目标地址。

- **CVE-2021-42013**：在 Docker `--internal` 网络内对照 Apache 2.4.50 与 2.4.51，两者使用从实际交付镜像提取的相同配置；随机标记文件只写入被测容器的 `/tmp`。仅当 2.4.50 能读取，而 2.4.51 不能读取，且原始镜像摘要、版本、配置和负对照都正确时，状态才为 `BEHAVIOR_VERIFIED`。
- **CVE-2014-6271**：完全禁网的容器中对比 Bash 环境变量解析，无害随机打印标记作为独立证据。结果为 `PARSER_BEHAVIOR_VERIFIED`，只证明 Bash 解析器根因行为，**不等于 Web CGI 攻击路径已经通过**。
- **CVE-2018-8715**：在缺乏受保护路由、凭据与修复版 Appweb 对照之前返回 `AUTH_ORACLE_NOT_IMPLEMENTED`，严禁宣称认证绕过已验证。

执行器只使用内置的静态本地测试请求和命令；不执行 LLM 生成命令。验证 JSON 保存在对应 `output/main/<CVE>/proof/` 下；汇总单独写入 `output/proof_extension_v23_summary.json`。Docker 镜像及实验输出不提交 Git。
