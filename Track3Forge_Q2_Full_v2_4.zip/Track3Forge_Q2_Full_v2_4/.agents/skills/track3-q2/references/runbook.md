# 五题端到端操作手册

## 1. 环境要求

Python 3.10+、Docker Engine 和 Compose v2、Git；Mac 建议使用 `caffeinate -i` 保持终端运行。可选 Ollama `qwen2.5:3b` 用于失败诊断，无训练、无需 GPU。

## 2. 五题基线

详见 `examples/skill_pilot5.txt`，选择的五个 CVE 过去曾进入 `output/main`，作为优先环境交付样本。由于磁盘状态、镜像拉取、系统版本和源代码均可变化，它们不是本次已成功样本。

## 3. 先测试与计划

```bash
bash scripts/check.sh
bash scripts/skill_pilot5.sh plan
```

如本地 `data/vulhub` 不存在，可显式设置 `TRACK3_ALLOW_FETCH=YES`，从现有 `catalog.fetch_snapshot` 接口获取配方。它可能失败；不应偷偷改用未审计源。

## 4. 一次跑五题

```bash
TRACK3_ACK_LAB=YES TRACK3_ALLOW_PULL=YES TRACK3_ALLOW_FETCH=YES \
  caffeinate -i bash scripts/skill_pilot5.sh run
```

脚本在当前终端实时显示进度，结束时打印汇总，退出码 0=交付目标成功，2=未达交付门槛，3=内部中断或配置错误。

## 5. 查看交付

```bash
python3 tools/Q2_SKILL_GATE.py --list examples/skill_pilot5.txt \
  --summary output/summary.json --main output/main --minimum-delivery 5
ls -lah output/main
```

如果 `DELIVERY_VERIFIED=5`，表示五份交付包通过本地严格核查；**仍非五个 CVE 行为复现已经证实**。

## 6. 进阶行为验证

现有仓库含针对 Grafana CVE-2021-43798、Apache CVE-2021-41773、ActiveMQ CVE-2023-46604 的独立验证器；支持范围有限，且必须由用户明确允许在隔离 Docker 实验环境中运行。新增其它 CVE 的验证器要经过单独审定、对照和回归测试，不能写一个通用 HTTP 200 就宣布存在漏洞。

## 7. 团队协作

Git 只提交代码、文档、测试和清单。`output/`、`runs/`、`data/`、Docker 归档与凭据不提交。每个 PR 需说明离线测试和 Docker 实测是哪个层级。
