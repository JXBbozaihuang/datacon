# 验收状态机与证据链

1. `NO_RECIPE`：不存在适用的可信构建配方；不得虚构镜像。
2. `READY_TO_RUN`：配方与基础镜像具备，但尚未执行；不能计分。
3. `ENVIRONMENT_EXPORTED_NOT_CVE_PROOF`：已导出镜像，仅证实工件生成。
4. `CLEAN_REDEPLOY_SERVICES_HEALTHY_NOT_CVE_PROOF`：从交付镜像重新部署，服务基本运行。
5. `MAIN_READY` / `MAIN_ALREADY_VALID`：本地交付门禁成功，manifest、Compose、真实 Docker 镜像和重部署通过。
6. `BEHAVIOR_VERIFIED`：只允许独立 CVE 专用 oracle 根据正负控制和版本差分给出。旧证据只称历史记录，不当作“本次重新验证”。
7. `OFFICIAL_ACCEPTED`：只有赛事官方接口或回执可声明；否则 `UNKNOWN`。

## 重要边界

- `packaged_runtime.json.status` 必须为 `PASS`；`validation.json.packaged_runtime` 必须为 `PASS`。
- `submission.json.cve` 与目录 CVE 完全一致；镜像归档的 SHA256 与 `submission.json.artifact_sha256`、`validation.json.source_archive_sha256` 对得上。
- `manifest.json` 的所有条目存在、大小与摘要完全一致，禁止符号链接和路径逃逸。
- `BEHAVIOR_VERIFIED` 只有独立证明材料可计数；不符合审查条件的 `proof.json` 不算。
- `ERROR`、`NOT_REPRODUCED`、`PROOF_FAILED` 不推断为漏洞不存在，也不能计为成功。

> 以上是内部交付技术标准，不能代替赛事官方评分标准。
