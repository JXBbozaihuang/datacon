---
name: track3-q2
description: Use this skill to run a user-supplied CVE list through the authorized, isolated Track3Forge Q2 pipeline with independent delivery and behavior-evidence reporting.
---

# Track3Forge Q2 — Team Orchestration Skill v2.4

**Goal:** take a CVE text list, deliver authentic portable Docker environments into `output/main/<CVE>/`, then evaluate known behavior only with reviewed, bounded laboratory oracles. Do not equate an archive, a running service, a guessed vulnerable version, and a demonstrated vulnerability.

## Trigger / scope
- CVE lists supplied by the user and an explicitly authorized local test lab.
- Existing checked local Vulhub recipes and official supplier containers.
- Unknown CVEs are supported in intake and structured research planning; no success claim without a vetted verifier and observed evidence.
- The Skill is **procedural guidance**. `ONE_RUN_Q2_30.sh` is the executable entrypoint; loading SKILL.md alone starts nothing.

## Runtime contract
Inputs: `TRACK3_CVE_LIST`, trusted `TRACK3_SOURCE`, `TRACK3_MIN_DELIVERY`, optionally `TRACK3_MIN_BEHAVIOR`, per-stage budgets, and `TRACK3_ACK_LAB=YES`.
Optional local LLM: `qwen2.5:3b` via Ollama (`TRACK3_AGENT=YES`, `TRACK3_AGENT_PLAN=YES`); no training or hosted API requirement. CVE metadata network fetch is **off by default** (`TRACK3_METADATA_ONLINE=YES` enables only official CVE metadata lookup).
Outputs: `output/main/<CVE>/`, `output/rejected`, `output/summary.json`, `output/agent_plans/<CVE>.json`, `output/behavior_batch.json`, `output/final_report.json`. Git ignores output artifacts.

## State machine
1. **INTAKE** → validate strictly formatted, unique CVE IDs; sources and authority. Follow `cve-intake`.
2. **RECIPE & PLATFORM** → find authentic Docker/Compose recipe; check exact product and version; record `NO_RECIPE` if none. Follow `recipe-sourcing`.
3. **SCHEDULE & BUILD** → cached images first, `BATCH30.py` timeouts + resumable receipts; per-case isolation. Follow `container-delivery`.
4. **REDEPLOY & AUDIT** → verify digest, OCI content and Compose, clean redeploy and packaged runtime; only then mark `MAIN_READY`. Follow `submission-gate`.
5. **AGENT EVIDENCE PLANNING** → read CVE metadata if available; Qwen emits only classification and evidence requirements from allowlists. No shell commands, self-written exploit or PASS result. Follow `unknown-cve-planning`.
6. **AUDITED BEHAVIOR** → `BEHAVIOR_BATCH.py` dispatches only explicit `verification_registry.py` oracles; always compare observed evidence, target version and patched-control when implemented. Follow `behavior-verification`.
7. **REPORT** → emit independent delivery, parser-only, full-behavior and official-acceptance columns; never conflate them.

## Single full run (Mac)
```bash
cd "$HOME/Downloads/Track3Forge_Q2_Full_v2_4"
TRACK3_CVE_LIST=examples/cve30_reviewed.txt TRACK3_MIN_DELIVERY=10 \
  bash ONE_RUN_Q2_30.sh
```
Equivalent explicit CLI:
```bash
python3 -u tools/Q2_FULL_RUN.py --list examples/cve30_reviewed.txt \
  --source data/vulhub --fetch --allow-pull --ack-lab --agent \
  --agent-plan --start-ollama --minimum-delivery 10 --proof-budget 360
```
Run tests before full batch: `bash scripts/check.sh`. Reports always end; never use `tail -f`.

## Success standards
- `DELIVERY_VERIFIED` counts audited, complete, cleanly redeployable Docker submissions.
- `FULL_BEHAVIOR_VERIFIED_THIS_RUN` counts actual observed vetted differential oracles this run.
- `PARSER_ONLY_VERIFIED_THIS_RUN` is a separate, weaker finding, not full CVE proof.
- `OFFICIAL_ACCEPTANCE=UNKNOWN` until a competition verdict is available.
- `DELIVERY_GATE=PASS` **does not** make the behavior count pass. Use `--minimum-behavior N` for combined gate if required.

## Safety / provenance / bounded execution
No public target scanning, exposed host ports, arbitrary LLM-generated commands, fake targets, invented evidence or unreviewed proof registration. Do not change target version just to get a PASS. Unknown CVEs remain `ORACLE_MISSING` until a human-reviewed controlled oracle exists. Always preserve raw receipts, record failure codes and keep submitted content traceable.

## Failure recovery
Do not repeat the same registry error indefinitely. Preflight storage, platform and Docker; retry only transient failures within budgets. On errors, preserve `output/main` successes and mark incomplete cases `NOT_DELIVERED`. LLM advice may suggest a check, but deterministic code alone selects commands and computes verdicts.

References: `references/acceptance.md`, `references/runbook.md`, `references/proof-extension-v23.md`, `docs/TEAM_Q2_V24.md`.
