---
name: container-delivery
description: Use to build, test, export, and independently redeploy approved lab Docker environments.
---

# Container Delivery Skill

Tools: `RUN_Q2.sh`, `BATCH30.py`, `track3forge/pilot.py`, `track3forge/platform_export.py`. The user must opt into local-lab container execution with `--ack-lab`; pulls require `--allow-pull` and have deadlines. No public host ports, privileged execution, untrusted host mounts or repeated blind retry. Docker commands derive from reviewed Python functions, not model text.

Priority: cached-image runnable recipes → images requiring pull within budget → no-recipe cases (report, do not fake). Preserve receipt files and original versions. Export OCI archive, verify identity, restart a *fresh Compose project* from the packaged files without pull or rebuild; check service health. A successful container `RUNNING` state alone is insufficient.

Only transfer audited successes into `output/main/<CVE>` via `SUBMISSION_GATE.py`. On incomplete results preserve raw logs, mark non-delivery; do not delete earlier successful output. Distinguish portability and ARM64/AMD64 constraints. Default target is 10/30 delivery, configurable.
