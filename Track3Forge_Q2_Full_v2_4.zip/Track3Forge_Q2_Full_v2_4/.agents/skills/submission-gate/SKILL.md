---
name: submission-gate
description: Use when evaluating whether a candidate may appear in output/main or when producing an honest final result.
---

# Submission and Evidence Gate Skill

Original gate `tools/SUBMISSION_GATE.py` validates recipe and exported archive from build receipts, checks full archive SHA256 and OCI digest references, checks Compose layout and source bindings, and validates a fresh packaged runtime. `tools/Q2_SKILL_GATE.py` performs a separate read-only audit of `output/main/<CVE>` and its manifest. Reject missing/damaged archives, path escapes, symlink tricks, false receipt status, or unsafe Compose options.

The final runner stores `output/final_report.json` with independent fields: `delivery_verified`, `full_behavior_verified_this_run`, `parser_only_verified_this_run`, `official_acceptance`, `delivery_gate`, `overall_gate` and error evidence. `official_acceptance` stays `UNKNOWN` without a true competition verdict. The batch runner may exit 2 for below target while successful individual artifacts remain valid.

Do not equate metadata 30/30, 245 unit tests, or delivery 5/5 with behavior 5/5. Never retroactively count older proof files as verification in the current run. Keep a permanent distinction between produced / running / portable / behavior / accepted.
