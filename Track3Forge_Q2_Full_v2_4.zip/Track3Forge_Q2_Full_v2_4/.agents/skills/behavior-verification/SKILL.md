---
name: behavior-verification
description: Use when an exported lab case may have an existing reviewed CVE-specific verification routine.
---

# Differential Behavior Verification Skill

Dispatch from `track3forge/verification_registry.py`; audited code in `track3forge/verify.py`, `apache_proof.py`, `activemq_proof.py`, `bash_proof.py`. Bound each run with a hard child-process timeout and isolated single-use lab networking; never reach public IPs or expose host ports.

A full local behavior verdict requires (a) exact target image identity and vulnerable version, (b) positive condition on real target, (c) negative condition/benign baseline, (d) equivalent fixed version control showing absence of behavior, (e) resulting fresh evidence JSON from the current run, (f) verified cleanup. `BEHAVIOR_VERIFIED` only if all required conditions hold. Do not fabricate an oracle for an unknown CVE. The Bash root-cause parser check is parser-level only, not full HTTP CGI exploit-chain proof, and is counted separately.

Known registered: Grafana 2021-43798; Apache 2021-41773 / 2021-42013; ActiveMQ 2023-46604; Bash parser-only 2014-6271. Appweb 2018-8715 is intentionally `ORACLE_MISSING`. Unknown CVE: generate an Agent evidence plan, do not run arbitrary model-authored probes.

Run `python3 -u tools/BEHAVIOR_BATCH.py --list examples/cve30_reviewed.txt --ack-lab --allow-pull`. Stored evidence in `output/main/<CVE>/proof/...`, independent batch result in `output/behavior_batch.json`.
