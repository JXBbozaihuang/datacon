---
name: recipe-sourcing
description: Use when locating an authentic container/Compose environment for a target CVE in local trusted sources.
---

# Recipe Sourcing Skill

Check `data/vulhub` or explicit `--source` and record provenance. Never substitute a similar service, patched version, or mock application. Parse Compose and base images, note hardcoded host binds, platform requirements and external dependencies; reject unsafe privileged mode or unexpected external mounts. Existing core modules: `track3forge/catalog.py`, `track3forge/compose.py`, `track3forge/mechanism.py`.

First check local cache; if the recipe is missing, `NO_RECIPE`; `--fetch` may acquire a trusted source snapshot when authorized. Classify `IMAGE_NOT_CACHED`, `PLATFORM_UNAVAILABLE`, `CONTENT_DIGEST_NOT_FOUND` distinctly. Neither the model nor the Skill may invent a recipe or secretly alter versions.

Output: source/identity hints and the build-ready status. Before proceeding, require a real product identity, Compose parsing, safety isolation and a bounded runtime plan.
