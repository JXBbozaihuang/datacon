#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
TARGET="${1:-$HOME/Downloads/Track3Forge_Q2_Team}"
exec python3 -u "$ROOT/tools/INSTALL_INTO_EXISTING.py" "$TARGET"
