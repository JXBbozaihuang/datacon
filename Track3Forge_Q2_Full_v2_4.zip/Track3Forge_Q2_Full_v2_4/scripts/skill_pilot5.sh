#!/usr/bin/env bash
# Skill v2.2 pilot: prefer known 5 delivery candidates, do not fake CVE proof.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
cd "$ROOT"
MODE="${1:-plan}"
SOURCE="${TRACK3_SKILL_SOURCE:-$ROOT/data/vulhub}"
LIST="$ROOT/examples/skill_pilot5.txt"

printf 'GPU=OLLAMA_AUTO_OR_NO TRAINING=NO MODEL=%s\n' "${TRACK3_SKILL_MODEL:-qwen2.5:3b}"
printf 'REQUESTED=5 DELIVERY_TARGET=5\n'
printf 'SOURCE=%s\n' "$SOURCE"

if [[ ! -f "$LIST" ]]; then
  echo "ERROR=FIVE_CASE_LIST_MISSING FINISHED=YES" >&2; exit 3
fi

ARGS=(--list "$LIST" --source "$SOURCE" --minimum 5
      --max-new 5 --per-image-seconds 180 --per-cve-seconds 420
      --redeploy-seconds 180 --total-seconds "${TRACK3_SKILL_TOTAL_SECONDS:-3600}")
[[ "${TRACK3_ALLOW_FETCH:-NO}" == YES ]] && ARGS+=(--fetch)

case "$MODE" in
  plan)
    echo 'DOCKER=NO MODE=PLAN'
    bash RUN_Q2.sh "${ARGS[@]}" --plan-only
    exit $?
    ;;
  run)
    if [[ "${TRACK3_ACK_LAB:-NO}" != YES ]]; then
      echo 'ERROR=ACK_LAB_REQUIRED: TRACK3_ACK_LAB=YES FINISHED=YES' >&2
      exit 3
    fi
    echo 'DOCKER=YES MODE=REAL_DELIVERY'
    ARGS+=(--ack-lab)
    [[ "${TRACK3_ALLOW_PULL:-NO}" == YES ]] && ARGS+=(--allow-pull)
    if [[ "${TRACK3_SKILL_AGENT:-NO}" == YES ]]; then
      ARGS+=(--agent --start-ollama --model "${TRACK3_SKILL_MODEL:-qwen2.5:3b}")
    fi
    set +e
    bash RUN_Q2.sh "${ARGS[@]}"
    ENGINE_RC=$?
    python3 -u tools/Q2_SKILL_GATE.py \
      --list "$LIST" --summary "$ROOT/output/summary.json" \
      --main "$ROOT/output/main" --minimum-delivery 5 \
      --out "$ROOT/output/skill_pilot5_report.json"
    AUDIT_RC=$?
    set -e
    echo "ENGINE_EXIT_CODE=$ENGINE_RC"
    echo "AUDIT_EXIT_CODE=$AUDIT_RC"
    echo "OUTPUT=$ROOT/output/main"
    echo "FINISHED=YES"
    if (( ENGINE_RC == 3 || ENGINE_RC == 124 )); then exit 3; fi
    if (( ENGINE_RC != 0 || AUDIT_RC != 0 )); then exit 2; fi
    exit 0
    ;;
  *)
    echo "USAGE: bash scripts/skill_pilot5.sh [plan|run]" >&2; exit 3
    ;;
esac
