# Track3Forge Q2 v2.2 — Agent Skill 五题交付试点

此补充包可以添加到现有 `Track3Forge_Q2_Team` Git 仓库，**不覆盖** `Q2_COMPETE.py`、`BATCH30.py`、`SUBMISSION_GATE.py` 等核心运行器。目的：把“Agent 规范 + 固定工具链 + 严格验收 + 5题试点”固化为可协作流程。

## 安装

```bash
cd "$HOME/Downloads"
unzip -oq Track3Forge_Q2_Skill_v2_2.zip
bash Track3Forge_Q2_Skill_v2_2/APPLY.sh "$HOME/Downloads/Track3Forge_Q2_Team"
cd "$HOME/Downloads/Track3Forge_Q2_Team"
```

安装会先备份同名文件和 `AGENTS.md`，完成单元测试，失败则回滚。没有下载本 ZIP 的话，仅粘贴命令不会凭空出现该文件。

## 试点清单

- CVE-2021-43798
- CVE-2021-41773
- CVE-2021-42013
- CVE-2018-8715
- CVE-2014-6271

这五个来自过去出现过 `MAIN_READY` 的已知候选，用于测试 **五份真实 Docker 环境交付**，不是已证明五种漏洞行为。项目内部已审定的独立行为验证器尚不足以覆盖这五项。

## 实际运行（实时终端输出，自动结束）

```bash
# 快速检查（可用本地配方；若缺失则显式允许获取）
TRACK3_ALLOW_FETCH=YES bash scripts/skill_pilot5.sh plan

# 授权隔离环境中跑五题，保持 Mac 唤醒
TRACK3_ACK_LAB=YES TRACK3_ALLOW_FETCH=YES TRACK3_ALLOW_PULL=YES \
  caffeinate -i bash scripts/skill_pilot5.sh run
```

计划模式不会创建 CVE 容器；可能访问网络获取可信配方。运行模式执行已有引擎，在 `output/main` 生成经过本地交付门禁的产物，最多总预算默认 3600 秒，不是预计耗时。

## 预期输出

```text
REQUESTED=5
DELIVERY_VERIFIED=N
DELIVERY_TARGET=5
DELIVERY_GATE=PASS / BELOW_TARGET
BEHAVIOR_PROOF_RECORDED_HISTORICAL=M
BEHAVIOR_VERIFIED_THIS_RUN=0
OFFICIAL_ACCEPTED=UNKNOWN
REPORT=.../output/skill_pilot5_report.json
FINISHED=YES
```

`DELIVERY_VERIFIED=5` 只说明本地交付门禁和实物复核通过。想要 **5 个独立漏洞行为验证**，还需要对应的真实 CVE 验证器、修复版负对照与本轮运行证据；本版不会伪造或自动填充。

## Git 团队协作

```bash
git switch -c feat/q2-agent-skill
git add AGENTS.md .agents/skills/track3-q2 scripts/skill_pilot5.sh \
  tools/Q2_SKILL_GATE.py tests/test_q2_skill_v22.py \
  examples/skill_pilot5.txt docs/SKILL_PILOT5.md
git commit -m "feat: evidence-first Q2 skill and five-case pilot"
git push -u origin feat/q2-agent-skill
```

`output/`、`data/`、`runs/` 继续被 `.gitignore` 忽略，避免将大镜像和日志上传到公开仓库。
