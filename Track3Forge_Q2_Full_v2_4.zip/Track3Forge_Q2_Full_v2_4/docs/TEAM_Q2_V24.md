# v2.4 团队分工及设计要点

- **平台组**：`BATCH30.py`、`Q2_COMPETE.py`；减少仓库等待与重复构建，保存结构化错误码。
- **Agent组**：`llm.py`、`CVE_AGENT_PLANNER.py`、`.agents/skills/unknown-cve-planning/`；只输出受限结构化证据计划、模型可用状态和成本；测量未知样本覆盖率，禁止自我评分。
- **验证组**：`verification_registry.py` + 专用 proof 模块；新增审定验证器必须有独立正负对照、版本与配置校验、运行超时及可复现报告，并提供异常/伪阳性单元测试。
- **交付组**：`SUBMISSION_GATE.py`、`Q2_SKILL_GATE.py`、`artifact_audit.py`；仅将真实运行且可打包重部署的产物放入 `output/main`，负责提交规范核对。

## 建议 PR 准入标准

1. 保留 Python 3.10+ 和 macOS `/private/var` 别名路径兼容。
2. `bash scripts/check.sh` 全部通过；检查没有 Docker 副作用的单元测试。
3. 新功能不得把 `MAIN_READY` 视为 `BEHAVIOR_VERIFIED`。
4. 新增行为验证必须是经过审核的受控本地验证器，并有修复版差分，不接受模型自述。
5. 代码中所有运行时下载、Docker 启动都必须有授权、预算和隔离。
6. 确认 `.gitignore` 不泄露本地证据、日志、模型或密钥；不要提交镜像归档。

## 下一阶段真正的难点

未知 CVE 的原理、真实漏洞触发条件及可信修复版对照不能凭一段描述自动确认。优先完善**真实环境的来源证明**与**独立证据机制**，避免在未知样本上盲目宣称通过。优先衡量首次交付时间、交付成功数、已审定行为证据数和误报率，分别报告。
