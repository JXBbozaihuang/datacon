import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from track3forge import apache_proof as a
from track3forge import bash_proof as b

class Result:
    def __init__(self,stdout='',stderr='',returncode=0):
        self.stdout=stdout
        self.stderr=stderr
        self.returncode=returncode

class Fake:
    def __init__(self):self.calls=[]
    def run(self,cmd,**kwargs):
        self.calls.append(list(cmd))
        if len(cmd)>=2 and cmd[-1]=='--version':return Result(stdout='GNU bash, version 4.3.0(1)-release')
        if '--entrypoint' in cmd and '-c' in cmd:
            text='T3_BASH_NORMAL\n'
            if 'vulnerable' in cmd:text='T3_SHELLSHOCK_CANARY_test\n'+text
            return Result(stdout=text)
        return Result()

class Tests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.case=Path(self.t.name)
        self.tar=self.case/'artifact.tar'
        self.tar.write_bytes(b'fake')
        self.obj={'cve':'CVE-2021-42013','status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
                  'images':['apache:local'],'artifact':str(self.tar),
                  'archive_sha256':hashlib.sha256(b'fake').hexdigest()}
        self.write()
    def write(self):
        (self.case/'result.json').write_text(json.dumps(self.obj))
    def test_apache_wrong_cve_failclosed(self):
        self.obj['cve']='CVE-2021-41773';self.write()
        d=a.verify_apache_case(self.case,cve='CVE-2021-42013')
        self.assertEqual(d['error_code'],'WRONG_CVE')
        self.assertFalse(d['vulnerability_verified'])
    def test_apache_42013_full_differential(self):
        positive={'health_version':'2.4.50','positive_exact':True,'negative_exact':False}
        negative={'health_version':'2.4.51','positive_exact':False,'negative_exact':False}
        with patch.object(a,'assert_archive_tag',return_value={'status':'ARCHIVE_TAG_CONFIG_MATCHED'}),\
             patch.object(a,'_image_available'),\
             patch.object(a,'_extract_config',return_value={'httpd_conf_sha256':'xx','autoindex_conf_sha256':'yy'}),\
             patch.object(a,'_build_fixed',return_value={'config_test':'PASSED'}),\
             patch.object(a,'_confirm_control_config',return_value='CRITICAL_CONFIG_BYTES_MATCHED'),\
             patch.object(a,'_trial',side_effect=[positive,negative]) as mocked:
            d=a.verify_apache_case(self.case,runner=Fake(),cve='CVE-2021-42013')
        self.assertEqual(d['status'],'BEHAVIOR_VERIFIED')
        self.assertTrue(d['vulnerability_verified'])
        self.assertEqual(mocked.call_args_list[0].kwargs['attack_segment'],'.%%32%65')
        self.assertTrue((self.case/'proof/apache42013/apache_proof.json').is_file())
    def test_apache_42013_patched_still_matches_rejected(self):
        good={'health_version':'2.4.50','positive_exact':True,'negative_exact':False}
        bad={'health_version':'2.4.51','positive_exact':True,'negative_exact':False}
        with patch.object(a,'assert_archive_tag',return_value={}),\
             patch.object(a,'_image_available'),patch.object(a,'_extract_config',return_value={}),\
             patch.object(a,'_build_fixed',return_value={}),patch.object(a,'_confirm_control_config',return_value='MATCHED'),\
             patch.object(a,'_trial',side_effect=[good,bad]):
            d=a.verify_apache_case(self.case,runner=Fake(),cve='CVE-2021-42013')
        self.assertFalse(d['vulnerability_verified'])
    def test_bash_wrong_cve_rejected(self):
        d=b.verify_bash_case(self.case,runner=Fake())
        self.assertEqual(d['error_code'],'WRONG_CVE')
    def test_bash_diff_only_local_parser(self):
        self.obj['cve']='CVE-2014-6271';self.obj['images']=['vulnerable'];self.write()
        runner=Fake()
        def trial(r,image,marker,deadline):
            if image=='vulnerable':
                return {'version':'4.3','marker_observed':True,'normal_path_observed':True}
            return {'version':'5.2','marker_observed':False,'normal_path_observed':True}
        with patch.object(b,'assert_archive_tag',return_value={}),patch.object(b,'_trial',side_effect=trial):
            d=b.verify_bash_case(self.case,runner=runner)
        self.assertTrue(d['vulnerability_verified'])
        self.assertFalse(d['web_cgi_vector_verified'])
        self.assertEqual(d['status'],'PARSER_BEHAVIOR_VERIFIED')
    def test_bash_bad_control_not_verified(self):
        self.obj['cve']='CVE-2014-6271';self.obj['images']=['vulnerable'];self.write()
        def trial(r,image,marker,deadline):
            return {'version':'4.3' if image=='vulnerable' else '5.2',
                    'marker_observed':True,'normal_path_observed':True}
        with patch.object(b,'assert_archive_tag',return_value={}),patch.object(b,'_trial',side_effect=trial):
            d=b.verify_bash_case(self.case,runner=Fake())
        self.assertFalse(d['vulnerability_verified'])
    def test_bash_no_host_network(self):
        class R:
            def __init__(self):self.calls=[]
            def run(self,cmd,**kw):
                self.calls.append(cmd)
                if cmd[-1]=='--version':return Result(stdout='GNU bash, version 4.3.0(1)-release')
                return Result(stdout='T3_BASH_NORMAL')
        r=R();d=b._trial(r,'localimage','CANARY_TEST',1e12)
        self.assertFalse(d['marker_observed'])
        self.assertTrue(all('--network' in c and c[c.index('--network')+1]=='none' for c in r.calls))
        self.assertFalse(any('-p' in c or '--privileged' in c for c in r.calls))

if __name__=='__main__':unittest.main()
