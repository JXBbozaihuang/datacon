import hashlib
import json
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools.Q2_SKILL_GATE import audit, read_cves

CVE = 'CVE-2021-43798'


def dump(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


class TestSkillGate(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.main = self.root/'output'/'main'
        self.dir = self.main/CVE
        self.dir.mkdir(parents=True)
        self.lst = self.root/'list.txt'
        self.lst.write_text(CVE+'\n')
        self.summary = self.root/'summary.json'
        dump(self.summary, {'requested': 1, 'cases': [{'cve': CVE, 'status': 'MAIN_READY'}]})
        self.files = {
            'docker-images.tar': b'fake-test-image-bytes',
            'docker-compose.yml': b'{"services":{}}',
            'result.json': b'{}',
            'redeploy_result.json': b'{}',
            'portable.compose.json': b'{}',
        }
        digest = hashlib.sha256(self.files['docker-images.tar']).hexdigest()
        self.files['submission.json'] = json.dumps({'cve': CVE,
            'artifact': 'docker-images.tar', 'compose': 'docker-compose.yml',
            'artifact_sha256': digest, 'official_accepted': None}).encode()
        self.files['validation.json'] = json.dumps({'cve': CVE,
            'status': 'DELIVERY_ARCHIVE_AND_CLEAN_REDEPLOY_VERIFIED',
            'archive_content_integrity': {'status': 'PASS'},
            'docker_compose_parser': 'PASS', 'packaged_runtime': 'PASS',
            'source_archive_sha256': digest, 'official_accepted': None}).encode()
        self.files['packaged_runtime.json'] = b'{"status":"PASS","cleaned_up":true}'
        self.write_files()

    def write_files(self):
        for name, content in self.files.items():
            dest = self.dir/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
        inv = [{'path': n, 'size': len(v), 'sha256': hashlib.sha256(v).hexdigest()}
               for n,v in sorted(self.files.items())]
        dump(self.dir/'manifest.json', inv)

    def check(self):
        return audit(self.lst, self.summary, self.main, 1)

    def test_complete_delivery(self):
        self.assertEqual(self.check()['delivery_verified'], 1)

    def test_detect_tampered_archive(self):
        (self.dir/'docker-images.tar').write_bytes(b'tampered')
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_manifest_missing_required(self):
        data = json.loads((self.dir/'manifest.json').read_text())
        dump(self.dir/'manifest.json', [x for x in data if x['path'] != 'result.json'])
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_runtime_fails(self):
        self.files['packaged_runtime.json'] = b'{"status":"FAIL","cleaned_up":true}'
        self.write_files()
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_bad_identity(self):
        self.files['submission.json'] = self.files['submission.json'].replace(CVE.encode(), b'CVE-2021-1111')
        self.write_files()
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_wrong_archive_digest(self):
        bad = json.loads(self.files['submission.json'])
        bad['artifact_sha256'] = '0'*64
        self.files['submission.json'] = json.dumps(bad).encode()
        self.write_files()
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_not_delivered(self):
        dump(self.summary, {'requested': 1, 'cases': [{'cve': CVE, 'status': 'NOT_DELIVERED'}]})
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_summary_duplicates_rejected(self):
        dump(self.summary, {'requested': 1, 'cases': [{'cve': CVE, 'status': 'MAIN_READY'}]*2})
        with self.assertRaises(ValueError): self.check()

    def test_list_duplicate_rejected(self):
        self.lst.write_text(CVE+'\n'+CVE+'\n')
        with self.assertRaises(ValueError): read_cves(self.lst)

    def test_proof_record_not_fresh_proof(self):
        self.files['proof/test_proof.json'] = json.dumps({'cve': CVE, 'status': 'BEHAVIOR_VERIFIED',
                                  'vulnerability_verified': True}).encode()
        self.write_files()
        report = self.check()
        self.assertEqual(report['behavior_proof_recorded_historical'], 1)
        self.assertEqual(report['behavior_verified_this_run'], 0)

    def test_wrong_proof_not_counted(self):
        self.files['proof/test_proof.json'] = b'{"cve":"CVE-2022-12345","status":"BEHAVIOR_VERIFIED","vulnerability_verified":true}'
        self.write_files()
        self.assertEqual(self.check()['behavior_proof_recorded_historical'], 0)

    def test_symlink_archive_rejected(self):
        (self.dir/'docker-images.tar').unlink()
        other = self.root/'elsewhere.tar'
        other.write_bytes(b'fake-test-image-bytes')
        (self.dir/'docker-images.tar').symlink_to(other)
        self.assertEqual(self.check()['delivery_verified'], 0)

    def test_no_official_claim(self):
        data = json.loads(self.files['submission.json'])
        data['official_accepted'] = True
        self.files['submission.json'] = json.dumps(data).encode()
        self.write_files()
        self.assertEqual(self.check()['delivery_verified'], 0)


if __name__ == '__main__':
    unittest.main()
