"""Offline regression: unknown CVE and failed probes can never become PASS."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from track3forge.verification_registry import REGISTRY, lookup, acceptable_verdict
from tools import CVE_AGENT_PLANNER as planner
from tools import BEHAVIOR_BATCH as behavior
from tools import Q2_FULL_RUN as full


class RegistryTests(unittest.TestCase):
    def test_known_targets(self):
        self.assertIn('CVE-2021-42013',REGISTRY)
        self.assertEqual(lookup('CVE-2021-42013').evidence_relative,'proof/apache42013/apache_proof.json')

    def test_unknown_not_registered(self):
        self.assertIsNone(lookup('CVE-2025-99999'))

    def test_parser_not_full(self):
        self.assertEqual(lookup('CVE-2014-6271').claim,'parser_only')

    def test_full_not_inferred_from_claim(self):
        spec=lookup('CVE-2021-43798')
        self.assertFalse(acceptable_verdict(spec,{'cve':spec.cve,'status':'BEHAVIOR_VERIFIED',
                                                  'vulnerability_verified':True}))

    def test_wrong_cve_fails(self):
        spec=lookup('CVE-2021-43798')
        self.assertFalse(acceptable_verdict(spec,{'cve':'CVE-2025-12345',
                                                  'status':'BEHAVIOR_VERIFIED',
                                                  'vulnerability_verified':True,
                                                  'vulnerable_trial':{}, 'fixed_trial':{}, 'checks':['fake']}))

    def test_parser_has_distinct_success_type(self):
        spec=lookup('CVE-2014-6271')
        self.assertTrue(acceptable_verdict(spec,{'cve':spec.cve,'status':'PARSER_BEHAVIOR_VERIFIED',
                                                 'vulnerability_verified':True,
                                                 'vulnerable_trial':{'version':'4.3'},
                                                 'fixed_trial':{'version':'5'}}))


class PlanningTests(unittest.TestCase):
    def test_unknown_plan_never_verified(self):
        p=planner.make_plan('CVE-2025-99999',Path('/nonexistent'),
                            {'source':'NOT_AVAILABLE','description':''},
                            advice={'type':'authentication','checks':['random_canary','run arbitrary shell', 'manual_oracle_review'],
                                    'status':'BEHAVIOR_VERIFIED'})
        self.assertEqual(p['behavior_verdict'],'NOT_TESTED')
        self.assertFalse(p['vetted_behavior_oracle'])
        self.assertNotIn('run arbitrary shell',p['verification_strategy'])
        self.assertEqual(p['vulnerability_class_hypothesis'],'unknown')

    def test_version_hint_without_behavior(self):
        with tempfile.TemporaryDirectory() as d:
            case=Path(d)
            (case/'result.json').write_text(json.dumps({'status':'ENVIRONMENT_EXPORTED_NOT_CVE_PROOF',
                                                        'images':['vendor/a:1.2']}))
            p=planner.make_plan('CVE-2025-99999',case,{'source':'NOT_AVAILABLE','description':''})
            self.assertEqual(p['images'],['vendor/a:1.2'])
            self.assertEqual(p['next_action'],'REVIEW_UNKNOWN_CVE_ORACLE')

    def test_metadata_cache_no_network(self):
        with tempfile.TemporaryDirectory() as d:
            v=planner.safe_metadata('CVE-2025-99999',Path(d),online=False)
            self.assertEqual(v['source'],'NOT_AVAILABLE')

    def test_metadata_cache_record(self):
        with tempfile.TemporaryDirectory() as d:
            cve='CVE-2024-99999'
            Path(d,cve+'.json').write_text(json.dumps({'cveMetadata':{'cveId':cve,'state':'PUBLISHED'},
                                                      'containers':{'cna':{'descriptions':[{'value':'directory traversal in Demo'}],
                                                                            'affected':[{'vendor':'Demo','product':'One'}]}}}))
            v=planner.safe_metadata(cve,Path(d))
            self.assertEqual(planner.hint_type(v['description']),'path_handling')
            self.assertEqual(v['affected'][0]['product'],'One')

    def test_generate_never_claims_success(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            report=planner.generate(['CVE-2025-99999'],root/'main',root/'plans',root/'cache')
            self.assertEqual(report['behavior_verified_this_run'],0)
            self.assertEqual(report['plans'][0]['behavior_verdict'],'NOT_TESTED')


class BatchTests(unittest.TestCase):
    def test_unknown_oracle_missing(self):
        with tempfile.TemporaryDirectory() as d:
            case=Path(d,'CVE-2025-99999')
            case.mkdir()
            rec=behavior.execute_one('CVE-2025-99999',Path(d),budget=120,
                                      allow_pull=False,ack_lab=True,logs=Path(d,'logs'))
            self.assertEqual(rec['status'],'ORACLE_MISSING')
            self.assertFalse(rec['full_behavior_verified_this_run'])

    def test_not_delivered(self):
        with tempfile.TemporaryDirectory() as d:
            rec=behavior.execute_one('CVE-2021-43798',Path(d),budget=120,
                                      allow_pull=False,ack_lab=True,logs=Path(d,'logs'))
            self.assertEqual(rec['status'],'NOT_DELIVERED')

    def test_missing_ack_blocks_subprocess(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d,'CVE-2021-43798').mkdir()
            rec=behavior.execute_one('CVE-2021-43798',Path(d),budget=120,
                                      allow_pull=False,ack_lab=False,logs=Path(d,'logs'))
            self.assertEqual(rec['status'],'LAB_ACK_REQUIRED')

    def test_report_counters_independent(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d,'r.json')
            rows=[{'cve':'CVE-2014-6271','status':'PARSER_BEHAVIOR_VERIFIED',
                   'full_behavior_verified_this_run':False,'parser_only_verified_this_run':True},
                  {'cve':'CVE-2021-42013','status':'BEHAVIOR_VERIFIED',
                   'full_behavior_verified_this_run':True,'parser_only_verified_this_run':False}]
            behavior.write_report(dest,[r['cve'] for r in rows],rows)
            report=json.loads(dest.read_text())
            self.assertEqual(report['full_behavior_verified_this_run'],1)
            self.assertEqual(report['parser_only_verified_this_run'],1)
            self.assertIsNone(report['official_accepted'])

    def test_known_no_fresh_proof_not_success(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            case=base/'CVE-2021-43798'
            proof=case/'proof'/'known'
            proof.mkdir(parents=True)
            p=proof/'known_proof.json'
            p.write_text(json.dumps({'cve':'CVE-2021-43798','status':'BEHAVIOR_VERIFIED',
                                     'vulnerability_verified':True,'checks':['a'],
                                     'vulnerable_trial':{'a':1},'fixed_trial':{'b':2}}))
            with mock.patch.object(behavior.subprocess, 'Popen') as subprocess_mock:
                proc = subprocess_mock.return_value
                proc.wait.return_value=2
                r=behavior.execute_one('CVE-2021-43798',base,budget=120,
                                         allow_pull=False,ack_lab=True,logs=base/'logs')
            self.assertFalse(r['full_behavior_verified_this_run'])


class FullRunnerTests(unittest.TestCase):
    def test_invalid_combined_minimum(self):
        self.assertEqual(full.main(['--list','/does/not/exist','--minimum-delivery','100']),3)

    def test_help_parser_defaults(self):
        args=full.build_parser().parse_args([])
        self.assertEqual(args.minimum_delivery,10)
        self.assertEqual(args.minimum_behavior,0)

    def test_input_list_plaintext(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d,'cves.txt')
            p.write_text('CVE-2021-43798\nCVE-2021-41773\n')
            from tools.Q2_SKILL_GATE import read_cves
            self.assertEqual(len(read_cves(p)),2)

    def test_source_and_artifact_files_are_present(self):
        for path in ['ONE_RUN_Q2_30.sh','tools/BEHAVIOR_BATCH.py',
                     'tools/CVE_AGENT_PLANNER.py','track3forge/verification_registry.py']:
            self.assertTrue((ROOT/path).is_file())

    def test_every_skill_has_frontmatter(self):
        for name in ['track3-q2','cve-intake','recipe-sourcing','container-delivery',
                     'failure-diagnosis','unknown-cve-planning','behavior-verification','submission-gate']:
            self.assertTrue((ROOT/'.agents'/'skills'/name/'SKILL.md').read_text().startswith('---\nname:'))

if __name__ == '__main__': unittest.main()
