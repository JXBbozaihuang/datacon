# Track3Forge Q2 v2.4 consolidation

- Based on verified standalone Q2 team v2.1.2 source ZIP, plus v2.2 Skill and v2.3 proof extension.
- Built full 30-CVE user entrypoint `ONE_RUN_Q2_30.sh` and `tools/Q2_FULL_RUN.py`.
- Added `tools/BEHAVIOR_BATCH.py`: vetted-only local differential oracle registry, hard per-case deadlines, identity, fresh evidence, separate parser-level and full-behavior scores.
- Added `tools/CVE_AGENT_PLANNER.py`: optional public CVE metadata and local Qwen2.5-3B structured evidence planning for unknown CVEs, restricted actions and no model PASS.
- Added eight SKILL.md files for team Agent operating procedures and explicit evidence gates.
- Added `README_CN.md`, team design notes and offline tests.
- No new CVE payload/PoC generation. Unknown CVEs without reviewed oracles remain `ORACLE_MISSING`.
- Local Docker execution and official acceptance are not claimed by the offline authoring tests.
