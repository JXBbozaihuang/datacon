#!/usr/bin/env bash
# Main entrypoint: 30-CVE Docker delivery + LLM plan + reviewed behavior proofs.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
LIST="${TRACK3_CVE_LIST:-examples/cve30_reviewed.txt}"
echo "GPU=OLLAMA_AUTO_OR_NO TRAINING=NO"
echo "CVE_LIST=$LIST"
echo "OUTPUT=$ROOT/output/main"
echo "MODEL=${TRACK3_MODEL:-qwen2.5:3b}"
ARGS=(--list "$LIST" --source "${TRACK3_SOURCE:-data/vulhub}"
      --minimum-delivery "${TRACK3_MIN_DELIVERY:-10}"
      --minimum-behavior "${TRACK3_MIN_BEHAVIOR:-0}"
      --model "${TRACK3_MODEL:-qwen2.5:3b}"
      --total-seconds "${TRACK3_TOTAL_SECONDS:-10800}"
      --proof-budget "${TRACK3_PROOF_SECONDS:-360}")
if [[ "${TRACK3_ACK_LAB:-YES}" == YES ]]; then ARGS+=(--ack-lab); fi
if [[ "${TRACK3_FETCH:-YES}" == YES ]]; then ARGS+=(--fetch); fi
if [[ "${TRACK3_ALLOW_PULL:-YES}" == YES ]]; then ARGS+=(--allow-pull); fi
if [[ "${TRACK3_AGENT:-YES}" == YES ]]; then ARGS+=(--agent); fi
if [[ "${TRACK3_AGENT_PLAN:-YES}" == YES ]]; then ARGS+=(--agent-plan); fi
if [[ "${TRACK3_START_OLLAMA:-YES}" == YES ]]; then ARGS+=(--start-ollama); fi
if [[ "${TRACK3_METADATA_ONLINE:-NO}" == YES ]]; then ARGS+=(--metadata-online); fi
if command -v caffeinate >/dev/null 2>&1; then
  exec caffeinate -i python3 -u tools/Q2_FULL_RUN.py "${ARGS[@]}" "$@"
else
  exec python3 -u tools/Q2_FULL_RUN.py "${ARGS[@]}" "$@"
fi
