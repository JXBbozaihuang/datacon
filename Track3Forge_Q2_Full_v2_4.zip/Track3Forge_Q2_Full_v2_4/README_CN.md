# Track3Forge Q2 v2.4 — 30-CVE 完整工程（团队版）

> 用于授权隔离实验室的赛道三第二题：**CVE 清单 → 可信环境配方 → Docker 构建与导出 → 清洁重部署 → 独立验收 → 行为验证证据**。本仓库为可执行工程，不仅是 Prompt。未知 CVE 不会被编造为已复现。

## 安装环境

- macOS（包括 Apple Silicon）或 Linux；Python ≥3.10；Docker Engine + Compose v2。
- 可选：本地 Ollama 与 `qwen2.5:3b`。执行环境搭建和单元测试无需 GPU、无需训练。
- Docker Desktop 建议预留足够虚拟磁盘，建议单题并发1，避免 Apple Silicon 16GB 内存过载。
- 外网下载仅在 `--fetch` / `--allow-pull` / `TRACK3_METADATA_ONLINE=YES` 等明确选项下发生。
- 使用前确认镜像、漏洞复现配方和实验环境是你有权运行的受控内容；不要暴露到公网。

## 已有团队仓库：推荐直接升级，保留5份环境和现有行为证据

如果你之前已在 `$HOME/Downloads/Track3Forge_Q2_Team` 运行过五题验证，**推荐先使用这条命令**。它只复制新增/升级代码，自动备份原文件、运行全部离线测试，失败回滚。不会修改 `output/`、`data/`、`runs/` 或 Docker 镜像；保留旧路径，避免历史回执中的绝对路径失效。

```bash
cd "$HOME/Downloads" || exit 1
unzip -oq Track3Forge_Q2_Full_v2_4.zip
bash Track3Forge_Q2_Full_v2_4/INSTALL_INTO_TEAM.sh \
  "$HOME/Downloads/Track3Forge_Q2_Team" || exit 1
cd "$HOME/Downloads/Track3Forge_Q2_Team" || exit 1
bash ONE_RUN_Q2_30.sh
printf 'EXIT_CODE=%s\n' "$?"
```

不用将原有 `output/` 复制到新文件夹，也不要随意修改历史 JSON 中的归档路径。如果想使用**全新工程**，再按下面方法运行完整解压目录。

## Mac 一条命令运行30题

下载、解压后：

```bash
cd "$HOME/Downloads" || exit 1
unzip -tq Track3Forge_Q2_Full_v2_4.zip || exit 1
unzip -oq Track3Forge_Q2_Full_v2_4.zip || exit 1
cd Track3Forge_Q2_Full_v2_4 || exit 1
bash ONE_RUN_Q2_30.sh
printf 'EXIT_CODE=%s\n' "$?"
```

默认输入 `examples/cve30_reviewed.txt`，目标 **10/30 环境交付**，剩余目标仍需有真实验收证据，不会虚报。首次将尝试获取可信 Vulhub 源，允许受限 Docker 镜像下载；每题预算与批次预算均有限制。显示当前终端的进度，不用另外开 `tail -f`，执行结束会打印总表。

更换清单（每行一个 CVE，普通 TXT）：

```bash
TRACK3_CVE_LIST="$HOME/Downloads/cves.txt" \
TRACK3_MIN_DELIVERY=10 \
TRACK3_MIN_BEHAVIOR=0 \
bash ONE_RUN_Q2_30.sh
```

想让 Agent 参考公开 CVE 描述来规划未知样本：

```bash
TRACK3_METADATA_ONLINE=YES \
TRACK3_CVE_LIST="$HOME/Downloads/cves.txt" \
bash ONE_RUN_Q2_30.sh
```

**重要：** 提高 `TRACK3_MIN_BEHAVIOR` 会提高最终通过门槛，但不能增加实际能力。缺少可信 CVE 专用验证器时不会得到完整漏洞行为 PASS。

## 常见操作

```bash
# 离线单元测试（不调用 Docker、不连接网络）
bash scripts/check.sh

# 只读计划（只要已存在 data/vulhub；不运行 Docker）
python3 -u tools/Q2_FULL_RUN.py --list examples/cve30_reviewed.txt \
  --source data/vulhub --plan-only --skip-tests

# 重用已有 output/main，重新执行已审定的行为验证；不会重建全部环境
python3 -u tools/BEHAVIOR_BATCH.py --list examples/cve30_reviewed.txt \
  --ack-lab --allow-pull --budget 360

# 只生成结构化 Agent 验证计划，不启动漏洞容器
python3 -u tools/CVE_AGENT_PLANNER.py --list examples/cve30_reviewed.txt \
  --agent --start-ollama --model qwen2.5:3b
```

如果原有工程运行结果不在本工程的 `output/` 下，默认**不会**自动复制或伪造。需要通过可信文件复制/导入流程补齐产物，再验收。

## 工程结构

```text
Track3Forge_Q2_Full_v2_4/
  ONE_RUN_Q2_30.sh                 # 主入口；默认一次30题
  RUN_Q2.sh                        # 原有构建流水线
  tools/Q2_FULL_RUN.py            # 4阶段调度与双层成绩
  tools/BATCH30.py                # 原有镜像调度、resume、超时
  tools/CVE_AGENT_PLANNER.py      # 未知CVE公开信息 + Qwen证据需求分析
  tools/BEHAVIOR_BATCH.py         # 审定验证器批量调度、硬超时
  tools/SUBMISSION_GATE.py        # 镜像交付验收
  tools/Q2_SKILL_GATE.py          # 独立交付复核
  track3forge/verification_registry.py # 专用验证器白名单
  track3forge/apache_proof.py    # Apache 41773/42013
  track3forge/verify.py          # Grafana 43798
  track3forge/activemq_proof.py  # ActiveMQ 46604
  track3forge/bash_proof.py      # Bash 6271（仅解析器级别）
  track3forge/llm.py             # Ollama JSON诊断
  .agents/skills/                 # 8个可复用Skill规范
  examples/                       # 30题和5题列表
  tests/                          # 离线单元与模拟回归
  output/main/<CVE>/              # 可交付产物（自动创建、Git忽略）
  output/agent_plans/<CVE>.json   # 未知样本证据计划
  output/behavior_batch.json      # 行为验证审计
  output/final_report.json        # 本轮最终双层统计
```

## 关键状态，不得混淆

| 字段 | 表示 | 不是 |
|---|---|---|
| `MAIN_READY` / `DELIVERY_VERIFIED` | Docker tar + Compose + 完整性 + 清洁重部署通过 | 实际漏洞行为已触发 |
| `BEHAVIOR_VERIFIED` | 已审定本地随机标记+正反对照验证通过 | 官方评委已接受 |
| `PARSER_BEHAVIOR_VERIFIED` | Bash 解释器解析器现象的差分证据 | 完整 Shellshock CGI 复现 |
| `ORACLE_MISSING` | 未内置该未知 CVE 的审定行为测试 | 漏洞不存在 |
| `OFFICIAL_ACCEPTANCE=UNKNOWN` | 尚无官方结果 | 失败或者通过 |

当前有专用全行为验证器：Grafana `CVE-2021-43798`、Apache `CVE-2021-41773`、`CVE-2021-42013`、ActiveMQ `CVE-2023-46604`；Bash `CVE-2014-6271` 是解析器层的弱证据，Appweb `CVE-2018-8715` 目前没有审定认证差分验证器。

## Agent 在做什么？

Qwen2.5-3B（Ollama）最多做两件事：
1. 使用固定白名单，对 Docker 和镜像日志做故障分类建议，程序决定如何处理。
2. 对未知 CVE 的公开描述、真实镜像版本等证据给出 `verification_strategy`，由程序过滤到版本、配置、负对照、随机标记等**允许的检查类别**。它不会直接编写并执行任意漏洞利用脚本，也不会更改验证器注册表。

自动查找 Vulhub 之外完全未知的新环境、生成任意漏洞 PoC 并获得真实差分证据尚未实现；对于此类情况报告 `NO_RECIPE` 或 `ORACLE_MISSING`，确保可解释且不虚报。工程不能预先保证20/30、30/30或官方评委通过。

## 输出与退出码

终端会打印：`REQUESTED`、`DELIVERY_VERIFIED`、`FULL_BEHAVIOR_VERIFIED_THIS_RUN`、`PARSER_ONLY_VERIFIED_THIS_RUN`、`OVERALL_GATE_SCOPE`、`OVERALL_GATE`、`MAIN`、`REPORT`、`FINISHED=YES`。

- **0**：达到用户配置的门槛；默认只强制环境交付目标，不代表行为已达标。
- **2**：低于目标，但已经完成检查，成功产物保留。
- **3**：执行阶段异常中断或验收报告不一致。
- **124**：子阶段超时可能被外层转为3，详见日志。

禁止向 Git 提交 `output/`、`data/`、`runs/`、镜像 tar、密钥等。详见 `.gitignore` 和 `CONTRIBUTING.md`。
