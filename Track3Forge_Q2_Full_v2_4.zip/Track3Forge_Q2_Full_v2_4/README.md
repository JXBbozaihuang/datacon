# Track3Forge Q2 Integrated v2.4

**New full-run entrypoint:** `bash ONE_RUN_Q2_30.sh` (30 CVEs, Docker delivery, evidence-limited Qwen planning, independent proof batch). For a complete Chinese installation and status guide, read **[README_CN.md](README_CN.md)**. This is a standalone source package; you do not need older hotfix ZIPs.

---

# Track3Forge Q2 · 团队协作核心仓库（v2.1.2）

**用途**：赛道三第二题，输入一组 CVE 编号，在**授权隔离实验环境**中，从可审计的现有 Docker/Compose 配方部署服务、导出镜像、清洁重部署、校验 OCI 归档，并将通过环境交付门禁的产物放入 `output/main/<CVE>/`。此仓库不是漏洞自动利用库，**环境交付成功 ≠ 独立漏洞行为验证成功 ≠ 官方评委验收**。

本仓库以已知 v2.1.0 整合代码为基础，**预合并** v2.1.1（macOS `/var` 和 `/private/var` 路径别名）以及 v2.1.2（`PREFETCH_MISSING` 依赖、缓存优先调度与异常退出分类）。不再需要逐个安装这两个补丁。

## 目录重点

```text
track3forge/       核心：Docker 隔离、Compose 解析、运行状态、模型辅助、验证模块
  core.py          任务执行器、进程及超时机制
  catalog.py       CVE 配方发现与来源获取
  compose.py       Compose 隔离、配置处理与健康状态检查
  pilot.py         环境构建/归档试运行
  platform_export.py  多平台镜像导出处理
  llm.py           可选 Ollama 辅助日志解释（不能宣布成功）
tools/
  Q2_COMPETE.py    Q2 统一调度入口
  BATCH30.py       30-CVE 批量运行、缓存优先、断点续跑
  PREFETCH_MISSING.py  镜像预取和网络失败分类
  SUBMISSION_GATE.py  独立交付门禁与 output/main
  artifact_audit.py    OCI 镜像层完整性校验
examples/          CVE 测试清单（仅样本，不内置镜像）
tests/             可离线运行的单元/模拟集成测试
RUN_Q2.sh          直接运行 Q2
ONE_CLICK_MAC.sh   先回归测试，再运行默认列表（有 Docker 副作用）
docs/              验收分层和工程说明
```

## 第一次拉代码（Mac）

```bash
git clone <团队仓库地址> Track3Forge_Q2_Team
cd Track3Forge_Q2_Team
bash scripts/check.sh          # GPU=NO, TRAINING=NO, DOCKER=NO
```

**运行依赖**：Python >= 3.10、Git、Docker Desktop / Docker Engine 和 Docker Compose v2。可选：Ollama + 本地 `qwen2.5:3b`，仅供辅助分析。测试脚本不拉镜像。正式批处理可能访问 Docker Hub / 获取 Vulhub 环境配方。

## 运行第二题

事先确认 Docker 已启动，且使用来源可信的 `data/vulhub` 配方库。若本地没有该源码，可在实验室网络环境使用 `--fetch` 尝试获取；拉取失败需要自行准备可信来源配方，不会自动生成伪造环境。

```bash
# 先列计划，不构建容器
bash RUN_Q2.sh --list examples/cve30_reviewed.txt --source "$PWD/data/vulhub" --fetch --minimum 10 --plan-only

# 正式批次：GPU=OLLAMA_AUTO_OR_NO, TRAINING=NO, Docker=YES，长任务请使用 caffeinate（Mac）
caffeinate -i bash RUN_Q2.sh \
  --list examples/cve30_reviewed.txt \
  --source "$PWD/data/vulhub" --fetch \
  --allow-pull --ack-lab --minimum 10 \
  --max-new 30 --per-image-seconds 180 \
  --per-cve-seconds 420 --redeploy-seconds 180 \
  --total-seconds 10800
```

如需 Ollama 辅助诊断，可额外加 `--agent --start-ollama --model qwen2.5:3b`，不需要训练模型。

查看结果：

```bash
python3 scripts/summary.py
ls output/main
```

交付规范见 `docs/VERIFICATION_POLICY.md`。本地 `MAIN_READY` 仅代表代码中的交付门禁，不能直接当作官方成功率。

## 团队 Git 工作流

推荐创建**私有仓库**，所有成员 fork/分支提交 PR：

```bash
git switch -c feat/compose-health
# 修改代码并运行 bash scripts/check.sh
git add track3forge/ tools/ tests/ docs/
git commit -m "fix: improve compose health check"
git push -u origin feat/compose-health
```

- `main` 保持可运行，合并 PR 前必须离线回归通过；再安排专门的 Mac Docker 实测。
- **不要提交** `runs/`、`output/`、`data/`、镜像 tar、凭据、绝对路径日志。`.gitignore` 已默认排除。
- 每个 PR 说明：修复问题、复现步骤、回归测试、是否涉及 Docker 副作用以及验收结论。
- 测试清单可以提交；**真实大镜像和交付包不要放 Git**，使用内部制品库/授权文件共享。

详细协作约定见 [CONTRIBUTING.md](CONTRIBUTING.md)。

## 版本与已知边界

- 已在离线环境验证**225/225 单元及模拟集成测试通过**；尚未在当前交付的最终团队仓库上完成 Mac Docker 真实批次。
- 先前的真实批次观测为 **7/30 进入 `output/main`**，后续修补的实际交付率还没有新的 Mac 结果；旧工程曾出现 19/30 的环境交付基线，二者验收门槛不同，不能混算。
- 没有可信配方、镜像层下载失败或缺乏漏洞差分证据时，必须保留相应未通过状态。
